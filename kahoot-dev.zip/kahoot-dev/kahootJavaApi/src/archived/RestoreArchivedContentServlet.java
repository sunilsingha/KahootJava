package archived;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

import archived.classes.request.RestoreArchiveContentRequest;
import contents.classes.data.ContentData;
import db_operations.ActionLogDBUtils;
import db_operations.ContentDBUtils;
import db_operations.DBUtils;
import db_operations.UserDBUtils;
import users.classes.data.UserData;
import utils.RequestHelper;
import utils.Utils;
import validation.ValidateRequest;

import javax.annotation.Resource;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.Message.RecipientType;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.naming.InitialContext;
//import com.sap.core.connectivity.api.http.HttpDestination;


/**
 * Servlet implementation class RejectArchivedContentServlet
 */
@WebServlet("/api/contents/restore-archived-content")
public class RestoreArchivedContentServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;
    @Resource(name = "mail/Session")
    private Session	      mailSession;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public RestoreArchivedContentServlet()
    {
	super();
	// TODO Auto-generated constructor stub

	initialize();
    }


    private void initialize()
    {
	try
	{
	    InitialContext ctx = new InitialContext();
	    mailSession = (Session) ctx.lookup("java:comp/env/mail/Session");
	}
	catch (Exception e)
	{
	    e.printStackTrace();
	}
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub

	// Gets UserId
	String userId = new RequestHelper().getUserIdToResponse(response);
	if (userId == "")
	{
	    return;
	}

	// checks content type
	if (ValidateRequest.IsJSONRequest(request, response) == false)
	{
	    return;
	}

	// reads request data
	StringBuffer jb = new StringBuffer();
	String line = null;
	try
	{
	    BufferedReader reader = request.getReader();
	    while ((line = reader.readLine()) != null)
		jb.append(line);
	}
	catch (Exception e)
	{
	    Utils.addErrorResponse(response, "Invalid request.");
	    e.printStackTrace();
	    return;
	}

	// Parses JSOn String to object
	ObjectMapper mapper = new ObjectMapper();
	RestoreArchiveContentRequest restoreArchiveContentRequest;

	// Parse JSON string to JSON object
	try
	{
	    String requestJson = jb.toString();
	    restoreArchiveContentRequest = mapper.readValue(requestJson, RestoreArchiveContentRequest.class);
	}
	catch (Exception e)
	{
	    Utils.addErrorResponse(response, "Invalid request.");
	    e.printStackTrace();
	    return;
	}

	if (restoreArchiveContentRequest.ContentId == 0)
	{
	    Utils.addErrorResponse(response, "Invalid request.");
	    return;
	}

	// Connects to database
	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	try
	{
	    // Checks content Id exists
	    if (ContentDBUtils.isContentExists(conn, restoreArchiveContentRequest.ContentId) == false)
	    {
		Utils.addErrorResponse(response, "Content Id " + Long.toString(restoreArchiveContentRequest.ContentId) + " not found.");
		DBUtils.CloseConnection(conn);
		return;
	    }

	    // Checks UserId is Administrator
	    if (UserDBUtils.IsUserContentAdministrator(conn, userId) == false)
	    {
		Utils.addErrorResponse(response, "User " + userId + " is not Content Administrator.");
		DBUtils.CloseConnection(conn);
		return;
	    }

	    // Checks content Id archived
	    if (ContentDBUtils.isContent_Archived(conn, restoreArchiveContentRequest.ContentId) == false)
	    {
		Utils.addErrorResponse(response, "Content Id " + restoreArchiveContentRequest.ContentId + " not archived.");
		DBUtils.CloseConnection(conn);
		return;
	    }

	    ContentData contentData = ContentDBUtils.GetContentByContentId(conn, restoreArchiveContentRequest.ContentId);
	    UserData administrator = UserDBUtils.GetUsersDataByUsersId(conn, userId);
	    UserData creator = UserDBUtils.GetUsersDataByUsersId(conn, contentData.OwnerId);

	    // Begins Transaction
	    conn.setAutoCommit(false);

	    // changes status to published and add log to the action table
	    ContentDBUtils.updateStatus_To_Published(conn, restoreArchiveContentRequest.ContentId, userId);

	    // Insert new actions log
	    long actionLogId = ActionLogDBUtils.getNextActionLogId(conn);
	    ActionLogDBUtils.addActionLogforPublished(conn, actionLogId, restoreArchiveContentRequest.ContentId, userId);

	    // Commits Transaction
	    conn.commit();
	    conn.setAutoCommit(true);

	    // Construct message from parameters
	    MimeMessage mimeMessage = new MimeMessage(mailSession);
	    InternetAddress[] fromAddress = new InternetAddress[1];
	    fromAddress[0] = new InternetAddress(administrator.Email, administrator.Name);

	    InternetAddress[] toAddresses = new InternetAddress[1];
	    toAddresses[0] = new InternetAddress(creator.Email, creator.Name);

	    mimeMessage.setFrom(fromAddress[0]);
	    mimeMessage.setRecipients(RecipientType.TO, toAddresses);
	    mimeMessage.setSubject("Content restored: " + contentData.Title, "UTF-8");

	    MimeMultipart multiPart = new MimeMultipart("alternative");
	    MimeBodyPart part = new MimeBodyPart();

	    String strHtml = "";
	    strHtml += "Dear " + creator.Name + ",<br />";
	    strHtml += "<p>Please be informed that your archived content <strong><em>" + contentData.Title
	            + "</em></strong> has just been restored and is now available again for the Experience Center & SAP Community.</p>";
	    strHtml += "<p>You will be prompted separately if an update is needed.</p>";
	    strHtml += "<p>Thank you for your contribution.</p>";
	    strHtml += "Best regards,<br />";
	    strHtml += administrator.Name;

	    part.setContent(strHtml, "text/html; charset=utf-8");

	    multiPart.addBodyPart(part);
	    mimeMessage.setContent(multiPart);
	    // Send mail
	    Transport transport = null;
	    transport = mailSession.getTransport();
	    transport.connect();
	    transport.sendMessage(mimeMessage, mimeMessage.getAllRecipients());

	    DBUtils.CloseConnection(conn);
	}
	catch (Exception e)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	Utils.addSuccessResponse(response, "Content restored.");
    }

}
