package archived.classes.request;

public class RestoreArchiveContentRequest
{
    public long ContentId;
}
