package archived.classes.request;

public class RestoreMailRequest
{
    public String fromName;
    public String fromEmailId;
    public String toName;
    public String toEmailId;
    public String subject;
    public String content;
}
