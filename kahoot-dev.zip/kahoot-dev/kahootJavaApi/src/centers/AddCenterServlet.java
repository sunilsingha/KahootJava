package centers;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import centers.classes.response.CenterAddResponse;
import cmis_operations.CMISRepository;
import cmis_operations.CenterCMISRepository;
import cmis_operations.classes.CenterFolders;
import db_operations.CentersDBUtils;
import db_operations.DBUtils;
import utils.RequestHelper;
import utils.RequestType;
import utils.Utils;


/**
 * Servlet implementation class addCenterServlet
 */
@WebServlet("/api/centers/add-center")
public class AddCenterServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddCenterServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub
	String userId = new RequestHelper().getUserIdToResponse(response);
	if (userId == "")
	{
	    return;
	}

	// Connect to database
	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	// Reads Request Data and validates it
	AddOrUpdateCenterUtils addOrUpdateCenterUtils = new AddOrUpdateCenterUtils(request, response, RequestType.Add, conn);
	boolean blValidRequestData = false;
	try
	{
	    blValidRequestData = addOrUpdateCenterUtils.IsValidRequestData();
	}
	catch (Exception e)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while validating the fields - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	if (blValidRequestData == false)
	{
	    DBUtils.CloseConnection(conn);
	    return;
	}

	// Opens session in repository
	CMISRepository cmisRepository;

	try
	{
	    cmisRepository = new CMISRepository();
	    cmisRepository.sessionLogin();
	}
	catch (Exception e)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while connecting to CMIS repository - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	// Gets New Center Id
	try
	{
	    // Gets Next Sequence Id
	    addOrUpdateCenterUtils.setCenterId(CentersDBUtils.getNextCenterId(conn));
	}
	catch (Exception e)
	{
	    cmisRepository.session.clear();
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while retrieving Sequence Id - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	// Creates Folder Structure for Center in Document Repository
	CenterFolders centerFolders = null;
	CenterCMISRepository centerCMISRepository = new CenterCMISRepository(cmisRepository);
	try
	{
	    String strCenterId = Long.toString(addOrUpdateCenterUtils.getCenterId());
	    centerFolders = centerCMISRepository.CreateFolderStructure(strCenterId);

	}
	catch (Exception e)
	{
	    cmisRepository.session.clear();
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while creating folder structure - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	// updates files and documents in database and repository
	try
	{
	    addOrUpdateCenterUtils.processUpdatingCenter(cmisRepository, centerFolders);
	}
	catch (Exception e)
	{
	    cmisRepository.session.clear();
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while upading data and documents - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	DBUtils.CloseConnection(conn);
	cmisRepository.session.clear();

	// Creates object to send response
	CenterAddResponse centerAddResponse = new CenterAddResponse();
	centerAddResponse.contentId = Long.toString(addOrUpdateCenterUtils.getCenterId());
	centerAddResponse.message = "New Center Added";

	Utils.addSuccessResponseFromObject(response, centerAddResponse);
    }

}
