package centers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import centers.classes.data.CenterData;
import centers.classes.data.CenterDataFile;
import centers.classes.request.CenterRequest;
import cmis_operations.CMISRepository;
import cmis_operations.classes.CMISDocument;
import cmis_operations.classes.CenterFolders;
import db_operations.CMISDocumentDBUtils;
import db_operations.CentersDBUtils;
import db_operations.DBUtils;
import db_operations.SQLFieldsAndQueries;
import utils.RequestHelper;
import utils.RequestType;
import utils.Utils;
import validation.ValidateFile;
import validation.ValidateFileArray;
import validation.ValidateFormFields;
import validation.ValidateNumber;
import validation.ValidateNumberArray;
import validation.ValidateString;
import validation.ValidateStringArray;
import validation.classes.EnumFieldType;
import validation.classes.FormField;


public class AddOrUpdateCenterUtils
{

    private HttpServletRequest	request;
    private HttpServletResponse	response;
    private RequestType		requestType;
    private Connection		conn;
    private CenterRequest	centerRequest;

    private static final String tblCenters = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblCenters + "\"";


    public AddOrUpdateCenterUtils(HttpServletRequest _httpServletRequest, HttpServletResponse _httpServletResponse,
                                  RequestType _requestType, Connection _conn)
    {
	request = _httpServletRequest;
	response = _httpServletResponse;
	requestType = _requestType;
	conn = _conn;
    }


    public void setCenterId(long centerId)
    {
	centerRequest.CenterId = centerId;
    }


    public long getCenterId()
    {
	return centerRequest.CenterId;
    }


    public boolean IsValidRequestData()
            throws IOException, SQLException
    {
	// process only if its multipart content
	if (!ServletFileUpload.isMultipartContent(request))
	{
	    Utils.addErrorResponse(response, "Invalid request");
	    return false;
	}

	centerRequest = new CenterRequest();
	centerRequest.UserId = (new RequestHelper().getUser()).getName();

	DiskFileItemFactory factory = new DiskFileItemFactory();
	// factory.setSizeThreshold(209715200);
	ServletFileUpload upload = new ServletFileUpload(factory);
	// upload.setFileSizeMax(209715200);

	ValidateFormFields validateFormFields = getValidateFormFieldsList();

	try
	{
	    List<FileItem> fileItems = upload.parseRequest(request);
	    Iterator<FileItem> iterator = fileItems.iterator();

	    while (iterator.hasNext())
	    {
		FileItem fileItem = (FileItem) iterator.next();
		if (fileItem.isFormField())
		{
		    addValuesToObject(fileItem);
		}
		else
		{
		    addFilesToObject(fileItem);
		}

		validateFormFields.updateRequestFieldCount(fileItem);
	    }
	}
	catch (Exception e)
	{
	    Utils.addErrorResponse(response, "Error occurred while reading request items - " + e.getMessage());
	    e.printStackTrace();
	    return false;
	}

	// Validates Form fields
	if (validateFormFields.IsValidToResponse() == false)
	{
	    return false;
	}

	// Validating fields starts
	ValidateString validateString = new ValidateString(response, true);
	ValidateFile validateFile = new ValidateFile(response, true);
	ValidateStringArray validateStringArray = new ValidateStringArray(response, true);
	ValidateFileArray validateFileArray = new ValidateFileArray(response, true);
	ValidateNumber validateNumber = new ValidateNumber(response, true);
	ValidateNumberArray validateNumberArray = new ValidateNumberArray(response, true);

	// Checks for CenterId
	if (requestType == RequestType.Update)
	{
	    // checks for contentId field
	    validateNumber.Reset();
	    validateNumber.IsStringInput = true;
	    validateNumber.StrInput = centerRequest.strCenterId;
	    validateNumber.FieldName = "'CenterId'";
	    validateNumber.IsRequired = true;
	    validateNumber.IsLong = true;
	    validateNumber.IsAllCharactersNumber = true;

	    if (validateNumber.isValueNumericToResponse() == false)
	    {
		return false;
	    }

	    centerRequest.CenterId = Long.parseLong(centerRequest.strCenterId);

	    if (CentersDBUtils.isCenterIdExists(conn, centerRequest.CenterId) == false)
	    {
		Utils.addErrorResponse(response, "center Id " + centerRequest.CenterId + " not found.");
		return false;
	    }
	}
	else
	{
	    centerRequest.CenterId = 0;
	}

	// checks for name field
	validateString.Reset();
	validateString.Input = centerRequest.Name;
	validateString.FieldName = "'Name'";
	validateString.IsRequired = true;
	validateString.IsValueWillBeTrimmed = true;
	validateString.HasMaximumLength = true;
	validateString.MaximumLength = 255;

	if (validateString.isValueStringToResponse() == false)
	{
	    return false;
	}

	if (CentersDBUtils.isCenterNameExists(conn, centerRequest.Name, centerRequest.CenterId))
	{
	    Utils.addErrorResponse(response, "Center Name '" + centerRequest.Name + "' already exists.");
	    return false;
	}

	// checks for city field
	validateString.Reset();
	validateString.Input = centerRequest.City;
	validateString.FieldName = "'City'";
	validateString.IsRequired = true;
	validateString.IsValueWillBeTrimmed = true;
	validateString.HasMaximumLength = true;
	validateString.MaximumLength = 50;

	if (validateString.isValueStringToResponse() == false)
	{
	    return false;
	}

	// checks for country field
	validateString.Reset();
	validateString.Input = centerRequest.Country;
	validateString.FieldName = "'Country'";
	validateString.IsRequired = true;
	validateString.IsValueWillBeTrimmed = true;
	validateString.HasMaximumLength = true;
	validateString.MaximumLength = 50;

	if (validateString.isValueStringToResponse() == false)
	{
	    return false;
	}

	// checks for latitude field
	validateString.Reset();
	validateString.Input = centerRequest.Latitude;
	validateString.FieldName = "'Latitude'";
	validateString.IsRequired = true;
	validateString.IsValueWillBeTrimmed = true;
	validateString.IsLatitudeOrLongitude = true;
	validateString.HasMaximumLength = true;
	validateString.MaximumLength = 30;

	if (validateString.isValueStringToResponse() == false)
	{
	    return false;
	}

	// checks for longitude field
	validateString.Reset();
	validateString.Input = centerRequest.Longitude;
	validateString.FieldName = "'Longitude'";
	validateString.IsRequired = true;
	validateString.IsValueWillBeTrimmed = true;
	validateString.IsLatitudeOrLongitude = true;
	validateString.HasMaximumLength = true;
	validateString.MaximumLength = 30;

	if (validateString.isValueStringToResponse() == false)
	{
	    return false;
	}

	// checks for description field
	validateString.Reset();
	validateString.Input = centerRequest.Description;
	validateString.FieldName = "'Description'";
	validateString.IsRequired = true;
	validateString.IsValueWillBeTrimmed = true;
	validateString.HasMinimumLength = true;
	validateString.MinimumLength = 1;

	if (validateString.isValueStringToResponse() == false)
	{
	    return false;
	}

	// checks for VirtualTourURL field
	validateString.Reset();
	validateString.Input = centerRequest.VirtualTourURL;
	validateString.FieldName = "'VirtualTourURL'";
	validateString.IsRequired = true;
	validateString.IsValueWillBeTrimmed = true;
	validateString.HasMaximumLength = true;
	validateString.MaximumLength = 255;

	if (validateString.isValueStringToResponse() == false)
	{
	    return false;
	}

	// checks for BookVisitURL field
	validateString.Reset();
	validateString.Input = centerRequest.BookVisitURL;
	validateString.FieldName = "'BookVisitURL'";
	validateString.IsRequired = true;
	validateString.IsValueWillBeTrimmed = true;
	validateString.HasMaximumLength = true;
	validateString.MaximumLength = 500;

	if (validateString.isValueStringToResponse() == false)
	{
	    return false;
	}

	// checks for marker color field
	validateString.Reset();
	validateString.Input = centerRequest.MarkerColor;
	validateString.FieldName = "'MarkerColor'";
	validateString.IsRequired = true;
	validateString.IsValueWillBeTrimmed = true;
	validateString.HasMaximumLength = true;
	validateString.MaximumLength = 10;

	if (validateString.isValueStringToResponse() == false)
	{
	    return false;
	}

	// checks for contacts field
	validateStringArray.Reset();
	validateStringArray.Input = centerRequest.Contacts;
	validateStringArray.FieldName = "'Contacts'";
	validateStringArray.IsRequired = true;
	validateStringArray.CheckDuplicates = true;
	validateStringArray.IsEmail = true;
	validateStringArray.HasMaximumStringLength = true;
	validateStringArray.MaximumStringLength = 255;

	if (validateStringArray.IsStringArrayToResponse() == false)
	{
	    return false;
	}

	// Checks file item for Introduction Video
	validateFile.Reset();
	validateFile.InputFile = centerRequest.IntroductionVideoFile;
	validateFile.FieldName = "'IntroductionVideo'";
	validateFile.IsRequired = requestType == RequestType.Add;
	validateFile.IsVideo = true;

	if (validateFile.IsValidFileToResponse() == false)
	{
	    return false;
	}

	// Checks file item for Pictures
	validateFileArray.Reset();
	validateFileArray.InputFiles = centerRequest.Pictures;
	validateFileArray.FieldName = "'Pictures'";
	validateFileArray.IsRequired = requestType == RequestType.Add;
	validateFileArray.IsImage = true;

	if (validateFileArray.IsValidFileArrayToResponse() == false)
	{
	    return false;
	}

	// Checks file item for Floormaps
	validateFileArray.Reset();
	validateFileArray.InputFiles = centerRequest.Floormaps;
	validateFileArray.FieldName = "'Floormaps'";
	validateFileArray.IsRequired = requestType == RequestType.Add;
	validateFileArray.IsImage = true;

	if (validateFileArray.IsValidFileArrayToResponse() == false)
	{
	    return false;
	}

	// Checks file item for other documents
	validateFileArray.Reset();
	validateFileArray.InputFiles = centerRequest.OtherDocuments;
	validateFileArray.FieldName = "'OtherDocuments'";
	validateFileArray.IsRequired = false;
	validateFileArray.IsDocument = true;

	if (validateFileArray.IsValidFileArrayToResponse() == false)
	{
	    return false;
	}

	int i = 0;
	// Checks for remove files in centers in update
	if (requestType == RequestType.Update)
	{
	    String strRemoveId = "";
	    long lRemoveId = 0L;
	    long cmisDocumentId = 0L;
	    List<String> messageList = new ArrayList<String>();

	    // checks for pictures
	    if (centerRequest.strRemovePicturesByIds != null)
	    {
		validateNumberArray.Reset();
		validateNumberArray.IsStringInput = true;
		validateNumberArray.StringArrayInput = centerRequest.strRemovePicturesByIds;
		validateNumberArray.FieldName = "'RemovePicturesByIds'";
		validateNumberArray.IsLong = true;

		if (validateNumberArray.IsNumberArrayToResponse() == false)
		{
		    return false;
		}

		centerRequest.RemovePicturesFiles = new ArrayList<CenterDataFile>();
		for (i = 0; i < centerRequest.strRemovePicturesByIds.size(); i++)
		{
		    strRemoveId = centerRequest.strRemovePicturesByIds.get(i);
		    lRemoveId = Long.parseLong(strRemoveId);

		    if (CentersDBUtils.isCenterPictureExists(conn, centerRequest.CenterId, lRemoveId) == false)
		    {
			messageList.add("Item " + (i + 1) + " of Picture Id " + lRemoveId + " doesn't exists.");
		    }
		    else
		    {
			cmisDocumentId = CentersDBUtils.GetCMISDocumentIdOfPictureId(conn, lRemoveId);

			CenterDataFile centerPictureFile = new CenterDataFile();
			centerPictureFile.Id = lRemoveId;
			centerPictureFile.CMISDocument = CMISDocumentDBUtils.GetCMISDocumentById(conn, cmisDocumentId);
			centerRequest.RemovePicturesFiles.add(centerPictureFile);
		    }
		}

		if (messageList.size() > 0)
		{
		    Utils.addErrorListResponse(response, "Error in the field 'RemovePicturesByIds'.", messageList);
		    return false;
		}
	    }

	    // checks for floormaps
	    if (centerRequest.strRemoveFloormapsByIds != null)
	    {
		validateNumberArray.Reset();
		validateNumberArray.IsStringInput = true;
		validateNumberArray.StringArrayInput = centerRequest.strRemoveFloormapsByIds;
		validateNumberArray.FieldName = "'RemoveFloormapsByIds'";
		validateNumberArray.IsLong = true;

		if (validateNumberArray.IsNumberArrayToResponse() == false)
		{
		    return false;
		}

		centerRequest.RemoveFloormapsFiles = new ArrayList<CenterDataFile>();
		for (i = 0; i < centerRequest.strRemoveFloormapsByIds.size(); i++)
		{
		    strRemoveId = centerRequest.strRemoveFloormapsByIds.get(i);
		    lRemoveId = Long.parseLong(strRemoveId);

		    if (CentersDBUtils.isCenterFloormapExists(conn, centerRequest.CenterId, lRemoveId) == false)
		    {
			messageList.add("Item " + (i + 1) + " of Floormap Id " + lRemoveId + " doesn't exists.");
		    }
		    else
		    {
			cmisDocumentId = CentersDBUtils.GetCMISDocumentIdOfFloormapId(conn, lRemoveId);

			CenterDataFile centerFloormapFile = new CenterDataFile();
			centerFloormapFile.Id = lRemoveId;
			centerFloormapFile.CMISDocument = CMISDocumentDBUtils.GetCMISDocumentById(conn, cmisDocumentId);
			centerRequest.RemoveFloormapsFiles.add(centerFloormapFile);
		    }
		}

		if (messageList.size() > 0)
		{
		    Utils.addErrorListResponse(response, "Error in the field 'RemoveFloormapsByIds'.", messageList);
		    return false;
		}
	    }

	    // checks for other documents
	    if (centerRequest.strRemoveOtherDocumentsByIds != null)
	    {
		validateNumberArray.Reset();
		validateNumberArray.IsStringInput = true;
		validateNumberArray.StringArrayInput = centerRequest.strRemoveOtherDocumentsByIds;
		validateNumberArray.FieldName = "'RemoveOtherDocumentsByIds'";
		validateNumberArray.IsLong = true;

		if (validateNumberArray.IsNumberArrayToResponse() == false)
		{
		    return false;
		}

		centerRequest.RemoveOtherDocumentsFiles = new ArrayList<CenterDataFile>();
		for (i = 0; i < centerRequest.strRemoveOtherDocumentsByIds.size(); i++)
		{
		    strRemoveId = centerRequest.strRemoveOtherDocumentsByIds.get(i);
		    lRemoveId = Long.parseLong(strRemoveId);

		    if (CentersDBUtils.isCenterOtherDocumentExists(conn, centerRequest.CenterId, lRemoveId) == false)
		    {
			messageList.add("Item " + (i + 1) + " of OtherDocument Id " + lRemoveId + " doesn't exists.");
		    }
		    else
		    {
			cmisDocumentId = CentersDBUtils.GetCMISDocumentIdOfOtherDocumentId(conn, lRemoveId);

			CenterDataFile centerOtherDocumentFile = new CenterDataFile();
			centerOtherDocumentFile.Id = lRemoveId;
			centerOtherDocumentFile.CMISDocument = CMISDocumentDBUtils.GetCMISDocumentById(conn, cmisDocumentId);
			centerRequest.RemoveOtherDocumentsFiles.add(centerOtherDocumentFile);
		    }
		}

		if (messageList.size() > 0)
		{
		    Utils.addErrorListResponse(response, "Error in the field 'RemoveOtherDocumentsByIds'.", messageList);
		    return false;
		}
	    }

	}

	return true;
    }


    private ValidateFormFields getValidateFormFieldsList()
    {
	ValidateFormFields validateFormFields = new ValidateFormFields(response);

	validateFormFields.addFormField(new FormField("name", EnumFieldType.Text, false));
	validateFormFields.addFormField(new FormField("city", EnumFieldType.Text, false));
	validateFormFields.addFormField(new FormField("country", EnumFieldType.Text, false));
	validateFormFields.addFormField(new FormField("latitude", EnumFieldType.Text, false));
	validateFormFields.addFormField(new FormField("longitude", EnumFieldType.Text, false));
	validateFormFields.addFormField(new FormField("description", EnumFieldType.Text, false));
	validateFormFields.addFormField(new FormField("virtualtoururl", EnumFieldType.Text, false));
	validateFormFields.addFormField(new FormField("bookvisiturl", EnumFieldType.Text, false));
	validateFormFields.addFormField(new FormField("markercolor", EnumFieldType.Text, false));
	validateFormFields.addFormField(new FormField("contacts[]", EnumFieldType.Text, true));
	validateFormFields.addFormField(new FormField("introductionvideo", EnumFieldType.File, false));
	validateFormFields.addFormField(new FormField("pictures[]", EnumFieldType.File, false));
	validateFormFields.addFormField(new FormField("floormaps[]", EnumFieldType.File, false));
	validateFormFields.addFormField(new FormField("otherdocuments[]", EnumFieldType.File, false));

	if (requestType == RequestType.Update)
	{
	    validateFormFields.addFormField(new FormField("centerid", EnumFieldType.Text, false));
	    validateFormFields.addFormField(new FormField("removepicturesbyids[]", EnumFieldType.Text, true));
	    validateFormFields.addFormField(new FormField("removefloormapsbyids[]", EnumFieldType.Text, true));
	    validateFormFields.addFormField(new FormField("removeotherdocumentsbyids[]", EnumFieldType.Text, true));
	}

	return validateFormFields;
    }


    private void addValuesToObject(FileItem item)
            throws Exception
    {
	String fieldName = item.getFieldName().toLowerCase();
	String value = "";

	try
	{
	    value = item.getString("UTF-8");
	}
	catch (UnsupportedEncodingException ex)
	{
	    throw new Exception("UTF-8 is unsupported encoding !?");
	}

	switch (fieldName)
	{
	    case "centerid":
		centerRequest.strCenterId = value;
		break;

	    case "name":
		centerRequest.Name = value;
		break;

	    case "city":
		centerRequest.City = value;
		break;

	    case "country":
		centerRequest.Country = value;
		break;

	    case "latitude":
		centerRequest.Latitude = value;
		break;

	    case "longitude":
		centerRequest.Longitude = value;
		break;

	    case "description":
		centerRequest.Description = value;
		break;

	    case "virtualtoururl":
		centerRequest.VirtualTourURL = value;
		break;

	    case "bookvisiturl":
		centerRequest.BookVisitURL = value;
		break;

	    case "markercolor":
		centerRequest.MarkerColor = value;
		break;

	    case "contacts[]":
		if (centerRequest.Contacts == null)
		{
		    centerRequest.Contacts = new ArrayList<String>();
		}
		value = value.trim();
		centerRequest.Contacts.add(value);
		break;

	    case "removepicturesbyids[]":
		if (centerRequest.strRemovePicturesByIds == null)
		{
		    centerRequest.strRemovePicturesByIds = new ArrayList<String>();
		}
		value = value.trim();
		centerRequest.strRemovePicturesByIds.add(value);
		break;

	    case "removefloormapsbyids[]":
		if (centerRequest.strRemoveFloormapsByIds == null)
		{
		    centerRequest.strRemoveFloormapsByIds = new ArrayList<String>();
		}
		value = value.trim();
		centerRequest.strRemoveFloormapsByIds.add(value);
		break;

	    case "removeotherdocumentsbyids[]":
		if (centerRequest.strRemoveOtherDocumentsByIds == null)
		{
		    centerRequest.strRemoveOtherDocumentsByIds = new ArrayList<String>();
		}
		value = value.trim();
		centerRequest.strRemoveOtherDocumentsByIds.add(value);
		break;
	}
    }


    private void addFilesToObject(FileItem item)
    {
	String fieldName = item.getFieldName().toLowerCase();

	switch (fieldName)
	{
	    case "introductionvideo":
		centerRequest.IntroductionVideoFile = item;
		break;

	    case "pictures[]":
		if (centerRequest.Pictures == null)
		{
		    centerRequest.Pictures = new ArrayList<FileItem>();
		}
		centerRequest.Pictures.add(item);
		break;

	    case "floormaps[]":
		if (centerRequest.Floormaps == null)
		{
		    centerRequest.Floormaps = new ArrayList<FileItem>();
		}
		centerRequest.Floormaps.add(item);
		break;

	    case "otherdocuments[]":
		if (centerRequest.OtherDocuments == null)
		{
		    centerRequest.OtherDocuments = new ArrayList<FileItem>();
		}
		centerRequest.OtherDocuments.add(item);
		break;

	}
    }


    public void processUpdatingCenter(CMISRepository cmisRepository, CenterFolders centerFolders)
            throws IOException, SQLException
    {
	long cmisDocumentId = 0L;
	int i = 0;
	CMISDocument cmisDocument = null;
	CenterData centerData = null;

	// Gets all documents
	if (requestType == RequestType.Update)
	{
	    centerData = CentersDBUtils.GetCenterById(conn, centerRequest.CenterId);

	    if (centerRequest.IntroductionVideoFile != null)
	    {
		if (centerData.IntroductionVideo_CMISDocument != null)
		{
		    centerRequest.RemoveIntroductionVideo_CMISDocument = centerData.IntroductionVideo_CMISDocument;
		    centerRequest.RemoveIntroductionVideo_CMISDocument = cmisRepository.updateCMIS_DocumentbyDetails(centerFolders.IntroductionVideoFolder,
		                                                                                                    centerRequest.RemoveIntroductionVideo_CMISDocument);
		}
	    }

	    if (centerRequest.RemovePicturesFiles != null)
	    {
		for (i = 0; i < centerRequest.RemovePicturesFiles.size(); i++)
		{
		    centerRequest.RemovePicturesFiles.get(i).CMISDocument = cmisRepository.updateCMIS_DocumentbyDetails(centerFolders.PicturesFolder,
		                                                                                                        centerRequest.RemovePicturesFiles.get(i).CMISDocument);
		}
	    }

	    if (centerRequest.RemoveFloormapsFiles != null)
	    {
		for (i = 0; i < centerRequest.RemoveFloormapsFiles.size(); i++)
		{
		    centerRequest.RemoveFloormapsFiles.get(i).CMISDocument = cmisRepository.updateCMIS_DocumentbyDetails(centerFolders.FloormapsFolder,
		                                                                                                         centerRequest.RemoveFloormapsFiles.get(i).CMISDocument);
		}
	    }

	    if (centerRequest.RemoveOtherDocumentsFiles != null)
	    {
		for (i = 0; i < centerRequest.RemoveOtherDocumentsFiles.size(); i++)
		{
		    centerRequest.RemoveOtherDocumentsFiles.get(i).CMISDocument = cmisRepository.updateCMIS_DocumentbyDetails(centerFolders.OtherDocumentsFolder,
		                                                                                                              centerRequest.RemoveOtherDocumentsFiles.get(i).CMISDocument);
		}
	    }
	}

	// Adds Introduction Video File
	if (centerRequest.IntroductionVideoFile != null)
	{
	    cmisDocumentId = CMISDocumentDBUtils.GetNextCMISDocumentId(conn);
	    centerRequest.IntroductionVideo_CMISDocument = cmisRepository.AddCMIS_Document(centerFolders.IntroductionVideoFolder,
	                                                                                  cmisDocumentId,
	                                                                                  centerRequest.IntroductionVideoFile);
	    CMISDocumentDBUtils.AddCMISDocumentFromCMISDocument(conn, centerRequest.UserId, centerRequest.IntroductionVideo_CMISDocument);
	}

	// Adds Picture files
	if (centerRequest.Pictures != null)
	{
	    FileItem fileItemPicture = null;
	    centerRequest.Pictures_CMISDocuments = new ArrayList<CMISDocument>();

	    for (i = 0; i < centerRequest.Pictures.size(); i++)
	    {
		fileItemPicture = centerRequest.Pictures.get(i);
		cmisDocumentId = CMISDocumentDBUtils.GetNextCMISDocumentId(conn);
		cmisDocument = cmisRepository.AddCMIS_Document(centerFolders.PicturesFolder, cmisDocumentId, fileItemPicture);
		CMISDocumentDBUtils.AddCMISDocumentFromCMISDocument(conn, centerRequest.UserId, cmisDocument);

		centerRequest.Pictures_CMISDocuments.add(cmisDocument);
	    }
	}

	// Adds Floormap file
	if (centerRequest.Floormaps != null)
	{
	    FileItem fileItemFloormap = null;
	    centerRequest.Floormaps_CMISDocuments = new ArrayList<CMISDocument>();

	    for (i = 0; i < centerRequest.Floormaps.size(); i++)
	    {
		fileItemFloormap = centerRequest.Floormaps.get(i);
		cmisDocumentId = CMISDocumentDBUtils.GetNextCMISDocumentId(conn);
		cmisDocument = cmisRepository.AddCMIS_Document(centerFolders.FloormapsFolder, cmisDocumentId, fileItemFloormap);
		CMISDocumentDBUtils.AddCMISDocumentFromCMISDocument(conn, centerRequest.UserId, cmisDocument);

		centerRequest.Floormaps_CMISDocuments.add(cmisDocument);
	    }
	}

	// Adds Other document file
	if (centerRequest.OtherDocuments != null)
	{
	    FileItem fileItemOtherDocument = null;
	    centerRequest.OtherDocuments_CMISDocuments = new ArrayList<CMISDocument>();

	    for (i = 0; i < centerRequest.OtherDocuments.size(); i++)
	    {
		fileItemOtherDocument = centerRequest.OtherDocuments.get(i);
		cmisDocumentId = CMISDocumentDBUtils.GetNextCMISDocumentId(conn);
		cmisDocument = cmisRepository.AddCMIS_Document(centerFolders.OtherDocumentsFolder, cmisDocumentId, fileItemOtherDocument);
		CMISDocumentDBUtils.AddCMISDocumentFromCMISDocument(conn, centerRequest.UserId, cmisDocument);

		centerRequest.OtherDocuments_CMISDocuments.add(cmisDocument);
	    }
	}

	// Begins Transaction
	conn.setAutoCommit(false);

	// Insert Center
	if (requestType == RequestType.Add)
	{
	    insertCenter();
	}
	else
	{
	    updateCenter();
	}

	// Adds Contacts
	CentersDBUtils.DeleteContactsByCenterId(conn, centerRequest.CenterId);
	CentersDBUtils.AddContactFromList(conn, centerRequest.CenterId, centerRequest.Contacts, centerRequest.UserId);

	// Adds Floormaps
	if (centerRequest.Floormaps_CMISDocuments != null)
	{
	    CentersDBUtils.AddFloormapsFromList(conn, centerRequest.CenterId, centerRequest.UserId, centerRequest.Floormaps_CMISDocuments);
	}

	// Adds Pictures
	if (centerRequest.Pictures_CMISDocuments != null)
	{
	    CentersDBUtils.AddPicturesFromList(conn, centerRequest.CenterId, centerRequest.UserId, centerRequest.Pictures_CMISDocuments);
	}

	// Adds Other Documents
	if (centerRequest.OtherDocuments_CMISDocuments != null)
	{
	    CentersDBUtils.AddOtherDocumentsFromList(conn, centerRequest.CenterId, centerRequest.UserId,
	                                             centerRequest.OtherDocuments_CMISDocuments);
	}

	// Delete Introduction CMIS Document record
	if (centerRequest.RemoveIntroductionVideo_CMISDocument != null)
	{
	    CMISDocumentDBUtils.DeleteCMIS_Document_DB(conn, centerRequest.RemoveIntroductionVideo_CMISDocument.Id, centerRequest.UserId);
	}

	// Removes Pictures record
	if (centerRequest.RemovePicturesFiles != null)
	{
	    for (i = 0; i < centerRequest.RemovePicturesFiles.size(); i++)
	    {
		CMISDocumentDBUtils.DeleteCMIS_Document_DB(conn, centerRequest.RemovePicturesFiles.get(i).CMISDocument.Id,
		                                           centerRequest.UserId);
		CentersDBUtils.DeletePictureById(conn, centerRequest.RemovePicturesFiles.get(i).Id);
	    }
	}

	// Remove Floormaps record
	if (centerRequest.RemoveFloormapsFiles != null)
	{
	    for (i = 0; i < centerRequest.RemoveFloormapsFiles.size(); i++)
	    {
		CMISDocumentDBUtils.DeleteCMIS_Document_DB(conn, centerRequest.RemoveFloormapsFiles.get(i).CMISDocument.Id,
		                                           centerRequest.UserId);
		CentersDBUtils.DeleteFloormapById(conn, centerRequest.RemoveFloormapsFiles.get(i).Id);
	    }
	}

	// Remove Other Documents record
	if (centerRequest.RemoveOtherDocumentsFiles != null)
	{
	    for (i = 0; i < centerRequest.RemoveOtherDocumentsFiles.size(); i++)
	    {
		CMISDocumentDBUtils.DeleteCMIS_Document_DB(conn, centerRequest.RemoveOtherDocumentsFiles.get(i).CMISDocument.Id,
		                                           centerRequest.UserId);
		CentersDBUtils.DeleteOtherDocumentById(conn, centerRequest.RemoveOtherDocumentsFiles.get(i).Id);
	    }
	}

	conn.commit();
	conn.setAutoCommit(true);

	// Deletes Files from Document Repository
	
	// Delete Introduction Video file
	if (centerRequest.RemoveIntroductionVideo_CMISDocument != null)
	{
	    cmisRepository.DeleteCMISDocument(centerRequest.RemoveIntroductionVideo_CMISDocument);
	}

	// Removes Pictures files
	if (centerRequest.RemovePicturesFiles != null)
	{
	    for (i = 0; i < centerRequest.RemovePicturesFiles.size(); i++)
	    {
		cmisRepository.DeleteCMISDocument(centerRequest.RemovePicturesFiles.get(i).CMISDocument);
	    }
	}

	// Remove Floormaps files
	if (centerRequest.RemoveFloormapsFiles != null)
	{
	    for (i = 0; i < centerRequest.RemoveFloormapsFiles.size(); i++)
	    {
		cmisRepository.DeleteCMISDocument(centerRequest.RemoveFloormapsFiles.get(i).CMISDocument);
	    }
	}

	// Remove Other Documents Files
	if (centerRequest.RemoveOtherDocumentsFiles != null)
	{
	    for (i = 0; i < centerRequest.RemoveOtherDocumentsFiles.size(); i++)
	    {
		cmisRepository.DeleteCMISDocument(centerRequest.RemoveOtherDocumentsFiles.get(i).CMISDocument);
	    }
	}
    }


    private SQLFieldsAndQueries getSQLFields_SQLValues_array()
    {
	List<String> sqlFields = new ArrayList<String>();
	List<String> sqlValues = new ArrayList<String>();

	sqlFields.add("Name");
	sqlValues.add("?"); // 1

	sqlFields.add("City");
	sqlValues.add("?"); // 2

	sqlFields.add("Country");
	sqlValues.add("?"); // 3

	sqlFields.add("Latitude");
	sqlValues.add("?"); // 4

	sqlFields.add("Longitude");
	sqlValues.add("?"); // 5

	sqlFields.add("Description");
	sqlValues.add("?"); // 6

	sqlFields.add("VirtualTourURL");
	sqlValues.add("?"); // 7

	sqlFields.add("BookVisitURL");
	sqlValues.add("?"); // 8

	sqlFields.add("MarkerColor");
	sqlValues.add("?"); // 9

	sqlFields.add("UpdatedOn");
	sqlValues.add("Now()");

	sqlFields.add("UpdatedBy");
	sqlValues.add("?"); // 10

	SQLFieldsAndQueries sqlFieldsAndQueries = new SQLFieldsAndQueries();

	sqlFieldsAndQueries.SQLFields = sqlFields;
	sqlFieldsAndQueries.SQLValues = sqlValues;

	return sqlFieldsAndQueries;
    }


    private PreparedStatement updateValuesToSQlFields(PreparedStatement pstmt)
            throws SQLException
    {
	pstmt.setNString(1, centerRequest.Name);
	pstmt.setNString(2, centerRequest.City);
	pstmt.setNString(3, centerRequest.Country);
	pstmt.setNString(4, centerRequest.Latitude);
	pstmt.setNString(5, centerRequest.Longitude);
	pstmt.setNString(6, centerRequest.Description);
	pstmt.setNString(7, centerRequest.VirtualTourURL);
	pstmt.setNString(8, centerRequest.BookVisitURL);
	pstmt.setNString(9, centerRequest.MarkerColor);
	pstmt.setNString(10, centerRequest.UserId);

	return pstmt;
    }


    private void insertCenter()
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	SQLFieldsAndQueries objSQLFieldsValues = getSQLFields_SQLValues_array();
	List<String> sqlFields = objSQLFieldsValues.SQLFields;
	List<String> sqlValues = objSQLFieldsValues.SQLValues;

	sqlFields.add("IntroductionVideo_CMIS_DocumentId");
	sqlValues.add("?"); // 11

	sqlFields.add("CreatedOn");
	sqlValues.add("Now()");

	sqlFields.add("CreatedBy");
	sqlValues.add("?"); // 12

	sqlFields.add("Id");
	sqlValues.add("?"); // 13

	sql = DBUtils.combineSQLInsertQuery(sqlFields, sqlValues, tblCenters);
	pstmt = conn.prepareStatement(sql);

	pstmt = updateValuesToSQlFields(pstmt);
	pstmt.setLong(11, centerRequest.IntroductionVideo_CMISDocument.Id);
	pstmt.setNString(12, centerRequest.UserId);
	pstmt.setLong(13, centerRequest.CenterId);

	pstmt.execute();
	pstmt.close();
    }


    private void updateCenter()
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	SQLFieldsAndQueries objSQLFieldsValues = getSQLFields_SQLValues_array();
	List<String> sqlFields = objSQLFieldsValues.SQLFields;
	List<String> sqlValues = objSQLFieldsValues.SQLValues;

	// Introduction Video
	if (centerRequest.IntroductionVideo_CMISDocument != null)
	{
	    sqlFields.add("IntroductionVideo_CMIS_DocumentId");
	    sqlValues.add("?"); // 11
	}

	String whereCondition = " where \"Id\" = ? "; // 12
	sql = DBUtils.combineSQLUpdateQuery(sqlFields, sqlValues, tblCenters, whereCondition);

	pstmt = conn.prepareStatement(sql);
	pstmt = updateValuesToSQlFields(pstmt);

	int colId = 10;

	// Introduction Video
	if (centerRequest.IntroductionVideo_CMISDocument != null)
	{
	    colId = colId + 1;
	    pstmt.setLong(colId, centerRequest.IntroductionVideo_CMISDocument.Id);
	}

	colId = colId + 1;
	pstmt.setLong(colId, centerRequest.CenterId);

	pstmt.execute();
	pstmt.close();
    }
}
