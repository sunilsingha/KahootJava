package centers;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import centers.classes.data.CenterData;
import centers.classes.response.CentersResponse;
import db_operations.CentersDBUtils;
import db_operations.DBUtils;
import utils.Utils;


/**
 * Servlet implementation class GetAllCenterDetailsServlet
 */
@WebServlet("/api/centers/get-all-center-details")
public class GetAllCenterDetailsServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetAllCenterDetailsServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// Connect to database
	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	// Get all Ids
	try
	{
	    List<Long> centerIds = CentersDBUtils.GetAllCenterIds(conn);
	    List<CentersResponse> centersDetails = new ArrayList<CentersResponse>();
	    CenterData centerData = new CenterData();
	    int i = 0;

	    for (; i < centerIds.size(); i++)
	    {
		centerData = CentersDBUtils.GetCenterById(conn, centerIds.get(i));

		centersDetails.add(new CentersResponse(centerData));
	    }

	    Utils.addSuccessResponseFromObject(response, centersDetails);
	    DBUtils.CloseConnection(conn);
	}
	catch (Exception e)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while retrieving center locations - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}
    }

}
