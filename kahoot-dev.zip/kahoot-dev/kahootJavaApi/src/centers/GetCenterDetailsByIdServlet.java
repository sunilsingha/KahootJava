package centers;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import centers.classes.data.CenterData;
import centers.classes.response.CentersResponse;
import db_operations.CentersDBUtils;
import db_operations.DBUtils;
import utils.Utils;
import validation.ValidateString;


/**
 * Servlet implementation class GetCentersServlet
 */
@WebServlet("/api/centers/get-center-details-byid")
public class GetCenterDetailsByIdServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetCenterDetailsByIdServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub
	String strCenterId = request.getParameter("id");

	if (strCenterId == null || strCenterId == "")
	{
	    Utils.addErrorResponse(response, "Provide 'id'.");
	    return;
	}

	// Validates Center Id
	ValidateString validateString = new ValidateString(response, true);
	validateString.Input = strCenterId;
	validateString.FieldName = "'id'";
	validateString.IsRequired = true;
	validateString.IsAllCharactersNumber = true;

	if (validateString.isValueStringToResponse() == false)
	{
	    return;
	}

	// Parses Center Id
	Long CenterId = Long.parseLong(strCenterId);

	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	try
	{
	    if (CentersDBUtils.isCenterIdExists(conn, CenterId) == false)
	    {
		Utils.addErrorResponse(response, "center Id " + strCenterId + " not found");
		DBUtils.CloseConnection(conn);
		return;
	    }

	    // Gets center details
	    CentersResponse centerResponse = null;
	    CenterData centerData = new CenterData();

	    centerData = CentersDBUtils.GetCenterById(conn, CenterId);
	    centerResponse = new CentersResponse(centerData);

	    Utils.addSuccessResponseFromObject(response, centerResponse);
	    DBUtils.CloseConnection(conn);
	}
	catch (Exception e)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while retrieving center details - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}
    }
}
