package centers;

import centers.classes.data.CenterData;
import centers.classes.response.CentersResponse;

import java.util.ArrayList;
import java.util.List;
import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db_operations.CentersDBUtils;
import db_operations.ContentDBUtils;
import db_operations.DBUtils;
import utils.Utils;
import validation.ValidateNumber;


/**
 * Servlet implementation class GetCentersLocationByContentIdServlet
 */
@WebServlet("/api/contents/get-centers-details-by-contentid")
public class GetCentersDetailsByContentIdServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetCentersDetailsByContentIdServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub

	String strContentId = request.getParameter("id");

	if (strContentId == null || strContentId == "")
	{
	    Utils.addErrorResponse(response, "Provide 'id'.");
	    return;
	}

	// Validates Content Id
	ValidateNumber validateNumber = new ValidateNumber(response, true);
	validateNumber.IsStringInput = true;
	validateNumber.StrInput = strContentId;
	validateNumber.FieldName = "'id'";
	validateNumber.IsRequired = true;
	validateNumber.IsAllCharactersNumber = true;
	validateNumber.IsLong = true;

	if (validateNumber.isValueNumericToResponse() == false)
	{
	    return;
	}

	// Parses Content Id
	long ContentId = Long.parseLong(strContentId);

	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	try
	{
	    if (ContentDBUtils.isContentExists(conn, ContentId) == false)
	    {
		Utils.addErrorResponse(response, "content Id " + strContentId + " not found");
		DBUtils.CloseConnection(conn);
		return;
	    }

	    List<Long> centerIds = ContentDBUtils.GetCenterIdsByContentId(conn, ContentId);
	    List<CentersResponse> centersResponses = new ArrayList<CentersResponse>();
	    CenterData centerData = null;
	    CentersResponse centersResponse = null;
	    int i = 0;

	    for (; i < centerIds.size(); i++)
	    {
		centerData = CentersDBUtils.GetCenterById(conn, centerIds.get(i));
		centersResponse = new CentersResponse(centerData);

		centersResponses.add(centersResponse);
	    }

	    Utils.addSuccessResponseFromObject(response, centersResponses);
	    DBUtils.CloseConnection(conn);
	}
	catch (Exception ex)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while retrieving data - " + ex.getMessage());
	    ex.printStackTrace();
	    return;
	}
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub
	doGet(request, response);
    }

}
