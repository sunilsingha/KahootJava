package centers.classes.data;

import java.util.List;

import cmis_operations.classes.CenterFolders;
import cmis_operations.classes.CMISDocument;


public class CenterData
{
    public long			CenterId;
    public String		Name;
    public String		City;
    public String		Country;
    public String		Latitude;
    public String		Longitude;
    public String		Description;
    public String		VirtualTourURL;
    public String		BookVisitURL;
    public String		MarkerColor;
    public long			IntroductionVideo_CMIS_DocumentId;
    public List<String>		Contacts;
    public List<CenterDataFile>	Floormaps;
    public List<CenterDataFile>	Pictures;
    public List<CenterDataFile>	OtherDocuments;

    public CMISDocument	 IntroductionVideo_CMISDocument;
    public CenterFolders CenterFolders;
}
