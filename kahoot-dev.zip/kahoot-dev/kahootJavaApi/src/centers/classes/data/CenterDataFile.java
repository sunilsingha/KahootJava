package centers.classes.data;

import cmis_operations.classes.CMISDocument;


public class CenterDataFile
{
    public long		Id;
    public CMISDocument	CMISDocument;
}
