package centers.classes.request;

import java.util.List;
import org.apache.commons.fileupload.FileItem;

import centers.classes.data.CenterDataFile;
import cmis_operations.classes.CMISDocument;


public class CenterRequest
{
    public String	  Name;
    public String	  City;
    public String	  Country;
    public String	  Latitude;
    public String	  Longitude;
    public String	  Description;
    public String	  VirtualTourURL;
    public String	  BookVisitURL;
    public String	  MarkerColor;
    public List<String>	  Contacts;
    public FileItem	  IntroductionVideoFile;
    public List<FileItem> Pictures;
    public List<FileItem> Floormaps;
    public List<FileItem> OtherDocuments;
    public List<String>	  strRemovePicturesByIds;	// For update
    public List<String>	  strRemoveFloormapsByIds;	// For update
    public List<String>	  strRemoveOtherDocumentsByIds;	// For update
    public String	  strCenterId;			// For update or used for passing values

    // Assigned dynamically
    public long	  CenterId;
    public String UserId;

    public CMISDocument	      IntroductionVideo_CMISDocument;
    public List<CMISDocument> Pictures_CMISDocuments;
    public List<CMISDocument> Floormaps_CMISDocuments;
    public List<CMISDocument> OtherDocuments_CMISDocuments;

    public CMISDocument		RemoveIntroductionVideo_CMISDocument;
    public List<CenterDataFile>	RemovePicturesFiles;
    public List<CenterDataFile>	RemoveFloormapsFiles;
    public List<CenterDataFile>	RemoveOtherDocumentsFiles;
}
