package centers.classes.response;

public class CenterAddResponse
{
    public String message;
    public String contentId;
}
