package centers.classes.response;

import centers.classes.data.CenterData;


public class CenterLocationResponse
{
    public CenterLocationResponse(CenterData centerData)
    {
	this.CenterId = centerData.CenterId;
	this.Name = centerData.Name;
	this.City = centerData.City;
	this.Country = centerData.Country;
	this.Latitude = centerData.Latitude;
	this.Longitude = centerData.Longitude;
	this.MarkerColor = centerData.MarkerColor;
    }

    public Long	  CenterId;
    public String Name;
    public String City;
    public String Country;
    public String Latitude;
    public String Longitude;
    public String MarkerColor;
}
