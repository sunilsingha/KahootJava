package centers.classes.response;

public class CenterUpdateResponse
{
    public String message;
}
