package centers.classes.response;

import java.util.ArrayList;
import java.util.List;

import centers.classes.data.CenterData;


public class CentersResponse
{
    public CentersResponse(CenterData centerData)
    {
	this.CenterId = centerData.CenterId;
	this.Name = centerData.Name;
	this.City = centerData.City;
	this.Country = centerData.Country;
	this.Latitude = centerData.Latitude;
	this.Longitude = centerData.Longitude;
	this.Description = centerData.Description;
	this.VirtualTourURL = centerData.VirtualTourURL;
	this.BookVisitURL = centerData.BookVisitURL;
	this.MarkerColor = centerData.MarkerColor;
	this.IntroductionVideoPath = centerData.IntroductionVideo_CMISDocument.FilePath;
	this.visitorGuidePath = centerData.visitorGuide_CMISDocument.FilePath;
	this.Contacts = centerData.Contacts;

	int i = 0;
	CentersResponseFile centersResponseFile = null;

	if (centerData.Floormaps != null)
	{
	    Floormaps = new ArrayList<CentersResponseFile>();

	    for (i = 0; i < centerData.Floormaps.size(); i++)
	    {
		centersResponseFile = new CentersResponseFile();
		centersResponseFile.Id = centerData.Floormaps.get(i).Id;
		centersResponseFile.Path = centerData.Floormaps.get(i).CMISDocument.FilePath;
		this.Floormaps.add(centersResponseFile);
	    }
	}

	if (centerData.Pictures != null)
	{
	    Pictures = new ArrayList<CentersResponseFile>();

	    for (i = 0; i < centerData.Pictures.size(); i++)
	    {
		centersResponseFile = new CentersResponseFile();
		centersResponseFile.Id = centerData.Pictures.get(i).Id;
		centersResponseFile.Path = centerData.Pictures.get(i).CMISDocument.FilePath;
		this.Pictures.add(centersResponseFile);
	    }
	}

	if (centerData.OtherDocuments != null)
	{
	    OtherDocuments = new ArrayList<CentersResponseFile>();

	    for (i = 0; i < centerData.OtherDocuments.size(); i++)
	    {
		centersResponseFile = new CentersResponseFile();
		centersResponseFile.Id = centerData.OtherDocuments.get(i).Id;
		centersResponseFile.Path = centerData.OtherDocuments.get(i).CMISDocument.FilePath;
		this.OtherDocuments.add(centersResponseFile);
	    }
	}
    }

    public long			     CenterId;
    public String		     Name;
    public String		     City;
    public String		     Country;
    public String		     Latitude;
    public String		     Longitude;
    public String		     Description;
    public String		     VirtualTourURL;
    public String		     BookVisitURL;
    public String		     MarkerColor;
    public String		     IntroductionVideoPath;
    public String 			 visitorGuidePath;
    public List<String>		     Contacts;
    public List<CentersResponseFile> Floormaps;
    public List<CentersResponseFile> Pictures;
    public List<CentersResponseFile> OtherDocuments;
}
