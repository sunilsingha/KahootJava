package centers.classes.response;

public class CentersResponseFile
{
    public long	  Id;
    public String Path;
}
