package centers.classes.response;

import centers.classes.data.CenterData;


public class LocationResponse
{
    public LocationResponse(CenterData centerData)
    {
	this.CenterId = centerData.CenterId;
	this.LocationName = centerData.Name;
    }

    public long	  CenterId;
    public String LocationName;
}
