package cmis_operations;

import com.sap.ecm.api.EcmService;

import cmis_operations.classes.CMISDocument;

import java.io.IOException;
import java.io.InputStream;

import java.util.HashMap;
import java.util.Map;

import javax.naming.InitialContext;

import org.apache.chemistry.opencmis.client.api.CmisObject;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.client.api.Session;

import org.apache.chemistry.opencmis.commons.data.ContentStream;
import org.apache.chemistry.opencmis.commons.enums.VersioningState;
import org.apache.chemistry.opencmis.commons.exceptions.CmisNameConstraintViolationException;
import org.apache.chemistry.opencmis.commons.exceptions.CmisObjectNotFoundException;
import org.apache.commons.fileupload.FileItem;
import org.apache.chemistry.opencmis.commons.PropertyIds;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class CMISRepository
{
/* Development Document Repository instances By Raghu ********************/
    //private String repositoryName = "LeonardoContentRepositoryDevelopment";
    //private String secretKey	  = "lcrepositorydevelopment";
/* UAT Document Repository instances By Abhishek Kumar *******************/
	  //private String repositoryName = "LeonardoContentRepositoryUAT";
	  //private String secretKey	  = "lcrepositoryuat";
/* Production Document Repository instances By Raghu *********************/
	//private String repositoryName = "LeonardoContentRepository";
	//private String secretKey	  = "lcrepository";
/* Production Document Repository instances By Abhishek Kumar *********************/
	private String repositoryName = "LeonardoContent";
	private String secretKey	  = "leonardocontent";


    private static final Logger LOGGER = LoggerFactory.getLogger(CMISRepository.class);

    public Session session	     = null;
    public Boolean IsSessionLoggedIn = false;

    public Folder ContentsFolder = null;
    public Folder CentersFolder	 = null;
    public Folder StoriesFolder	 = null;

    private static final String CMIS_DOCUMENT_TYPE = "cmis:document";


    public void sessionLogin()
    {
	if (session != null)
	{
	    return;
	}

	LOGGER.info("Opening session with Document Repository.");

	try
	{
	    InitialContext ctx = new InitialContext();
	    String lookupName = "java:comp/env/EcmService";
	    EcmService ecmSvc = (EcmService) ctx.lookup(lookupName);

	    try
	    {
		// Below line is the JVM arguments
		// -DjndiCmisServiceName=TestRespository -DjndiCmisServiceKey=1234567890
		// repositoryName = System.getProperty("jndiCmisServiceName");
		// secretKey = System.getProperty("jndiCmisServiceKey");

		session = ecmSvc.connect(repositoryName, secretKey);
		IsSessionLoggedIn = true;
	    }
	    catch (CmisObjectNotFoundException e)
	    {
		LOGGER.error("Error occurred in connecting to repository. Repository not found. Method: sessionLogin. Class: CMISRepository.",
		             e);
		throw new Exception("Repository not found");
	    }
	}
	catch (Exception e)
	{
	    e.printStackTrace();
	    LOGGER.error("Error occurred while opening repositiory session. Method: sessionLogin. Class: CMISRepository.", e);
	    return;
	}

	// Create Folder Structure
	CreateLCRepositoryFolderStructure();

    }


    public void CreateLCRepositoryFolderStructure()
    {
	// This method creates default folder structure
	// +Contents
	// +Centers
	// +Stories

	// access the root folder from the repository
	Folder rootFolder = session.getRootFolder();

	// Create Contents Folder if not exists
	String strContents = "Contents";
	boolean is_Contents_FolderExists = checkFolderExistsInFolder(rootFolder, strContents);

	if (is_Contents_FolderExists == false)
	{
	    ContentsFolder = createFolderInFolder(rootFolder, strContents);
	}
	else
	{
	    ContentsFolder = getFolderInFolder(rootFolder, strContents);
	}

	// Create Centers Folder if not exists
	String strCenters = "Centers";
	boolean is_Centers_FolderExists = checkFolderExistsInFolder(rootFolder, strCenters);

	if (is_Centers_FolderExists == false)
	{
	    CentersFolder = createFolderInFolder(rootFolder, strCenters);
	}
	else
	{
	    CentersFolder = getFolderInFolder(rootFolder, strCenters);
	}

	// Create Stories Folder if not exists
	String strStories = "Stories";
	boolean is_Stories_FolderExists = checkFolderExistsInFolder(rootFolder, strStories);

	if (is_Stories_FolderExists == false)
	{
	    StoriesFolder = createFolderInFolder(rootFolder, strStories);
	}
	else
	{
	    StoriesFolder = getFolderInFolder(rootFolder, strStories);
	}
    }


    public Boolean checkFolderExistsInFolder(Folder parentFolder, String folderName)
    {
	Boolean blFound = false;

	for (CmisObject child : parentFolder.getChildren())
	{
	    if (child instanceof Folder)
	    {
		String strFolderName = child.getName().toLowerCase();
		String strLfn = folderName.toLowerCase();
		if (strFolderName.equals(strLfn))
		{
		    blFound = true;
		    break;
		}
	    }
	}

	return blFound;
    }


    public Folder getFolderInFolder(Folder parentFolder, String folderName)
    {
	Folder folder = null;

	for (CmisObject child : parentFolder.getChildren())
	{
	    if (child instanceof Folder)
	    {
		String strFolderName = child.getName().toLowerCase();
		String strLfn = folderName.toLowerCase();
		if (strFolderName.equals(strLfn))
		{
		    folder = (Folder) child;
		    break;
		}
	    }
	}

	return folder;
    }


    public Folder createFolderInFolder(Folder parentFolder, String folderName)
    {
	Folder folder = null;

	Map<String, String> newFolderProps = new HashMap<String, String>();
	newFolderProps.put(PropertyIds.OBJECT_TYPE_ID, "cmis:folder");
	newFolderProps.put(PropertyIds.NAME, folderName);

	try
	{
	    folder = parentFolder.createFolder(newFolderProps);
	}
	catch (CmisNameConstraintViolationException e)
	{
	    // Add Error for
	}

	return folder;
    }


    /**
     * creates document in the folder
     * 
     * @param parentFolder
     * @param fileName
     * @param inputStream
     * @param fileType
     * @return
     */
    public Document createDocument(Folder parentFolder, String fileName, InputStream inputStream, String fileType)
            throws CmisNameConstraintViolationException
    {
	// Creates document in a Folder
	Document document = null;

	Map<String, Object> properties = new HashMap<String, Object>();
	properties.put(PropertyIds.OBJECT_TYPE_ID, CMIS_DOCUMENT_TYPE);
	properties.put(PropertyIds.NAME, fileName);
	ContentStream contentStream = session.getObjectFactory().createContentStream(fileName, -1, fileType, inputStream);

	document = parentFolder.createDocument(properties, contentStream, VersioningState.NONE);

	return document;
    }


    public Document addDocumentfromFileItem(FileItem fileItem, Folder folder)
            throws IOException
    {
	String strFileName = fileItem.getName();

	if (strFileName.indexOf('\\') > -1)
	{
	    String fullPath = strFileName;
	    int index = fullPath.lastIndexOf("\\");
	    strFileName = fullPath.substring(index + 1);
	}

	InputStream inputStream = fileItem.getInputStream();
	String mimeType = fileItem.getContentType();

	return createDocument(folder, strFileName, inputStream, mimeType);
    }


    public void DeleteAllTheFilesInFolder(Folder folder)
    {
	for (CmisObject child : folder.getChildren())
	{
	    if (child instanceof Document)
	    {
		child.delete();
	    }
	}
    }


    public CMISDocument AddCMIS_Document(Folder parentFolder, Long CMIS_DocumentId, FileItem fileItem)
            throws IOException
    {
	CMISDocument cmisDocument = new CMISDocument();
	String strCMISDocumentId = Long.toString(CMIS_DocumentId);

	cmisDocument.IdFolder = createFolderInFolder(parentFolder, strCMISDocumentId);
	cmisDocument.File = addDocumentfromFileItem(fileItem, cmisDocument.IdFolder);

	cmisDocument.Id = CMIS_DocumentId;
	cmisDocument.FileName = fileItem.getName();
	cmisDocument.FileSize = fileItem.getSize();
	cmisDocument.MimeType = fileItem.getContentType();
	cmisDocument.FilePath = cmisDocument.File.getPaths().get(0);
	cmisDocument.CMISObjectId = cmisDocument.File.getId();

	return cmisDocument;
    }


    public CMISDocument updateCMIS_DocumentbyDetails(Folder parentFolder, CMISDocument cmisDocument)
    {
	cmisDocument.IdFolder = getFolderInFolder(parentFolder, Long.toString(cmisDocument.Id));
	cmisDocument.File = (Document) session.getObjectByPath(cmisDocument.FilePath);

	return cmisDocument;
    }


    public void DeleteCMISDocument(CMISDocument cmisDocument)
    {
	cmisDocument.File.delete();
	cmisDocument.IdFolder.delete();
    }
}
