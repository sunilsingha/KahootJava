package cmis_operations;

import centers.classes.data.CenterData;
import cmis_operations.classes.CenterFolders;


public class CenterCMISRepository
{
    private CMISRepository _cmisRepository;

    private static final String	FolderNameIntroductionVideo = "Introduction Video";
    
    private static final String	FolderNamePictures	    = "Pictures";
    private static final String	FolderNameFloormaps	    = "Floormaps";
    private static final String	FolderNameOtherDocuments    = "Other Documents";


    public CenterCMISRepository(CMISRepository cmisRepository)
    {
	_cmisRepository = cmisRepository;
    }


    public CenterFolders CreateFolderStructure(String CenterId)
    {
	CenterFolders centerFolders = new CenterFolders();

	// Creates Id folder
	centerFolders.Center = _cmisRepository.createFolderInFolder(_cmisRepository.CentersFolder, CenterId);

	centerFolders.IntroductionVideoFolder = _cmisRepository.createFolderInFolder(centerFolders.Center, FolderNameIntroductionVideo);
	centerFolders.PicturesFolder = _cmisRepository.createFolderInFolder(centerFolders.Center, FolderNamePictures);
	centerFolders.FloormapsFolder = _cmisRepository.createFolderInFolder(centerFolders.Center, FolderNameFloormaps);
	centerFolders.OtherDocumentsFolder = _cmisRepository.createFolderInFolder(centerFolders.Center, FolderNameOtherDocuments);

	return centerFolders;
    }


    public CenterFolders GetCenterFolders(String CenterId)
    {
	CenterFolders centerFolders = new CenterFolders();

	// Gets Id folder
	centerFolders.Center = _cmisRepository.getFolderInFolder(_cmisRepository.CentersFolder, CenterId);

	centerFolders.IntroductionVideoFolder = _cmisRepository.getFolderInFolder(centerFolders.Center, FolderNameIntroductionVideo);
	centerFolders.PicturesFolder = _cmisRepository.getFolderInFolder(centerFolders.Center, FolderNamePictures);
	centerFolders.FloormapsFolder = _cmisRepository.getFolderInFolder(centerFolders.Center, FolderNameFloormaps);
	centerFolders.OtherDocumentsFolder = _cmisRepository.getFolderInFolder(centerFolders.Center, FolderNameOtherDocuments);

	return centerFolders;
    }


    public CenterData UpdateCenterDocuments(CenterData centerData)
    {
	// Find Introduction Video File
	centerData.IntroductionVideo_CMISDocument = _cmisRepository.updateCMIS_DocumentbyDetails(centerData.CenterFolders.IntroductionVideoFolder,
	                                                                                         centerData.IntroductionVideo_CMISDocument);

	// Find Picture files
	int i = 0;
	for (i = 0; i < centerData.Pictures.size(); i++)
	{
	    centerData.Pictures.get(i).CMISDocument = _cmisRepository.updateCMIS_DocumentbyDetails(centerData.CenterFolders.PicturesFolder,
	                                                                                           centerData.Pictures.get(i).CMISDocument);
	}

	// Find Floormap files
	for (i = 0; i < centerData.Floormaps.size(); i++)
	{
	    centerData.Floormaps.get(i).CMISDocument = _cmisRepository.updateCMIS_DocumentbyDetails(centerData.CenterFolders.FloormapsFolder,
	                                                                                            centerData.Floormaps.get(i).CMISDocument);
	}

	// Find Other Document files
	for (i = 0; i < centerData.OtherDocuments.size(); i++)
	{
	    centerData.OtherDocuments.get(i).CMISDocument = _cmisRepository.updateCMIS_DocumentbyDetails(centerData.CenterFolders.OtherDocumentsFolder,
	                                                                                                 centerData.OtherDocuments.get(i).CMISDocument);
	}

	return centerData;
    }
}
