package cmis_operations;

import cmis_operations.classes.ContentFolders;
import contents.classes.data.ContentData;


public class ContentCMISRepository
{
    private CMISRepository _cmisRepository;

    private static final String	FolderNameBannerImage	   = "Banner Image";
    private static final String	FolderNameThumbnailImage   = "Thumbnail Image";
    private static final String	FolderNameWalkthroughVideo = "Walkthrough Video";
    private static final String	FolderNameInRoleVideos	   = "In-Role Videos";
    private static final String	FolderNamePresenterGuide   = "Presenter Guide";
    private static final String	FolderNameSetupGuide	   = "Setup Guide";


    public ContentCMISRepository(CMISRepository cmisRepository)
    {
	_cmisRepository = cmisRepository;
    }


    public ContentFolders CreateFolderStructure(long ContentId)
    {
	ContentFolders contentFolders = new ContentFolders();
	String strContentId = Long.toString(ContentId);

	// Creates Id folder
	contentFolders.Content = _cmisRepository.createFolderInFolder(_cmisRepository.ContentsFolder, strContentId);

	contentFolders.BannerImageFolder = _cmisRepository.createFolderInFolder(contentFolders.Content, FolderNameBannerImage);
	contentFolders.thumbnailImageFolder = _cmisRepository.createFolderInFolder(contentFolders.Content, FolderNameThumbnailImage);
	contentFolders.WalkthroughVideoFolder = _cmisRepository.createFolderInFolder(contentFolders.Content, FolderNameWalkthroughVideo);
	contentFolders.InRoleVideosFolder = _cmisRepository.createFolderInFolder(contentFolders.Content, FolderNameInRoleVideos);
	contentFolders.PresenterGuideFolder = _cmisRepository.createFolderInFolder(contentFolders.Content, FolderNamePresenterGuide);
	contentFolders.SetupGuideFolder = _cmisRepository.createFolderInFolder(contentFolders.Content, FolderNameSetupGuide);

	return contentFolders;
    }


    public ContentFolders GetContentFolders(long ContentId)
    {
	ContentFolders contentFolders = new ContentFolders();
	String strContentId = Long.toString(ContentId);

	// Gets Id folder
	contentFolders.Content = _cmisRepository.getFolderInFolder(_cmisRepository.ContentsFolder, strContentId);

	contentFolders.BannerImageFolder = _cmisRepository.getFolderInFolder(contentFolders.Content, FolderNameBannerImage);
	contentFolders.thumbnailImageFolder = _cmisRepository.getFolderInFolder(contentFolders.Content, FolderNameThumbnailImage);
	contentFolders.WalkthroughVideoFolder = _cmisRepository.getFolderInFolder(contentFolders.Content, FolderNameWalkthroughVideo);
	contentFolders.InRoleVideosFolder = _cmisRepository.getFolderInFolder(contentFolders.Content, FolderNameInRoleVideos);
	contentFolders.PresenterGuideFolder = _cmisRepository.getFolderInFolder(contentFolders.Content, FolderNamePresenterGuide);
	contentFolders.SetupGuideFolder = _cmisRepository.getFolderInFolder(contentFolders.Content, FolderNameSetupGuide);

	return contentFolders;
    }


    public ContentData UpdateDocuments(ContentData contentData)
    {
	return contentData;
    }
}
