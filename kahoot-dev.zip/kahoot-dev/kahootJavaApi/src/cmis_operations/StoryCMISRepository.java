package cmis_operations;

import cmis_operations.classes.StoryFolders;
import stories.classes.data.StoryData;


public class StoryCMISRepository
{
    private CMISRepository _cmisRepository;

    private static final String FolderNameDocuments = "Documents";


    public StoryCMISRepository(CMISRepository cmisRepository)
    {
	_cmisRepository = cmisRepository;
    }


    public StoryFolders CreateFolderStructure(long StoryId)
    {
	StoryFolders storyFolders = new StoryFolders();
	String strStoryId = Long.toString(StoryId);

	// creates Id folder
	storyFolders.Story = _cmisRepository.createFolderInFolder(_cmisRepository.StoriesFolder, strStoryId);

	storyFolders.DocumentsFolder = _cmisRepository.createFolderInFolder(storyFolders.Story, FolderNameDocuments);

	return storyFolders;
    }


    public StoryFolders GetStoryFolders(long StoryId)
    {
	StoryFolders storyFolders = new StoryFolders();
	String strStoryId = Long.toString(StoryId);

	// Gets Id folder
	storyFolders.Story = _cmisRepository.getFolderInFolder(_cmisRepository.StoriesFolder, strStoryId);

	storyFolders.DocumentsFolder = _cmisRepository.getFolderInFolder(storyFolders.Story, FolderNameDocuments);

	return storyFolders;
    }


    public StoryData UpdateStoryDocuments(StoryData storyData)
    {
	// Find Documents
	int i = 0;
	for (i = 0; i < storyData.Documents.size(); i++)
	{
	    storyData.Documents.get(i).CMISDocument = _cmisRepository.updateCMIS_DocumentbyDetails(storyData.StoryFolders.DocumentsFolder,
	                                                                                           storyData.Documents.get(i).CMISDocument);
	}

	return storyData;
    }
}
