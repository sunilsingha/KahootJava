package cmis_operations.classes;

import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;


public class CMISDocument
{
    public Long	  Id;
    public String FileName;
    public String FilePath;
    public String CMISObjectId;
    public Long	  FileSize;
    public String MimeType;

    public Folder   IdFolder;
    public Document File;
}
