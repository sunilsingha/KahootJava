package cmis_operations.classes;

import java.util.List;

import org.apache.chemistry.opencmis.client.api.Folder;


public class CenterFolders
{
    public Folder Center;

    public Folder IntroductionVideoFolder;
    public Folder PicturesFolder;
    public Folder FloormapsFolder;
    public Folder OtherDocumentsFolder;

    public CMISDocument	      IntroductionVideoCMISDocument;
    public List<CMISDocument> PicturesCMISDocuments;
    public List<CMISDocument> FloormapsCMISDocuments;
    public List<CMISDocument> OtherDocumentsCMISDocuments;
}
