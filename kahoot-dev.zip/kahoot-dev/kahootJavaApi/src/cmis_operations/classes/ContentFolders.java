package cmis_operations.classes;

import java.util.List;

import org.apache.chemistry.opencmis.client.api.Folder;


public class ContentFolders
{
    public Folder Content;

    public Folder BannerImageFolder;
    public Folder thumbnailImageFolder;
    public Folder WalkthroughVideoFolder;
    public Folder SetupGuideFolder;
    public Folder PresenterGuideFolder;
    public Folder InRoleVideosFolder;

    public CMISDocument	      BannerImageCMISDocument;
    public CMISDocument		  thumbnailImageCMISDocument;
    public CMISDocument	      WalkthroughVideoCMISDocument;
    public CMISDocument	      SetupGuideCMISDocument;
    public CMISDocument	      PresenterGuideCMISDocument;
    public List<CMISDocument> InRoleVideoCMISDocuments;
}
