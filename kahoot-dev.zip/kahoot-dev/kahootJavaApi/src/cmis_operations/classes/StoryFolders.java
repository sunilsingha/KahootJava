package cmis_operations.classes;

import java.util.List;

import org.apache.chemistry.opencmis.client.api.Folder;


public class StoryFolders
{
    public Folder Story;

    public Folder DocumentsFolder;

    public List<CMISDocument> DocumentsCMISDocuments;
}
