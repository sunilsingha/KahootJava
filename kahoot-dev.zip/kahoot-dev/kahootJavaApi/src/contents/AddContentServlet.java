package contents;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cmis_operations.CMISRepository;
import cmis_operations.ContentCMISRepository;
import cmis_operations.classes.ContentFolders;
import contents.classes.response.ContentAddResponse;
import contents.utils.AddOrUpdateContentUtils;
import db_operations.ContentDBUtils;
import db_operations.DBUtils;
import utils.RequestHelper;
import utils.RequestType;
import utils.Utils;


/**
 * Servlet implementation class AddContentServlet
 */
@WebServlet("/api/contents/add-content")
public class AddContentServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddContentServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	String userId = new RequestHelper().getUserIdToResponse(response);
	if (userId == "")
	{
	    return;
	}

	// Connect to database
	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	// Reads Request Data and validates it
	AddOrUpdateContentUtils addOrUpdateContentUtils = new AddOrUpdateContentUtils(request, response, conn, RequestType.Add);
	boolean blValidRequestData = false;

	try
	{
	    blValidRequestData = addOrUpdateContentUtils.IsValidRequestData();
	}
	catch (Exception e)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while validating the fields - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	if (blValidRequestData == false)
	{
	    DBUtils.CloseConnection(conn);
	    return;
	}

	// Opens session in repository
	CMISRepository cmisRepository;

	try
	{
	    cmisRepository = new CMISRepository();
	    cmisRepository.sessionLogin();
	}
	catch (Exception e)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while connecting to CMIS repository - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	// Gets New Content Id
	try
	{
	    // Gets Next Sequence Id
	    addOrUpdateContentUtils.setContentId(ContentDBUtils.getNextContentId(conn));

	}
	catch (Exception e)
	{
	    cmisRepository.session.clear();
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while retrieving Sequence Id - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	// Creates Folder Structure in Document Repository
	ContentFolders contentFolders = null;
	ContentCMISRepository contentCMISRespository = new ContentCMISRepository(cmisRepository);
	try
	{
	    contentFolders = contentCMISRespository.CreateFolderStructure(addOrUpdateContentUtils.getContentId());
	}
	catch (Exception e)
	{
	    cmisRepository.session.clear();
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while createing folder structure - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	try
	{
	    addOrUpdateContentUtils.processUpdatingContent(cmisRepository, contentFolders);
	}
	catch (Exception e)
	{
	    cmisRepository.session.clear();
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while upading data and documents - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	// Closes connection and clears the session
	DBUtils.CloseConnection(conn);
	cmisRepository.session.clear();

	// Creates object to send response
	ContentAddResponse contentAddOrUpdateResponse = new ContentAddResponse();
	contentAddOrUpdateResponse.contentId = addOrUpdateContentUtils.getContentId();
	contentAddOrUpdateResponse.message = "New Content Added";

	// Sends the response back
	Utils.addSuccessResponseFromObject(response, contentAddOrUpdateResponse);
    }
}
