package contents;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

import contents.classes.request.ContentViewedRequest;
import db_operations.ContentDBUtils;
import db_operations.DBUtils;
import utils.Utils;
import validation.ValidateRequest;


/**
 * Servlet implementation class ContentViewed
 */
@WebServlet("/api/contents/content-viewed")
public class ContentViewedServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public ContentViewedServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub

	// checks content type
	if (ValidateRequest.IsJSONRequest(request, response) == false)
	{
	    return;
	}

	// reads request data
	StringBuffer jb = new StringBuffer();
	String line = null;
	try
	{
	    BufferedReader reader = request.getReader();
	    while ((line = reader.readLine()) != null)
		jb.append(line);
	}
	catch (Exception e)
	{
	    Utils.addErrorResponse(response, "Invalid request.");
	    e.printStackTrace();
	    return;
	}

	// Parses JSOn String to object
	ObjectMapper mapper = new ObjectMapper();
	ContentViewedRequest contentViewedRequest;

	// Parse JSON string to JSON object
	try
	{
	    String requestJson = jb.toString();
	    contentViewedRequest = mapper.readValue(requestJson, ContentViewedRequest.class);
	}
	catch (Exception e)
	{
	    Utils.addErrorResponse(response, "Invalid request.");
	    e.printStackTrace();
	    return;
	}

	if (contentViewedRequest.ContentId == 0)
	{
	    Utils.addErrorResponse(response, "Invalid request.");
	    return;
	}

	// Connects to database
	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	// Checks Content Id exists
	try
	{
	    // Checks content Id exists
	    if (ContentDBUtils.isContentExists(conn, contentViewedRequest.ContentId) == false)
	    {
		Utils.addErrorResponse(response, "Content Id " + Long.toString(contentViewedRequest.ContentId) + " not found.");
		DBUtils.CloseConnection(conn);
		return;
	    }

	    // Update Count in the database
	    ContentDBUtils.addViewCount(conn, contentViewedRequest.ContentId);
	    DBUtils.CloseConnection(conn);
	}
	catch (Exception e)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	Utils.addSuccessResponse(response, "Updated.");
    }
}
