package contents;

import java.util.ArrayList;
import java.util.List;
import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import contents.classes.data.ContentData;
import contents.classes.response.ContentsResponse;
import db_operations.ContentDBUtils;
import db_operations.DBUtils;
import db_operations.ParamDBUtils;
import utils.Utils;
import validation.ValidateString;


/**
 * Servlet implementation class GetAllContentsServlet
 */
@WebServlet("/api/contents/get-all-contents")
public class GetAllContentsServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetAllContentsServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub

	String strTitle = request.getParameter("title");
	String strStatus = request.getParameter("status");

	// Status
	if (strStatus != null)
	{
	    if (strStatus != "")
	    {
		strStatus = strStatus.trim();

		ValidateString validateString = new ValidateString(response, true);
		validateString.Input = strStatus;
		validateString.IsRequired = true;
		validateString.IsValueInCheckList = true;
		validateString.IsValueWillBeTrimmed = true;
		validateString.CheckList = ParamDBUtils.getStatuses();

		if (validateString.isValueStringToResponse() == false)
		{
		    return;
		}
	    }
	}

	// Connect to database
	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	try
	{
	    List<Long> contentIds = ContentDBUtils.GetContentIds(conn, strTitle, null, strStatus, null);
	    List<ContentsResponse> contentsResponseList = new ArrayList<ContentsResponse>();
	    ContentsResponse contentsResponse = null;
	    ContentData contentData = null;
	    int i = 0;

	    for (; i < contentIds.size(); i++)
	    {
		contentData = ContentDBUtils.GetContentByContentId(conn, contentIds.get(i));
		contentsResponse = new ContentsResponse(request, contentData);

		contentsResponseList.add(contentsResponse);
	    }

	    Utils.addSuccessResponseFromObject(response, contentsResponseList);

	}
	catch (Exception ex)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while retrieving data - " + ex.getMessage());
	    ex.printStackTrace();
	    return;
	}

	DBUtils.CloseConnection(conn);
    }
}
