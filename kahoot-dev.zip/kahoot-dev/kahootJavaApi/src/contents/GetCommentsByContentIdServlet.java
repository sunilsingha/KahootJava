package contents;

import java.util.ArrayList;
import java.util.List;
import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import contents.classes.data.ContentDataComment;
import contents.classes.response.ContentCommentResponse;
import db_operations.ContentDBUtils;
import db_operations.DBUtils;
import utils.Utils;
import validation.ValidateNumber;


/**
 * Servlet implementation class GetCommentsByContentIdServlet
 */
@WebServlet("/api/contents/get-comments-by-contentid")
public class GetCommentsByContentIdServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetCommentsByContentIdServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub

	String strContentId = request.getParameter("id");

	if (strContentId == null || strContentId == "")
	{
	    Utils.addErrorResponse(response, "Provide 'id'.");
	    return;
	}

	// Validates Content Id
	ValidateNumber validateNumber = new ValidateNumber(response, true);
	validateNumber.IsStringInput = true;
	validateNumber.StrInput = strContentId;
	validateNumber.FieldName = "'contentId'";
	validateNumber.IsRequired = true;
	validateNumber.IsAllCharactersNumber = true;
	validateNumber.IsLong = true;

	if (validateNumber.isValueNumericToResponse() == false)
	{
	    return;
	}

	// Parses Content Id
	long ContentId = Long.parseLong(strContentId);

	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	try
	{
	    if (ContentDBUtils.isContentExists(conn, ContentId) == false)
	    {
		Utils.addErrorResponse(response, "content Id " + strContentId + " not found");
		DBUtils.CloseConnection(conn);
		return;
	    }

	    List<ContentDataComment> contentDataComments = ContentDBUtils.GetCommentsByContentId(conn, ContentId);
	    int i = 0;

	    List<ContentCommentResponse> contentCommentsResponse = new ArrayList<ContentCommentResponse>();
	    ContentCommentResponse contentCommentResponse = null;

	    for (i = 0; i < contentDataComments.size(); i++)
	    {
		contentCommentResponse = new ContentCommentResponse(contentDataComments.get(i));
		contentCommentsResponse.add(contentCommentResponse);
	    }
	    Utils.addSuccessResponseFromObject(response, contentCommentsResponse);
	    DBUtils.CloseConnection(conn);
	}
	catch (Exception ex)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while retrieving data - " + ex.getMessage());
	    ex.printStackTrace();
	    return;
	}
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub
	doGet(request, response);
    }
}
