package contents;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import contents.classes.data.ContentDataRating;
import contents.classes.response.ContentRatingResponse;
import db_operations.ContentDBUtils;
import db_operations.DBUtils;
import utils.RequestHelper;
import utils.Utils;
import validation.ValidateNumber;


/**
 * Servlet implementation class GetContentRatingServlet
 */
@WebServlet("/api/contents/get-content-rating-by-user")
public class GetContentRatingByUserServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetContentRatingByUserServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub
	// Gets UserId
	String userId = new RequestHelper().getUserIdToResponse(response);
	if (userId == "")
	{
	    return;
	}

	// Gets ContentId
	String strContentId = request.getParameter("contentId");

	if (strContentId == null || strContentId == "")
	{
	    Utils.addErrorResponse(response, "Provide 'contentId'.");
	    return;
	}

	// Validates Content Id
	ValidateNumber validateNumber = new ValidateNumber(response, true);
	validateNumber.IsStringInput = true;
	validateNumber.StrInput = strContentId;
	validateNumber.FieldName = "'contentId'";
	validateNumber.IsRequired = true;
	validateNumber.IsAllCharactersNumber = true;
	validateNumber.IsLong = true;

	if (validateNumber.isValueNumericToResponse() == false)
	{
	    return;
	}

	// Parses Content Id
	long ContentId = Long.parseLong(strContentId);

	// Connect to database
	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	try
	{
	    if (ContentDBUtils.isContentExists(conn, ContentId) == false)
	    {
		Utils.addErrorResponse(response, "content Id " + strContentId + " not found");
		DBUtils.CloseConnection(conn);
		return;
	    }

	    ContentRatingResponse contentRatingResponse = null;
	    ContentDataRating contentDataRating = ContentDBUtils.GetContentRatingDetails(conn, ContentId, userId);

	    if (contentDataRating == null)
	    {
		contentRatingResponse = new ContentRatingResponse(userId);
	    }
	    else
	    {
		contentRatingResponse = new ContentRatingResponse(contentDataRating);
	    }

	    Utils.addSuccessResponseFromObject(response, contentRatingResponse);

	}
	catch (Exception ex)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while retrieving data - " + ex.getMessage());
	    ex.printStackTrace();
	    return;
	}

	DBUtils.CloseConnection(conn);

    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub
	doGet(request, response);
    }
}
