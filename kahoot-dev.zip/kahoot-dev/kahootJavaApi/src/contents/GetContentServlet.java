package contents;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import contents.classes.data.ContentData;
import contents.classes.response.ContentsResponse;
import db_operations.ContentDBUtils;
import db_operations.DBUtils;
import utils.Utils;
import validation.ValidateNumber;


/**
 * Servlet implementation class GetContentServlet
 */
@WebServlet("/api/contents/get-content-byid")
public class GetContentServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetContentServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {

	String strContentId = request.getParameter("id");

	if (strContentId == null || strContentId == "")
	{
	    Utils.addErrorResponse(response, "Provide 'id'.");
	    return;
	}

	// Validates Content Id
	ValidateNumber validateNumber = new ValidateNumber(response, true);
	validateNumber.IsStringInput = true;
	validateNumber.StrInput = strContentId;
	validateNumber.FieldName = "'id'";
	validateNumber.IsRequired = true;
	validateNumber.IsAllCharactersNumber = true;
	validateNumber.IsLong = true;

	if (validateNumber.isValueNumericToResponse() == false)
	{
	    return;
	}

	// Parses Content Id
	long ContentId = Long.parseLong(strContentId);

	Connection connection = null;
	connection = DBUtils.ConnectToDatabase(response);
	if (connection == null)
	{
	    return;
	}

	try
	{
	    if (ContentDBUtils.isContentExists(connection, ContentId) == false)
	    {
		Utils.addErrorResponse(response, "content Id " + strContentId + " not found");
		DBUtils.CloseConnection(connection);
		return;
	    }

	    ContentData contentData = ContentDBUtils.GetContentByContentId(connection, ContentId);
	    Utils.addSuccessResponseFromObject(response, new ContentsResponse(request, contentData));
	    DBUtils.CloseConnection(connection);
	}
	catch (Exception ex)
	{
	    DBUtils.CloseConnection(connection);
	    Utils.addErrorResponse(response, "Error occurred while retrieving data - " + ex.getMessage());
	    ex.printStackTrace();
	    return;
	}
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub
	doGet(request, response);
    }
}
