package contents;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import contents.classes.data.ContentData;
import contents.classes.response.ContentsByPagesResponse;
import contents.classes.response.ContentsResponse;
import db_operations.ContentDBUtils;
import db_operations.DBUtils;
import db_operations.ParamDBUtils;
import db_operations.utils.EnmContentSortByFields;
import utils.RequestHelper;
import utils.Utils;
import validation.ValidateNumber;
import validation.ValidateString;


/**
 * Servlet implementation class GetMyContentsByPages
 */
@WebServlet("/api/contents/get-my-contents-by-pages")
public class GetMyContentsByPagesServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetMyContentsByPagesServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub

	// Gets UserId
	String userId = new RequestHelper().getUserIdToResponse(response);
	if (userId == "")
	{
	    return;
	}

	// TODO Auto-generated method stub
	int pageSize = 20;
	int pageIndex = 1;

	// get request parameters
	String strPageIndex = request.getParameter("page_index");
	String strPageSize = request.getParameter("page_size");
	String strTitle = request.getParameter("title");
	String strStatus = request.getParameter("status");

	ValidateNumber validateNumber = new ValidateNumber(response, true);

	// checks for Page Index
	if (strPageIndex != null)
	{
	    if (strPageIndex != "")
	    {
		strPageIndex = strPageIndex.trim();

		validateNumber.IsStringInput = true;
		validateNumber.FieldName = "page_index";
		validateNumber.StrInput = strPageIndex;
		validateNumber.IsInteger = true;
		validateNumber.IsRequired = true;

		if (validateNumber.isValueNumericToResponse() == false)
		{
		    return;
		}

		pageIndex = Integer.parseInt(strPageIndex);
	    }
	}

	// checks for Page Size
	if (strPageSize != null)
	{
	    if (strPageSize != "")
	    {
		strPageSize = strPageSize.trim();

		validateNumber.IsStringInput = true;
		validateNumber.FieldName = "page_size";
		validateNumber.StrInput = strPageSize;
		validateNumber.IsInteger = true;
		validateNumber.IsRequired = true;

		if (validateNumber.isValueNumericToResponse() == false)
		{
		    return;
		}

		pageSize = Integer.parseInt(strPageSize);
	    }
	}

	// Status
	if (strStatus != null)
	{
	    if (strStatus != "")
	    {
		strStatus = strStatus.trim();

		ValidateString validateString = new ValidateString(response, true);
		validateString.Input = strStatus;
		validateString.IsRequired = true;
		validateString.IsValueInCheckList = true;
		validateString.IsValueWillBeTrimmed = true;
		validateString.CheckList = ParamDBUtils.getStatuses();

		if (validateString.isValueStringToResponse() == false)
		{
		    return;
		}
	    }
	}

	// Connect to database
	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	try
	{
	    List<Long> contentIds = ContentDBUtils.GetContentIds(conn, strTitle, null, strStatus, userId);

	    int total = contentIds.size();
	    int pageCount = 0;
	    double dblPageCount = 0;
	    if (total > 0)
	    {
		dblPageCount = (int) Math.floor(total / pageSize);

		if (total > (pageSize * dblPageCount))
		{
		    pageCount = (int) dblPageCount + 1;
		}
		else
		{
		    pageCount = (int) dblPageCount;
		}
	    }

	    contentIds = ContentDBUtils.GetContentIdsSortByPages(conn, contentIds, pageSize, (pageIndex - 1) * pageSize,
	                                                     EnmContentSortByFields.ContentId, true);

	    ContentsByPagesResponse contentsByPagesResponse = new ContentsByPagesResponse();
	    contentsByPagesResponse.PageCount = pageCount;
	    contentsByPagesResponse.PageSize = pageSize;
	    contentsByPagesResponse.PageIndex = pageIndex;
	    contentsByPagesResponse.Total = total;
	    contentsByPagesResponse.Contents = new ArrayList<ContentsResponse>();

	    ContentsResponse contentsResponse = null;
	    ContentData contentData = null;
	    int i = 0;

	    for (; i < contentIds.size(); i++)
	    {
		contentData = ContentDBUtils.GetContentByContentId(conn, contentIds.get(i));
		contentsResponse = new ContentsResponse(request, contentData);

		contentsByPagesResponse.Contents.add(contentsResponse);
	    }

	    Utils.addSuccessResponseFromObject(response, contentsByPagesResponse);

	}
	catch (Exception ex)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while retrieving data - " + ex.getMessage());
	    ex.printStackTrace();
	    return;
	}

	DBUtils.CloseConnection(conn);
    }
}
