package contents;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Connection;

import java.util.List;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

import contents.classes.request.ContentPublishCommentRequest;
import db_operations.ContentDBUtils;
import db_operations.DBUtils;
import utils.RequestHelper;
import utils.Utils;
import validation.ValidateString;
import validation.ValidateRequest;


/**
 * Servlet implementation class PublishContentServlet
 */
@WebServlet("/api/contents/publish-comment")
public class PublishCommentServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public PublishCommentServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub

	// Gets UserId
	String userId = new RequestHelper().getUserIdToResponse(response);
	if (userId == "")
	{
	    return;
	}

	// checks content type
	if (ValidateRequest.IsJSONRequest(request, response) == false)
	{
	    return;
	}

	// reads request data
	StringBuffer jb = new StringBuffer();
	String line = null;
	try
	{
	    BufferedReader reader = request.getReader();
	    while ((line = reader.readLine()) != null)
		jb.append(line);
	}
	catch (Exception e)
	{
	    Utils.addErrorResponse(response, "Invalid request.");
	    e.printStackTrace();
	    return;
	}

	// Parses JSOn String to object
	ObjectMapper mapper = new ObjectMapper();
	ContentPublishCommentRequest contentPublishCommentRequest;

	// Parse JSON string to JSON object
	try
	{
	    String requestJson = jb.toString();
	    contentPublishCommentRequest = mapper.readValue(requestJson, ContentPublishCommentRequest.class);
	}
	catch (Exception e)
	{
	    Utils.addErrorResponse(response, "Invalid request.");
	    e.printStackTrace();
	    return;
	}

	if (contentPublishCommentRequest.ContentId == 0)
	{
	    Utils.addErrorResponse(response, "Invalid request.");
	    return;
	}

	// Validates Rating
	ValidateString validateString = new ValidateString(response, true);
	validateString.FieldName = "'Comment'";
	validateString.Input = contentPublishCommentRequest.Comment;
	validateString.IsRequired = true;
	validateString.IsValueWillBeTrimmed = true;

	if (validateString.isValueStringToResponse() == false)
	{
	    return;
	}

	// Connects to database
	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	try
	{
	    // Checks content Id exists
	    if (ContentDBUtils.isContentExists(conn, contentPublishCommentRequest.ContentId) == false)
	    {
		Utils.addErrorResponse(response, "Content Id " + Long.toString(contentPublishCommentRequest.ContentId) + " not found.");
		DBUtils.CloseConnection(conn);
		return;
	    }

	    // Update rating in the database
	    List<String> comments = new ArrayList<String>();
	    comments.add(contentPublishCommentRequest.Comment);
	    ContentDBUtils.AddCommentFromList(conn, contentPublishCommentRequest.ContentId, comments, userId);
	    DBUtils.CloseConnection(conn);
	}
	catch (Exception e)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	Utils.addSuccessResponse(response, "Comment updated.");
    }

}
