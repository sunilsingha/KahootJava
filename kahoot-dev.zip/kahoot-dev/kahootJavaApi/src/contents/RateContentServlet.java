package contents;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

import contents.classes.data.ContentDataRating;
import contents.classes.request.ContentRateRequest;
import db_operations.ContentDBUtils;
import db_operations.DBUtils;
import utils.RequestHelper;
import utils.Utils;
import validation.ValidateNumber;
import validation.ValidateRequest;


/**
 * Servlet implementation class RateContentServlet
 */
@WebServlet("/api/conents/rate-content")
public class RateContentServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public RateContentServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub

	// checks content type
	if (ValidateRequest.IsJSONRequest(request, response) == false)
	{
	    return;
	}

	String userId = new RequestHelper().getUserIdToResponse(response);
	if (userId == "")
	{
	    return;
	}

	// reads request data
	StringBuffer jb = new StringBuffer();
	String line = null;
	try
	{
	    BufferedReader reader = request.getReader();
	    while ((line = reader.readLine()) != null)
		jb.append(line);
	}
	catch (Exception e)
	{
	    Utils.addErrorResponse(response, "Invalid request.");
	    e.printStackTrace();
	    return;
	}

	// Parses JSOn String to object
	ObjectMapper mapper = new ObjectMapper();
	ContentRateRequest contentRateRequest;

	// Parse JSON string to JSON object
	try
	{
	    String requestJson = jb.toString();
	    contentRateRequest = mapper.readValue(requestJson, ContentRateRequest.class);
	}
	catch (Exception e)
	{
	    Utils.addErrorResponse(response, "Invalid request.");
	    e.printStackTrace();
	    return;
	}

	if (contentRateRequest.ContentId == 0)
	{
	    Utils.addErrorResponse(response, "Invalid request.");
	    return;
	}

	// Validates Rating
	ValidateNumber validateNumber = new ValidateNumber(response, true);
	validateNumber.FieldName = "'Rating'";
	validateNumber.IntInput = contentRateRequest.Rating;
	validateNumber.IsRequired = true;
	validateNumber.HasMaxValue = true;
	validateNumber.HasMinValue = true;
	validateNumber.MinimumIntValue = 1;
	validateNumber.MaximumIntValue = 5;

	if (validateNumber.isValueNumericToResponse() == false)
	{
	    return;
	}

	// Connects to database
	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	// Checks Content Id exists
	try
	{
	    // Checks content Id exists
	    if (ContentDBUtils.isContentExists(conn, contentRateRequest.ContentId) == false)
	    {
		Utils.addErrorResponse(response, "Content Id " + Long.toString(contentRateRequest.ContentId) + " not found.");
		DBUtils.CloseConnection(conn);
		return;
	    }

	    ContentDataRating contentDataRating = ContentDBUtils.GetContentRatingDetails(conn, contentRateRequest.ContentId, userId);

	    if (contentDataRating == null)
	    {
		// Inserts rating in the database
		ContentDBUtils.addRating(conn, contentRateRequest.ContentId, contentRateRequest.Rating, userId);
	    }
	    else
	    {
		// Update rating in the database
		ContentDBUtils.updateRating(conn, contentRateRequest.ContentId, contentRateRequest.Rating, userId);
	    }

	    DBUtils.CloseConnection(conn);
	}
	catch (Exception e)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	Utils.addSuccessResponse(response, "Rating updated.");
    }
}
