package contents;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

import contents.classes.request.ContentSearchRequest;
import contents.utils.ContentSearchUtils;
import db_operations.DBUtils;
import utils.RequestHelper;
import utils.Utils;
import validation.ValidateRequest;


/**
 * Servlet implementation class SearchContentsServlet
 */
@WebServlet("/api/contents/search-contents")
public class SearchContentsServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchContentsServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// checks for UserId
	String userId = new RequestHelper().getUserIdToResponse(response);
	if (userId == "")
	{
	    return;
	}

	// checks content type
	if (ValidateRequest.IsJSONRequest(request, response) == false)
	{
	    return;
	}

	// reads request data
	StringBuffer jb = new StringBuffer();
	String line = null;
	try
	{
	    BufferedReader reader = request.getReader();
	    while ((line = reader.readLine()) != null)
		jb.append(line);
	}
	catch (Exception e)
	{
	    Utils.addErrorResponse(response, "Invalid request.");
	    e.printStackTrace();
	    return;
	}

	// Parses JSOn String to object
	ObjectMapper mapper = new ObjectMapper();
	ContentSearchRequest contentSearchRequest;

	// Parse JSON string to JSON object
	try
	{
	    String requestJson = jb.toString();
	    contentSearchRequest = mapper.readValue(requestJson, ContentSearchRequest.class);
	}
	catch (Exception e)
	{
	    Utils.addErrorResponse(response, "Invalid request.");
	    e.printStackTrace();
	    return;
	}

	// Connecting to database
	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	try
	{
	    ContentSearchUtils contentUtils = new ContentSearchUtils(request, response, conn, contentSearchRequest.ByPages,
	                                                             contentSearchRequest.IncludeStories);

	    // Asset Type
	    if (contentUtils.setAssetTypeIfValid(contentSearchRequest.AssetType, "'AssetType'") == false)
	    {
		DBUtils.CloseConnection(conn);
		return;
	    }

	    // Age
	    if (contentUtils.setAgeIfValid(contentSearchRequest.Age, "'Age'") == false)
	    {
		DBUtils.CloseConnection(conn);
		return;
	    }

	    // Industry
	    if (contentUtils.setIndustryIfValid(contentSearchRequest.Industry, "'Industry'") == false)
	    {
		DBUtils.CloseConnection(conn);
		return;
	    }

	    // Solution
	    if (contentUtils.setSolutionIfValid(contentSearchRequest.Solution, "'Solution'") == false)
	    {
		DBUtils.CloseConnection(conn);
		return;
	    }

	    // sizes
	    if (contentUtils.setSizesIfValid(contentSearchRequest.Sizes, "'Sizes'") == false)
	    {
		DBUtils.CloseConnection(conn);
		return;
	    }

	    // centerIds
	    if (contentUtils.setCenterIdsIfValid(contentSearchRequest.CenterIds, "'CenterIds'") == false)
	    {
		DBUtils.CloseConnection(conn);
		return;
	    }

	    // description
	    if (contentUtils.setDescriptionIfValid(contentSearchRequest.Description, "'Description'") == false)
	    {
		DBUtils.CloseConnection(conn);
		return;
	    }

	    // Sort By
	    if (contentUtils.setSortByIfValid(contentSearchRequest.SortBy, "'SortBy'") == false)
	    {
		DBUtils.CloseConnection(conn);
		return;
	    }

	    // Sort Order
	    if (contentUtils.setSortOrderIfValid(contentSearchRequest.SortOrder, "'SortOrder'") == false)
	    {
		DBUtils.CloseConnection(conn);
		return;
	    }

	    // Status
	    if (contentUtils.setStatusIfValid(contentSearchRequest.Status, "'Status'") == false)
	    {
		DBUtils.CloseConnection(conn);
		return;
	    }

	    // OwnerId
	    if (contentSearchRequest.MyContents)
	    {
		contentUtils.setOwnerId(userId);
	    }

	    if (contentSearchRequest.ByPages)
	    {
		if (contentSearchRequest.PageIndex > 0)
		{
		    if (contentUtils.setPageIndexIfValid(contentSearchRequest.PageIndex, "'PageIndex'") == false)
		    {
			DBUtils.CloseConnection(conn);
			return;
		    }
		}

		if (contentSearchRequest.PageSize > 0)
		{
		    if (contentUtils.setPageSizeIfValid(contentSearchRequest.PageSize, "'PageSize'") == false)
		    {
			DBUtils.CloseConnection(conn);
			return;
		    }
		}
	    }

	    contentUtils.updateResultToResponse();
	    DBUtils.CloseConnection(conn);
	}
	catch (Exception ex)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while retrieving data - " + ex.getMessage());
	    ex.printStackTrace();
	    return;

	}
    }
}
