package contents;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db_operations.ContentDBUtils;
import db_operations.DBUtils;
import utils.Utils;
import validation.ValidateString;


/**
 * Servlet implementation class ContentShowcaseLaunched
 */
@WebServlet("/api/content-showcase-launched")
public class ShowcaseLaunchedServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowcaseLaunchedServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub
	String strContentId = request.getParameter("c");

	if (strContentId == null || strContentId == "")
	{
	    Utils.addErrorResponse(response, "Provide 'c'.");
	    return;
	}

	// Validates Content Id
	ValidateString validateString = new ValidateString(response, true);
	validateString.Input = strContentId;
	validateString.FieldName = "'c'";
	validateString.IsRequired = true;
	validateString.IsAllCharactersNumber = true;

	if (validateString.isValueStringToResponse() == false)
	{
	    return;
	}

	// Parses Content Id
	long ContentId = Long.parseLong(strContentId);

	// Connects to database
	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	// Checks Content Id exists
	try
	{
	    // Checks content Id exists
	    if (ContentDBUtils.isContentExists(conn, ContentId) == false)
	    {
		Utils.addErrorResponse(response, "Content Id " + ContentId + " not found.");
		DBUtils.CloseConnection(conn);
		return;
	    }

	    // Update Count in the database
	    ContentDBUtils.addUsageCount(conn, ContentId);
	    DBUtils.CloseConnection(conn);
	}
	catch (Exception e)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	Utils.addSuccessResponse(response, "Updated.");
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub
	doGet(request, response);
    }
}
