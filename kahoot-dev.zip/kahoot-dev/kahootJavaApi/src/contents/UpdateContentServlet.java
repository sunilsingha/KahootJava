package contents;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cmis_operations.CMISRepository;
import cmis_operations.ContentCMISRepository;
import cmis_operations.classes.ContentFolders;
import contents.classes.response.ContentUpdateResponse;
import contents.utils.AddOrUpdateContentUtils;
import utils.RequestHelper;
import utils.RequestType;
import utils.Utils;
import db_operations.DBUtils;


/**
 * Servlet implementation class UpdateContent
 */
@WebServlet("/api/contents/update-content")
public class UpdateContentServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateContentServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub
	String userId = new RequestHelper().getUserIdToResponse(response);
	if (userId == "")
	{
	    return;
	}
	String xx = request.getParameter("ContentId");
	String yy = request.getAttribute("ContentId");
	// Connect to database
	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	// validating request
	AddOrUpdateContentUtils addOrUpdateContentUtils = new AddOrUpdateContentUtils(request, response, conn, RequestType.Update);
	boolean blValidRequestData = false;

	try
	{
	    blValidRequestData = addOrUpdateContentUtils.IsValidRequestData();
	}
	catch (Exception e)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while validating the fields.");
	    return;
	}

	if (blValidRequestData == false)
	{
	    return;
	}

	// Opens session in repository
	CMISRepository cmisRepository;

	try
	{
	    cmisRepository = new CMISRepository();
	    cmisRepository.sessionLogin();
	}
	catch (Exception e)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while connecting to CMIS repository - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	// Gets Folder Structure for Content in Document Repository
	ContentFolders contentFolders = null;
	ContentCMISRepository contentCMISRepository = new ContentCMISRepository(cmisRepository);

	try
	{
	    contentFolders = contentCMISRepository.GetContentFolders(addOrUpdateContentUtils.getContentId());
	}
	catch (Exception e)
	{
	    cmisRepository.session.clear();
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while getting folder structure - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	// updates files and documents in database and repository
	try
	{
	    addOrUpdateContentUtils.processUpdatingContent(cmisRepository, contentFolders);
	}
	catch (Exception e)
	{
	    cmisRepository.session.clear();
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while upading data and documents - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	// Closes connection
	DBUtils.CloseConnection(conn);
	cmisRepository.session.clear();

	// Send the response back
	ContentUpdateResponse contentUpdateResponse = new ContentUpdateResponse();
	contentUpdateResponse.message = "Content details updated.";
	Utils.addSuccessResponseFromObject(response, contentUpdateResponse);
    }
}
