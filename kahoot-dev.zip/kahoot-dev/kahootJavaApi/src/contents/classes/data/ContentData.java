package contents.classes.data;

import java.util.List;
import java.util.Date;

import cmis_operations.classes.CMISDocument;


public class ContentData
{
    public long	      ContentId;
    public String     Title;
    public String     Description;
    public List<Long> CenterIds;
    public String     Status;
    public Date	      ReleaseDate;
    public Date	      LatestUpdateDate;
    public String     LatestUpdateByUser;
    public String     OwnerId;
    public Date	      SubmittedOn;
    public Long	      BannerImage_CMIS_DocumentId;
    public Long       thumnailImage_CMIS_DocumentId;
    public Long	      WalkthroughVideo_CMIS_DocumentId;
    public Long	      SetupGuide_CMIS_DocumentId;
    public Long	      PresenterGuide_CMIS_DocumentId;
    public long	      ViewCount;
    public long	      UsageCount;
    public long	      CountRating;
    public double     AverageRating;
    public long	      Age;
    public long	      UsersCount;

    public List<String>	AssetTypes;
    public List<String>	Industries;
    public List<String>	Solutions;
    public List<String>	Sizes;
    public List<String>	Contacts;

    public CMISDocument			BannerImage_CMISDocument;
    public CMISDocument			thumnailImage_CMISDocument;
    public CMISDocument			WalkthroughVideo_CMISDocument;
    public CMISDocument			SetupGuide_CMISDocument;
    public CMISDocument			PresenterGuide_CMISDocument;
    public List<ContentDataInRoleVideo>	InRoleVideoDataList;
}
