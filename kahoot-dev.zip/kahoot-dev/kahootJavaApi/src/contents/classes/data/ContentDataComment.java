package contents.classes.data;

import java.sql.Timestamp;
import users.classes.data.UserData;


public class ContentDataComment
{
    public long	     ContentId;
    public Timestamp CommentedOn;
    public String    CommentedById;
    public String    Comment;

    public UserData CommentedBy;
}
