package contents.classes.data;

import cmis_operations.classes.CMISDocument;


public class ContentDataInRoleVideo
{
    public long		Id;
    public CMISDocument	CMISDocument;
    public long		CountRating;
    public double	AverageRating;
}
