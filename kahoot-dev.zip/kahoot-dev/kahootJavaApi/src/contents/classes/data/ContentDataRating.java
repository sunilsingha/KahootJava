package contents.classes.data;

import java.sql.Timestamp;

public class ContentDataRating
{
    public long ContentId;
    public Timestamp CreatedOn;
    public String CreatedBy;
    public int Rating;
}
