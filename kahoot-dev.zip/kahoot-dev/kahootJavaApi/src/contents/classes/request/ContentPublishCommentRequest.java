package contents.classes.request;

public class ContentPublishCommentRequest
{
    public long	  ContentId;
    public String Comment;
}
