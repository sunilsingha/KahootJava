package contents.classes.request;

public class ContentRateRequest
{
    public long	ContentId;
    public int	Rating;
}
