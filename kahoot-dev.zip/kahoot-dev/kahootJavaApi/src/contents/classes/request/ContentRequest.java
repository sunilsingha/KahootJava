package contents.classes.request;

import java.util.List;
import org.apache.commons.fileupload.FileItem;

import cmis_operations.classes.CMISDocument;
import contents.classes.data.ContentDataInRoleVideo;


public class ContentRequest
{
    // Retrieved from request
    public String	  Title;
    public String	  Description;
    public List<String>	  AssetTypes;
    public List<String>	  Industries;
    public List<String>	  Solutions;
    public List<String>	  Sizes;
    public List<String>	  Contacts;
    public List<String>	  MaintainenceContacts;
    public String	  strReleaseDate;
    public String	  strLatestUpdateDate;
    public FileItem	  BannerImageFile;
    public FileItem   thumbnailImageFile;
    public FileItem	  WalkthroughVideoFile;
    public FileItem	  SetupGuideFile;
    public FileItem	  PresenterGuideFile;
    public List<FileItem> InRoleVideoFiles;
    public List<String>	  strCenterIds;

    public String	strContentId;		    // For Update
    public List<String>	strRemoveInRoleVideosByIds; // For update

    // Values Will be assigned dynamically
    public long	      ContentId;
    public String     UserId;
    public List<Long> CenterIds;

    public CMISDocument	      BannerImage_CMISDocument;
    public CMISDocument		  thumbnailImage_CMISDocument;
    public CMISDocument	      WalkthroughVideo_CMISDocument;
    public CMISDocument	      SetupGuide_CMISDocument;
    public CMISDocument	      PresenterGuide_CMISDocument;
    public List<CMISDocument> InRoleVideos_CMISDocuments;

    public CMISDocument			RemoveBannerImage_CMISDocument;
    public CMISDocument			RemoveThumbnailImage_CMISDocument;
    public CMISDocument			RemoveWalkthroughVideo_CMISDocument;
    public CMISDocument			RemoveSetupGuide_CMISDocument;
    public CMISDocument			RemovePresenterGuide_CMISDocument;
    public List<ContentDataInRoleVideo>	RemoveInRoleVideos;

}
