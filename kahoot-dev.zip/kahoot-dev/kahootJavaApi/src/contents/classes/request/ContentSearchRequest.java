package contents.classes.request;

import java.util.List;


public class ContentSearchRequest
{
    public String AssetType;
    // public int Age;
    public String	Age;
    public String	Industry;
    public String	Solution;
    public List<String>	Sizes;
    public List<Long>	CenterIds;
    public String	Description;
    public String	SortBy;
    public String	SortOrder;
    public String	Status;
    public boolean	ByPages;
    public int		PageSize;
    public int		PageIndex;
    public boolean	MyContents;
    public boolean	IncludeStories;
}
