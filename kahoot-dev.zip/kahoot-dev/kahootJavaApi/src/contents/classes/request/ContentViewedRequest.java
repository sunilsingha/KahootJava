package contents.classes.request;

public class ContentViewedRequest
{
    public long ContentId;
}
