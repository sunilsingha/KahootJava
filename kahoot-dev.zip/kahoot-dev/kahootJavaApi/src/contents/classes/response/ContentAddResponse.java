package contents.classes.response;

public class ContentAddResponse
{
    public String message;
    public long contentId;
}
