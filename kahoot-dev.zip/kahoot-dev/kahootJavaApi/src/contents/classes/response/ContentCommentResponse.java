package contents.classes.response;

import java.time.format.DateTimeFormatter;

import contents.classes.data.ContentDataComment;
import users.classes.response.UsersDetailsResponse;


public class ContentCommentResponse
{
    public ContentCommentResponse(ContentDataComment contentDataComment)
    {
	this.Comment = contentDataComment.Comment;
	this.CommentedOn = DateTimeFormatter.ISO_INSTANT.format(contentDataComment.CommentedOn.toInstant());
	this.CommentedBy = new UsersDetailsResponse(contentDataComment.CommentedBy);
    }

    public String		Comment;
    public String		CommentedOn;
    public UsersDetailsResponse	CommentedBy;
}
