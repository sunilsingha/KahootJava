package contents.classes.response;

import java.time.format.DateTimeFormatter;

import contents.classes.data.ContentDataRating;


public class ContentRatingResponse
{
    public ContentRatingResponse(ContentDataRating contentDataRating)
    {
	this.UserId = contentDataRating.CreatedBy;
	this.RatingOn = DateTimeFormatter.ISO_INSTANT.format(contentDataRating.CreatedOn.toInstant());
	this.Rating = contentDataRating.Rating;
	this.IsRatingProvided = true;
    }


    public ContentRatingResponse(String userId)
    {
	this.UserId = userId;
	this.IsRatingProvided = false;
    }

    public String  UserId;
    public String  RatingOn;
    public int	   Rating;
    public boolean IsRatingProvided;
}
