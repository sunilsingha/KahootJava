package contents.classes.response;

public class ContentUpdateResponse
{
    public String message;
}
