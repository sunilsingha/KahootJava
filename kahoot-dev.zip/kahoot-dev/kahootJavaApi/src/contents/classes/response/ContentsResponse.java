package contents.classes.response;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import contents.classes.data.ContentData;


public class ContentsResponse
{
    public ContentsResponse(HttpServletRequest request, ContentData contentData)
    {
	this.ContentId = contentData.ContentId;
	this.Title = contentData.Title;
	this.Description = contentData.Description;
	this.CenterIds = contentData.CenterIds;
	this.Status = contentData.Status;
	this.ReleaseDate = contentData.ReleaseDate;
	this.LatestUpdateDate = contentData.LatestUpdateDate;
	this.OwnerId = contentData.OwnerId;
	this.SubmittedOn = contentData.SubmittedOn;

	if (contentData.BannerImage_CMISDocument != null)
	{
	    this.BannerImagePath = contentData.BannerImage_CMISDocument.FilePath;
	}
	if(contentData.thumbnailImage_CMISDocument != null)
	{
		this.thumbnailImagePath = contentData.thumbnailImage_CMISDocument.FilePath;
	}

	if (contentData.WalkthroughVideo_CMISDocument != null)
	{
	    this.WalkthroughVideoPath = contentData.WalkthroughVideo_CMISDocument.FilePath;
	}

	if (contentData.SetupGuide_CMISDocument != null)
	{
	    this.SetupGuidePath = contentData.SetupGuide_CMISDocument.FilePath;
	}

	if (contentData.PresenterGuide_CMISDocument != null)
	{
	    this.PresenterGuidePath = contentData.PresenterGuide_CMISDocument.FilePath;
	}

	this.ViewCount = contentData.ViewCount;
	this.UsageCount = contentData.UsageCount;
	this.CountRating = contentData.CountRating;
	this.AverageRating = contentData.AverageRating;
	this.Age = contentData.Age;
	this.UsersCount = contentData.UsersCount;

	String launchUrl = "";

	launchUrl += request.getScheme() + "://";
	launchUrl += request.getServerName();
	launchUrl += request.getContextPath();
	launchUrl += "/api/content-showcase-launched";
	launchUrl += "?c=" + ContentId;

	this.ShowcaseLaunchURL = launchUrl;
	this.Availability = this.CenterIds.size();

	this.AssetTypes = contentData.AssetTypes;
	this.Industries = contentData.Industries;
	this.Solutions = contentData.Solutions;
	this.Sizes = contentData.Sizes;
	this.Contacts = contentData.Contacts;
	this.MaintainenceContacts = contentData.MaintainenceContacts;
	this.InRoleVideos = new ArrayList<ContentsResponseInRoleVideo>();
	if (contentData.InRoleVideoDataList != null)
	{
	    int i = 0;
	    ContentsResponseInRoleVideo InRoleVideo = null;
	    for (; i < contentData.InRoleVideoDataList.size(); i++)
	    {
		InRoleVideo = new ContentsResponseInRoleVideo();
		InRoleVideo.Id = contentData.InRoleVideoDataList.get(i).Id;
		InRoleVideo.Path = contentData.InRoleVideoDataList.get(i).CMISDocument.FilePath;
		InRoleVideo.AverageRating = contentData.InRoleVideoDataList.get(i).AverageRating;
		InRoleVideo.CountRating = contentData.InRoleVideoDataList.get(i).CountRating;
		InRoleVideo.FileSize = contentData.InRoleVideoDataList.get(i).CMISDocument.FileSize;

		this.InRoleVideos.add(InRoleVideo);
	    }
	}
    }

    public long	      ContentId;
    public String     Title;
    public String     Description;
    public List<Long> CenterIds;
    public String     Status;
    public Date	      ReleaseDate;
    public Date	      LatestUpdateDate;
    public String     OwnerId;
    public Date	      SubmittedOn;
    public String     BannerImagePath;
    public String 	  thumbnailImagePath;
    public String     WalkthroughVideoPath;
    public String     SetupGuidePath;
    public String     PresenterGuidePath;
    public long	      ViewCount;
    public long	      UsageCount;
    public long	      CountRating;
    public double     AverageRating;
    public long	      Age;
    public long	      UsersCount;
    public String     ShowcaseLaunchURL;
    public int	      Availability;

    public List<String>			     AssetTypes;
    public List<String>			     Industries;
    public List<String>			     Solutions;
    public List<String>			     Sizes;
    public List<String>			     Contacts;
    public List<String>				 MaintainenceContacts;
    public List<ContentsResponseInRoleVideo> InRoleVideos;
}
