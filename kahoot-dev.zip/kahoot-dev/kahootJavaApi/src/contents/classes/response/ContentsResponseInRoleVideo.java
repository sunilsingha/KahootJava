package contents.classes.response;

public class ContentsResponseInRoleVideo
{
    public long	  Id;
    public String Path;
    public long	  CountRating;
    public double AverageRating;
    public long	  FileSize;
}
