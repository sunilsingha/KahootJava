package contents.classes.response;

public class ContentsStoriesByContentResponse
        extends ContentsStoriesResponse
{
    public ContentsStoriesByContentResponse()
    {
	type = "Content";
    }

    public ContentsResponse Content;
}
