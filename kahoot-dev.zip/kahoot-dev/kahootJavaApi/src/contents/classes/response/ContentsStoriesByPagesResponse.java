package contents.classes.response;

import java.util.List;


public class ContentsStoriesByPagesResponse
{
    public int				 PageCount;
    public int				 PageIndex;
    public int				 PageSize;
    public int				 Total;
    public List<ContentsStoriesResponse> Results;
}
