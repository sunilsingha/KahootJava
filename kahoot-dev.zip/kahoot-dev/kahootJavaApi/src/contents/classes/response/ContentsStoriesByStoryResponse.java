package contents.classes.response;

import stories.classes.response.StoriesResponse;


public class ContentsStoriesByStoryResponse
        extends ContentsStoriesResponse
{
    public ContentsStoriesByStoryResponse()
    {
	type = "Story";
    }

    public StoriesResponse Story;
}
