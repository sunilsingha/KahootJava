package contents.classes.response;

public abstract class ContentsStoriesResponse
{
    public String type;
}
