package contents.utils;

import cmis_operations.CMISRepository;
import cmis_operations.classes.CMISDocument;
import cmis_operations.classes.ContentFolders;
import contents.classes.data.ContentData;
import contents.classes.data.ContentDataInRoleVideo;
import contents.classes.request.ContentRequest;
import db_operations.ActionLogDBUtils;
import db_operations.CMISDocumentDBUtils;
import db_operations.CentersDBUtils;
import db_operations.ContentDBUtils;
import db_operations.DBUtils;
import db_operations.InRoleVideoDBUtils;
import db_operations.ParamDBUtils;
import db_operations.SQLFieldsAndQueries;
import db_operations.UserDBUtils;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import utils.Utils;
import utils.DateUtils;
import utils.RequestHelper;
import utils.RequestType;
import validation.ValidateDate;
import validation.ValidateFile;
import validation.ValidateNumber;
import validation.ValidateNumberArray;
import validation.ValidateString;
import validation.ValidateStringArray;
import validation.classes.EnumFieldType;
import validation.classes.FormField;
import validation.ValidateFileArray;
import validation.ValidateFormFields;


public class AddOrUpdateContentUtils
{

    private HttpServletRequest	request;
    private HttpServletResponse	response;
    private RequestType		requestType;
    private Connection		conn;
    private ContentRequest	contentRequest;
    
    private static final String tblContents = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblContents + "\"";


    public AddOrUpdateContentUtils(HttpServletRequest _httpServletRequest, HttpServletResponse _httpServletResponse, Connection _conn,
                                   RequestType _requestType)
    {
	request = _httpServletRequest;
	response = _httpServletResponse;
	requestType = _requestType;
	conn = _conn;
    }
    public void setContentId(long contentId)
    {
	contentRequest.ContentId = contentId;
    }
    public long getContentId()
    {
	return contentRequest.ContentId;
    }


    public boolean IsValidRequestData()
            throws IOException, SQLException
    {
	// process only if its MultiPart content
	if (!ServletFileUpload.isMultipartContent(request))
	{
	    Utils.addErrorResponse(response, "Invalid request");
	    return false;
	}

	contentRequest = new ContentRequest();
	contentRequest.UserId = (new RequestHelper().getUser()).getName();

	DiskFileItemFactory factory = new DiskFileItemFactory();
	// factory.setSizeThreshold(209715200);
	ServletFileUpload upload = new ServletFileUpload(factory);
	// upload.setFileSizeMax(209715200);

	ValidateFormFields validateFormFields = getValidateFormFieldsList();

	try
	{
	    List<FileItem> fileItems = upload.parseRequest(request);
	    Iterator<FileItem> iterator = fileItems.iterator();

	    while (iterator.hasNext())
	    {
		FileItem fileItem = (FileItem) iterator.next();
		if (fileItem.isFormField())
		{
		    addValuesToObject(fileItem);
		}
		else
		{
		    addFilesToObject(fileItem);
		}

		validateFormFields.updateRequestFieldCount(fileItem);
	    }
	}
	catch (Exception e)
	{
	    Utils.addErrorResponse(response, "Error occurred while reading request items - " + e.getMessage());
	    e.printStackTrace();
	    return false;
	}

	// Validates Form fields
	if (validateFormFields.IsValidToResponse() == false)
	{
	    return false;
	}

	// Creates objects for validations.
	ValidateString validateString = new ValidateString(response, true);
	ValidateStringArray validateStringArray = new ValidateStringArray(response, true);
	ValidateDate validateDate = new ValidateDate(response, true);
	ValidateNumber validateNumber = new ValidateNumber(response, true);
	ValidateNumberArray validateNumberArray = new ValidateNumberArray(response, true);
	ValidateFile validateFile = new ValidateFile(response, true);
	ValidateFileArray validateFileArray = new ValidateFileArray(response, true);

	// Checks Request Type is Update
	if (requestType == RequestType.Update)
	{
	    // checks for contentId field
	    validateNumber.Reset();
	    validateNumber.IsStringInput = true;
	    validateNumber.StrInput = contentRequest.strContentId;
	    validateNumber.FieldName = "'ContentId'";
	    validateNumber.IsRequired = true;
	    validateNumber.IsLong = true;
	    validateNumber.IsAllCharactersNumber = true;

	    if (validateNumber.isValueNumericToResponse() == false)
	    {
		return false;
	    }

	    contentRequest.ContentId = Long.parseLong(contentRequest.strContentId);

	    // check contentId exists
	    if (ContentDBUtils.isContentExists(conn, contentRequest.ContentId) == false)
	    {
		Utils.addErrorResponse(response, "Content Id " + contentRequest.ContentId + " not found.");
		return false;
	    }
	}
	else
	{
	    contentRequest.ContentId = 0;
	}

	// checks for sizes field
	validateStringArray.Reset();
	validateStringArray.Input = contentRequest.Sizes;
	validateStringArray.FieldName = "'Sizes'";
	validateStringArray.IsRequired = true;
	validateStringArray.CheckList = ParamDBUtils.getSizes();
	validateStringArray.IsValueInCheckList = true;
	validateStringArray.CheckDuplicates = true;

	if (validateStringArray.IsStringArrayToResponse() == false)
	{
	    return false;
	}

	// checks for Title field
	validateString.Reset();
	validateString.Input = contentRequest.Title;
	validateString.FieldName = "'Title'";
	validateString.IsRequired = true;
	validateString.IsValueWillBeTrimmed = true;
	validateString.HasMaximumLength = true;
	validateString.MaximumLength = 50;

	if (validateString.isValueStringToResponse() == false)
	{
	    return false;
	}

	// checks for description field
	validateString.Reset();
	validateString.Input = contentRequest.Description;
	validateString.FieldName = "'Description'";
	validateString.IsRequired = true;
	validateString.IsValueWillBeTrimmed = true;
	validateString.HasMaximumLength = true;
	validateString.MaximumLength = 5000;

	if (validateString.isValueStringToResponse() == false)
	{
	    return false;
	}

	// checks for CenterIds field
	validateNumberArray.Reset();
	validateNumberArray.IsStringInput = true;
	validateNumberArray.StringArrayInput = contentRequest.strCenterIds;
	validateNumberArray.FieldName = "'CenterIds'";
	validateNumberArray.IsRequired = true;
	validateNumberArray.HasMinimumItemsCount = true;
	validateNumberArray.MinimumItemsCount = 1;
	validateNumberArray.IsLong = true;
	validateNumberArray.IsAllCharactersNumber = true;
	validateNumberArray.CheckDuplicates = true;
	validateNumberArray.HasMinValue = true;
	validateNumberArray.MinimumLongValue = 1;

	if (validateNumberArray.IsNumberArrayToResponse() == false)
	{
	    return false;
	}

	List<String> messageList = new ArrayList<String>();
	int i = 0;
	long centerId;

	contentRequest.CenterIds = new ArrayList<Long>();
	for (i = 0; i < contentRequest.strCenterIds.size(); i++)
	{
	    // strRemoveId = contentRequest.strRemoveInRoleVideosByIds.get(i);
	    centerId = Long.parseLong(contentRequest.strCenterIds.get(i));

	    if (CentersDBUtils.isCenterIdExists(conn, centerId) == false)
	    {
		messageList.add("Item " + (i + 1) + " of Center Id " + centerId + " not found.");
	    }
	    else
	    {
		contentRequest.CenterIds.add(centerId);
	    }
	}

	if (messageList.size() > 0)
	{
	    Utils.addErrorListResponse(response, "Error in the field 'CenterIds'.", messageList);
	    return false;
	}

	// checks for contacts field
	validateStringArray.Reset();
	validateStringArray.Input = contentRequest.Contacts;
	validateStringArray.FieldName = "'Contacts'";
	validateStringArray.IsRequired = true;
	validateStringArray.CheckDuplicates = true;
	validateStringArray.IsEmail = true;
	validateStringArray.HasMaximumStringLength = true;
	validateStringArray.MaximumStringLength = 255;

	if (validateStringArray.IsStringArrayToResponse() == false)
	{
	    return false;
	}

	// checks for releaseDate field
	validateDate.Reset();
	validateDate.Input = contentRequest.strReleaseDate;
	validateDate.FieldName = "'ReleaseDate'";
	validateDate.IsRequired = true;
	validateDate.IsInputFormt_YYYY_MM_DD = true;

	if (validateDate.IsValueDateToResponse() == false)
	{
	    return false;
	}

	// checks for latestUpdateDate field
	validateDate.Reset();
	validateDate.Input = contentRequest.strLatestUpdateDate;
	validateDate.FieldName = "'LatestUpdateDate'";
	validateDate.IsRequired = true;
	validateDate.IsInputFormt_YYYY_MM_DD = true;

	if (validateDate.IsValueDateToResponse() == false)
	{
	    return false;
	}

	// checks for assetTypes
	validateStringArray.Reset();
	validateStringArray.Input = contentRequest.AssetTypes;
	validateStringArray.FieldName = "'AssetTypes'";
	validateStringArray.IsRequired = true;
	validateStringArray.CheckDuplicates = true;
	validateStringArray.IsValueInCheckList = true;
	validateStringArray.CheckList = ParamDBUtils.getAssetTypes(conn);

	if (validateStringArray.IsStringArrayToResponse() == false)
	{
	    return false;
	}

	// checks for industries field
	validateStringArray.Reset();
	validateStringArray.Input = contentRequest.Industries;
	validateStringArray.FieldName = "'Industries'";
	validateStringArray.IsRequired = true;
	validateStringArray.CheckDuplicates = true;
	validateStringArray.IsValueInCheckList = true;
	validateStringArray.CheckList = ParamDBUtils.getIndustries(conn);

	if (validateStringArray.IsStringArrayToResponse() == false)
	{
	    return false;
	}

	// checks for Solutions field
	validateStringArray.Reset();
	validateStringArray.Input = contentRequest.Solutions;
	validateStringArray.FieldName = "'Solutions'";
	validateStringArray.IsRequired = true;
	validateStringArray.CheckDuplicates = true;
	validateStringArray.IsValueInCheckList = true;
	validateStringArray.CheckList = ParamDBUtils.getSolutions(conn);

	if (validateStringArray.IsStringArrayToResponse() == false)
	{
	    return false;
	}

	// Checks file item for Banner Image
	validateFile.Reset();
	validateFile.InputFile = contentRequest.BannerImageFile;
	validateFile.FieldName = "'BannerImage'";
	validateFile.IsRequired = requestType == RequestType.Add;
	validateFile.IsImage = true;

	if (validateFile.IsValidFileToResponse() == false)
	{
	    return false;
	}
	// Checks file item for Thumbnail Image
	validateFile.Reset();
	validateFile.InputFile = contentRequest.thumbnailImageFile;
	validateFile.FieldName = "'thumbnailImage'";
	validateFile.IsRequired = false;
	validateFile.IsImage = true;
	if (validateFile.IsValidFileToResponse() == false)
	{
	    return false;
	}
	// Checks file item for Walkthrough Video
	validateFile.Reset();
	validateFile.InputFile = contentRequest.WalkthroughVideoFile;
	validateFile.FieldName = "'WalkthroughVideo'";
	validateFile.IsRequired = requestType == RequestType.Add;
	validateFile.IsVideo = true;

	if (validateFile.IsValidFileToResponse() == false)
	{
	    return false;
	}

	// Checks file items for In Role Video
	validateFileArray.Reset();
	validateFileArray.InputFiles = contentRequest.InRoleVideoFiles;
	validateFileArray.FieldName = "'InRoleVideos'";
	validateFileArray.IsRequired = false;
	validateFileArray.IsVideo = true;

	if (validateFileArray.IsValidFileArrayToResponse() == false)
	{
	    return false;
	}

	// Checks file item for Presenter Guide
	validateFile.Reset();
	validateFile.InputFile = contentRequest.PresenterGuideFile;
	validateFile.FieldName = "'PresenterGuide'";
	validateFile.IsRequired = requestType == RequestType.Add;
	validateFile.IsDocument = true;

	if (validateFile.IsValidFileToResponse() == false)
	{
	    return false;
	}

	// Checks file item for Setup Guide
	validateFile.Reset();
	validateFile.InputFile = contentRequest.SetupGuideFile;
	validateFile.FieldName = "'SetupGuide'";
	validateFile.IsRequired = requestType == RequestType.Add;
	validateFile.IsDocument = true;

	if (validateFile.IsValidFileToResponse() == false)
	{
	    return false;
	}

	try
	{
	    // Check User Exists
	    if (UserDBUtils.IsUserExists(conn, contentRequest.UserId) == false)
	    {
		Utils.addErrorResponse(response, "User " + contentRequest.UserId + " not found.");
		return false;
	    }

	    // Check User is Content Creator or Administrator
	    if (UserDBUtils.IsUserContentCreatorOrAdministrator(conn, contentRequest.UserId) == false)
	    {
		Utils.addErrorResponse(response, "User " + contentRequest.UserId + " is not Content Creator/Administrator.");
		return false;
	    }
	}
	catch (Exception e)
	{
	    Utils.addErrorResponse(response, "Error occurred while checking user details - " + e.getMessage());
	    e.printStackTrace();
	    return false;
	}

	if (requestType == RequestType.Update)
	{
	   /* try
	    {
			// Checks content is Rejection
			if (ContentDBUtils.isContent_Rejected_Or_UpdateNeeded(conn, contentRequest.ContentId) == false)
			{
			    Utils.addErrorResponse(response, "You can update the content when content is 'rejected/update needed'.");
			    return false;
			}
			// check conentId Owner
			if (ContentDBUtils.isContentOwner(conn, contentRequest.ContentId, contentRequest.UserId) == false)
			{
			    Utils.addErrorResponse(response, "User '" + contentRequest.UserId + "' is not the owner of the content "
			            + contentRequest.ContentId + ".");
			    return false;
			}
	    }
	    catch (Exception e)
	    {
		Utils.addErrorResponse(response, "Error occurred while checking content details - " + e.getMessage());
		e.printStackTrace();
		return false;
	    }*/

	    String strRemoveId = "";
	    long lRemoveId = 0L;
	    long cmisDocumentId = 0L;

	    messageList = new ArrayList<String>();

	    // checks for inrole videos
	    if (contentRequest.strRemoveInRoleVideosByIds != null)
	    {
		validateNumberArray.Reset();
		validateNumberArray.IsStringInput = true;
		validateNumberArray.StringArrayInput = contentRequest.strRemoveInRoleVideosByIds;
		validateNumberArray.FieldName = "'RemoveInRoleVideosByIds'";
		validateNumberArray.IsLong = true;

		if (validateNumberArray.IsNumberArrayToResponse() == false)
		{
		    return false;
		}

		// Checks In Role Video exists
		contentRequest.RemoveInRoleVideos = new ArrayList<ContentDataInRoleVideo>();
		for (i = 0; i < contentRequest.strRemoveInRoleVideosByIds.size(); i++)
		{
		    strRemoveId = contentRequest.strRemoveInRoleVideosByIds.get(i);
		    lRemoveId = Long.parseLong(strRemoveId);

		    if (InRoleVideoDBUtils.isInRoleVideoExists(conn, contentRequest.ContentId, lRemoveId) == false)
		    {
			messageList.add("Item " + (i + 1) + " of In-Role Video Id " + lRemoveId + " doesn't exists.");
		    }
		    else
		    {
			cmisDocumentId = ContentDBUtils.GetCMISDocumentIdOfInRoleVideoId(conn, lRemoveId);

			ContentDataInRoleVideo contentDataInRoleVideo = new ContentDataInRoleVideo();
			contentDataInRoleVideo.Id = lRemoveId;
			contentDataInRoleVideo.CMISDocument = CMISDocumentDBUtils.GetCMISDocumentById(conn, cmisDocumentId);
			contentRequest.RemoveInRoleVideos.add(contentDataInRoleVideo);
		    }
		}

		if (messageList.size() > 0)
		{
		    Utils.addErrorListResponse(response, "Error in the field 'RemoveInRoleVideosByIds'.", messageList);
		    return false;
		}
	    }
	}

	// Checks the total bytes of In Role Video Ids
	if (contentRequest.InRoleVideoFiles != null)
	{
	    if (contentRequest.InRoleVideoFiles.size() > 0)
	    {
		long totalBytes = 0;

		if (requestType == RequestType.Update)
		{
		    List<Long> removeInRoleVideoIds = new ArrayList<Long>();
		    if (contentRequest.RemoveInRoleVideos != null)
		    {
			for (i = 0; i < contentRequest.RemoveInRoleVideos.size(); i++)
			{
			    removeInRoleVideoIds.add(contentRequest.RemoveInRoleVideos.get(i).Id);
			}
		    }

		    List<Long> cmisIds = InRoleVideoDBUtils.GetCMISDocumentIdsByContentIdNotInInRoleVideoIds(conn, contentRequest.ContentId,
		                                                                                             removeInRoleVideoIds);
		    totalBytes = CMISDocumentDBUtils.GetTotalBytesByIds(conn, cmisIds);
		}

		for (i = 0; i < contentRequest.InRoleVideoFiles.size(); i++)
		{
		    totalBytes += contentRequest.InRoleVideoFiles.get(i).getSize();
		}

		// Checks total bytes is greater than 200 MB
		if (totalBytes > (200 * 1024 * 1024))
		{
		    Utils.addErrorResponse(response, "Total In-Role Video file size for the content is more than 200 MB.");
		    return false;
		}
	    }
	}

	return true;
    }


    private ValidateFormFields getValidateFormFieldsList()
    {
	ValidateFormFields validateFormFields = new ValidateFormFields(response);

	validateFormFields.addFormField(new FormField("sizes[]", EnumFieldType.Text, true));
	validateFormFields.addFormField(new FormField("title", EnumFieldType.Text, false));
	validateFormFields.addFormField(new FormField("description", EnumFieldType.Text, false));

	return validateFormFields;
    }


    private void addValuesToObject(FileItem fileItem)
            throws Exception
    {
	String fieldName = fileItem.getFieldName().toLowerCase();
	String value = "";

	try
	{
	    value = fileItem.getString("UTF-8");
	}
	catch (UnsupportedEncodingException ex)
	{
	    throw new Exception("UTF-8 is unsupported encoding !?");
	}

	switch (fieldName)
	{
	    case "sizes[]":
		if (contentRequest.Sizes == null)
		{
		    contentRequest.Sizes = new ArrayList<String>();
		}
		contentRequest.Sizes.add(value);
		break;

	    case "title":
		contentRequest.Title = value;
		break;

	    case "description":
		contentRequest.Description = value;
		break;

	    case "centerids[]":
		if (contentRequest.strCenterIds == null)
		{
		    contentRequest.strCenterIds = new ArrayList<String>();
		}
		value = value.trim();
		contentRequest.strCenterIds.add(value);
		break;

	    case "contacts[]":
		if (contentRequest.Contacts == null)
		{
		    contentRequest.Contacts = new ArrayList<String>();
		}
		value = value.trim();
		contentRequest.Contacts.add(value);
		break;

	    case "releasedate":
		contentRequest.strReleaseDate = value;
		break;

	    case "latestupdatedate":
		contentRequest.strLatestUpdateDate = value;
		break;

	    case "contentid":
		contentRequest.strContentId = value;
		break;

	    case "assettypes[]":
		if (contentRequest.AssetTypes == null)
		{
		    contentRequest.AssetTypes = new ArrayList<String>();
		}
		contentRequest.AssetTypes.add(value);
		break;

	    case "industries[]":
		if (contentRequest.Industries == null)
		{
		    contentRequest.Industries = new ArrayList<String>();
		}
		contentRequest.Industries.add(value);
		break;

	    case "solutions[]":
		if (contentRequest.Solutions == null)
		{
		    contentRequest.Solutions = new ArrayList<String>();
		}
		contentRequest.Solutions.add(value);
		break;

	    case "removeinrolevideosbyids[]":
		if (contentRequest.strRemoveInRoleVideosByIds == null)
		{
		    contentRequest.strRemoveInRoleVideosByIds = new ArrayList<String>();
		}
		value = value.trim();
		contentRequest.strRemoveInRoleVideosByIds.add(value);
		break;
	}
    }


    private void addFilesToObject(FileItem fileItem)
    {
	String fieldName = fileItem.getFieldName().toLowerCase();

	switch (fieldName)
	{
	    case "bannerimage":
		contentRequest.BannerImageFile = fileItem;
		break;
		
	    case "hasthumbnailimagechanged" :
	    contentRequest.strhasThumbnailImageChanged = value;
	    break;
	    
	    case "walkthroughvideo":
		contentRequest.WalkthroughVideoFile = fileItem;
		break;

	    case "setupguide":
		contentRequest.SetupGuideFile = fileItem;
		break;

	    case "presenterguide":
		contentRequest.PresenterGuideFile = fileItem;
		break;

	    case "inrolevideos[]":
		if (contentRequest.InRoleVideoFiles == null)
		{
		    contentRequest.InRoleVideoFiles = new ArrayList<FileItem>();
		}
		contentRequest.InRoleVideoFiles.add(fileItem);
		break;
	}
    }


    public void processUpdatingContent(CMISRepository cmisRepository, ContentFolders contentFolders)
            throws IOException, SQLException

    {
	long cmisDocumentId = 0L;
	int i = 0;
	CMISDocument cmisDocument = null;
	ContentData contentData = null;

	// Gets all documents
	if (requestType == RequestType.Update)
	{
	    contentData = ContentDBUtils.GetContentByContentId(conn, contentRequest.ContentId);

	    if (contentRequest.BannerImageFile != null)
	    {
		if (contentData.BannerImage_CMISDocument != null)
		{
		    contentRequest.RemoveBannerImage_CMISDocument = contentData.BannerImage_CMISDocument;
		    contentRequest.RemoveBannerImage_CMISDocument = cmisRepository.updateCMIS_DocumentbyDetails(contentFolders.BannerImageFolder,
		                                                                                                contentRequest.RemoveBannerImage_CMISDocument);
		}
	    }

	    if (contentRequest.WalkthroughVideoFile != null)
	    {
		if (contentData.WalkthroughVideo_CMISDocument != null)
		{
		    contentRequest.RemoveWalkthroughVideo_CMISDocument = contentData.WalkthroughVideo_CMISDocument;
		    contentRequest.RemoveWalkthroughVideo_CMISDocument = cmisRepository.updateCMIS_DocumentbyDetails(contentFolders.WalkthroughVideoFolder,
		                                                                                                     contentRequest.RemoveWalkthroughVideo_CMISDocument);
		}
	    }

	    if (contentRequest.PresenterGuideFile != null)
	    {
		if (contentData.PresenterGuide_CMISDocument != null)
		{
		    contentRequest.RemovePresenterGuide_CMISDocument = contentData.PresenterGuide_CMISDocument;
		    contentRequest.RemovePresenterGuide_CMISDocument = cmisRepository.updateCMIS_DocumentbyDetails(contentFolders.PresenterGuideFolder,
		                                                                                                   contentRequest.RemovePresenterGuide_CMISDocument);
		}
	    }

	    if (contentRequest.SetupGuideFile != null)
	    {
		if (contentData.SetupGuide_CMISDocument != null)
		{
		    contentRequest.RemoveSetupGuide_CMISDocument = contentData.SetupGuide_CMISDocument;
		    contentRequest.RemoveSetupGuide_CMISDocument = cmisRepository.updateCMIS_DocumentbyDetails(contentFolders.SetupGuideFolder,
		                                                                                               contentRequest.RemoveSetupGuide_CMISDocument);
		}
	    }

	    if (contentRequest.RemoveInRoleVideos != null)
	    {
		for (i = 0; i < contentRequest.RemoveInRoleVideos.size(); i++)
		{
		    contentRequest.RemoveInRoleVideos.get(i).CMISDocument = cmisRepository.updateCMIS_DocumentbyDetails(contentFolders.InRoleVideosFolder,
		                                                                                                        contentRequest.RemoveInRoleVideos.get(i).CMISDocument);
		}
	    }
	}

	// Adds Banner Image File
	if (contentRequest.BannerImageFile != null)
	{
	    cmisDocumentId = CMISDocumentDBUtils.GetNextCMISDocumentId(conn);
	    contentRequest.BannerImage_CMISDocument = cmisRepository.AddCMIS_Document(contentFolders.BannerImageFolder, cmisDocumentId,
	                                                                              contentRequest.BannerImageFile);

	    CMISDocumentDBUtils.AddCMISDocumentFromCMISDocument(conn, contentRequest.UserId, contentRequest.BannerImage_CMISDocument);
	}
	//Add thumbnailImage File
		if (contentRequest.thumbnailImageFile != null)
		{
		    cmisDocumentId = CMISDocumentDBUtils.GetNextCMISDocumentId(conn);
		    contentRequest.BannerImage_CMISDocument = cmisRepository.AddCMIS_Document(contentFolders.thumbnailImageFolder, cmisDocumentId,
		                                                                              contentRequest.thumbnailImageFile);
		    CMISDocumentDBUtils.AddCMISDocumentFromCMISDocument(conn, contentRequest.UserId, contentRequest.thumbnailImage_CMISDocument);
		}

	// Adds Walkthrough Video file
	if (contentRequest.WalkthroughVideoFile != null)
	{
	    cmisDocumentId = CMISDocumentDBUtils.GetNextCMISDocumentId(conn);
	    contentRequest.WalkthroughVideo_CMISDocument = cmisRepository.AddCMIS_Document(contentFolders.WalkthroughVideoFolder,
	                                                                                   cmisDocumentId,
	                                                                                   contentRequest.WalkthroughVideoFile);

	    CMISDocumentDBUtils.AddCMISDocumentFromCMISDocument(conn, contentRequest.UserId, contentRequest.WalkthroughVideo_CMISDocument);
	}

	// Adds In-Role Video Files
	if (contentRequest.InRoleVideoFiles != null)
	{
	    FileItem fileItemInRoleVideo = null;
	    contentRequest.InRoleVideos_CMISDocuments = new ArrayList<CMISDocument>();

	    for (i = 0; i < contentRequest.InRoleVideoFiles.size(); i++)
	    {
		fileItemInRoleVideo = contentRequest.InRoleVideoFiles.get(i);
		cmisDocumentId = CMISDocumentDBUtils.GetNextCMISDocumentId(conn);
		cmisDocument = cmisRepository.AddCMIS_Document(contentFolders.InRoleVideosFolder, cmisDocumentId, fileItemInRoleVideo);
		CMISDocumentDBUtils.AddCMISDocumentFromCMISDocument(conn, contentRequest.UserId, cmisDocument);

		contentRequest.InRoleVideos_CMISDocuments.add(cmisDocument);
	    }
	}

	// Add Presenter Guide File
	if (contentRequest.PresenterGuideFile != null)
	{
	    cmisDocumentId = CMISDocumentDBUtils.GetNextCMISDocumentId(conn);
	    contentRequest.PresenterGuide_CMISDocument = cmisRepository.AddCMIS_Document(contentFolders.PresenterGuideFolder,
	                                                                                 cmisDocumentId, contentRequest.PresenterGuideFile);

	    CMISDocumentDBUtils.AddCMISDocumentFromCMISDocument(conn, contentRequest.UserId, contentRequest.PresenterGuide_CMISDocument);
	}

	// Adds Setup Guide File
	if (contentRequest.SetupGuideFile != null)
	{
	    cmisDocumentId = CMISDocumentDBUtils.GetNextCMISDocumentId(conn);
	    contentRequest.SetupGuide_CMISDocument = cmisRepository.AddCMIS_Document(contentFolders.SetupGuideFolder, cmisDocumentId,
	                                                                             contentRequest.SetupGuideFile);

	    CMISDocumentDBUtils.AddCMISDocumentFromCMISDocument(conn, contentRequest.UserId, contentRequest.SetupGuide_CMISDocument);
	}

	// Begins Transaction
	conn.setAutoCommit(false);

	// Insert content
	if (requestType == RequestType.Add)
	{
	    insertContent();
	}
	else if (requestType == RequestType.Update)
	{
	    updateContent();
	}

	// Asset types
	ContentDBUtils.DeleteAssetTypesByContentId(conn, contentRequest.ContentId);
	ContentDBUtils.AddAssetTypeFromList(conn, contentRequest.ContentId, contentRequest.AssetTypes, contentRequest.UserId);

	// Industries
	ContentDBUtils.DeleteIndustriesByContentId(conn, contentRequest.ContentId);
	ContentDBUtils.AddIndustryFromList(conn, contentRequest.ContentId, contentRequest.Industries, contentRequest.UserId);

	// Solutions
	ContentDBUtils.DeleteSolutionsByContentId(conn, contentRequest.ContentId);
	ContentDBUtils.AddSolutionsFromList(conn, contentRequest.ContentId, contentRequest.Solutions, contentRequest.UserId);

	// Sizes
	ContentDBUtils.DeleteSizesByContentId(conn, contentRequest.ContentId);
	ContentDBUtils.AddSizeFromList(conn, contentRequest.ContentId, contentRequest.Sizes, contentRequest.UserId);

	// Contacts
	ContentDBUtils.DeleteContactsByContentId(conn, contentRequest.ContentId);
	ContentDBUtils.AddContactFromList(conn, contentRequest.ContentId, contentRequest.Contacts, contentRequest.UserId);

	// Centers
	ContentDBUtils.DeleteMappingsContentandCenter(conn, contentRequest.ContentId);
	ContentDBUtils.AddCentersFromList(conn, contentRequest.ContentId, contentRequest.CenterIds, contentRequest.UserId);

	// Adds In-Role Videos
	if (contentRequest.InRoleVideos_CMISDocuments != null)
	{
	    InRoleVideoDBUtils.AddInRoleVideoFromList(conn, contentRequest.ContentId, contentRequest.InRoleVideos_CMISDocuments,
	                                              contentRequest.UserId);
	}

	// Inserts Action Log
	Long actionLogId = ActionLogDBUtils.getNextActionLogId(conn);
	ActionLogDBUtils.addActionLogforInReview(conn, actionLogId, contentRequest.ContentId, contentRequest.UserId);

	// Removes Banner Image record
	if (contentRequest.RemoveBannerImage_CMISDocument != null)
	{
	    CMISDocumentDBUtils.DeleteCMIS_Document_DB(conn, contentRequest.RemoveBannerImage_CMISDocument.Id, contentRequest.UserId);
	}

	// Removes Walkthrough Video record
	if (contentRequest.RemoveWalkthroughVideo_CMISDocument != null)
	{
	    CMISDocumentDBUtils.DeleteCMIS_Document_DB(conn, contentRequest.RemoveWalkthroughVideo_CMISDocument.Id, contentRequest.UserId);
	}

	// Removes In-Role Video record
	if (contentRequest.RemoveInRoleVideos != null)
	{
	    for (i = 0; i < contentRequest.RemoveInRoleVideos.size(); i++)
	    {
		CMISDocumentDBUtils.DeleteCMIS_Document_DB(conn, contentRequest.RemoveInRoleVideos.get(i).CMISDocument.Id,
		                                           contentRequest.UserId);
		ContentDBUtils.DeleteInRoleVideoById(conn, contentRequest.RemoveInRoleVideos.get(i).Id);
	    }
	}

	// Removes Presenter Guide record
	if (contentRequest.RemovePresenterGuide_CMISDocument != null)
	{
	    CMISDocumentDBUtils.DeleteCMIS_Document_DB(conn, contentRequest.RemovePresenterGuide_CMISDocument.Id, contentRequest.UserId);
	}

	// Removes Setup Guide record
	if (contentRequest.RemoveSetupGuide_CMISDocument != null)
	{
	    CMISDocumentDBUtils.DeleteCMIS_Document_DB(conn, contentRequest.RemoveSetupGuide_CMISDocument.Id, contentRequest.UserId);
	}

	// Commits Transaction
	conn.commit();
	conn.setAutoCommit(true);

	// Deletes Files from Document Repository

	// Delete Banner Image file
	if (contentRequest.RemoveBannerImage_CMISDocument != null)
	{
	    cmisRepository.DeleteCMISDocument(contentRequest.RemoveBannerImage_CMISDocument);
	}

	// Delete Walkthrough video file
	if (contentRequest.RemoveWalkthroughVideo_CMISDocument != null)
	{
	    cmisRepository.DeleteCMISDocument(contentRequest.RemoveWalkthroughVideo_CMISDocument);
	}

	// Delete In-Role Video file
	if (contentRequest.RemoveInRoleVideos != null)
	{
	    for (i = 0; i < contentRequest.RemoveInRoleVideos.size(); i++)
	    {
		cmisRepository.DeleteCMISDocument(contentRequest.RemoveInRoleVideos.get(i).CMISDocument);
	    }
	}

	// Delete Presenter Guide file
	if (contentRequest.RemovePresenterGuide_CMISDocument != null)
	{
	    cmisRepository.DeleteCMISDocument(contentRequest.RemovePresenterGuide_CMISDocument);
	}

	// Delete Setup Guide file
	if (contentRequest.RemoveSetupGuide_CMISDocument != null)
	{
	    cmisRepository.DeleteCMISDocument(contentRequest.RemoveSetupGuide_CMISDocument);
	}
    }


    private SQLFieldsAndQueries getSQLFields_SQLValues_array()
    {
	List<String> sqlFields = new ArrayList<String>();
	List<String> sqlValues = new ArrayList<String>();

	sqlFields.add("Title");
	sqlValues.add("?"); // 1

	sqlFields.add("Description");
	sqlValues.add("?"); // 2

	sqlFields.add("ReleaseDate");
	sqlValues.add("?"); // 3

	sqlFields.add("Status");
	sqlValues.add("?"); // 4

	sqlFields.add("LatestUpdateDate");
	sqlValues.add("?"); // 5

	sqlFields.add("LatestUpdatedByUser");
	sqlValues.add("?"); // 6

	sqlFields.add("UpdatedOn");
	sqlValues.add("Now()");

	sqlFields.add("UpdatedBy");
	sqlValues.add("?"); // 7

	sqlFields.add("SubmittedOn");
	sqlValues.add("Now()");

	SQLFieldsAndQueries sqlFieldsAndQueries = new SQLFieldsAndQueries();

	sqlFieldsAndQueries.SQLFields = sqlFields;
	sqlFieldsAndQueries.SQLValues = sqlValues;

	return sqlFieldsAndQueries;
    }


    private PreparedStatement updateValuesToSQlFields(PreparedStatement pstmt)
            throws SQLException
    {
	pstmt.setNString(1, contentRequest.Title);
	pstmt.setNString(2, contentRequest.Description);
	pstmt.setDate(3, new java.sql.Date(DateUtils.getDate_From_FormattedDate_YYYY_MM_DD(contentRequest.strReleaseDate).getTime()));
	pstmt.setNString(4, "In Review");
	pstmt.setDate(5, new java.sql.Date(DateUtils.getDate_From_FormattedDate_YYYY_MM_DD(contentRequest.strLatestUpdateDate).getTime()));
	pstmt.setNString(6, contentRequest.UserId);
	pstmt.setNString(7, contentRequest.UserId);

	return pstmt;
    }


    private void insertContent()
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	SQLFieldsAndQueries objSQLFieldsValues = getSQLFields_SQLValues_array();
	List<String> sqlFields = objSQLFieldsValues.SQLFields;
	List<String> sqlValues = objSQLFieldsValues.SQLValues;

	sqlFields.add("BannerImage_CMIS_DocumentId");
	sqlValues.add("?"); // 8

	sqlFields.add("WalkthroughVideo_CMIS_DocumentId");
	sqlValues.add("?"); // 9

	sqlFields.add("SetupGuide_CMIS_DocumentId");
	sqlValues.add("?"); // 10

	sqlFields.add("PresenterGuide_CMIS_DocumentId");
	sqlValues.add("?"); // 11

	sqlFields.add("OwnerId");
	sqlValues.add("?"); // 12

	sqlFields.add("CreatedOn");
	sqlValues.add("Now()");

	sqlFields.add("CreatedBy");
	sqlValues.add("?"); // 13

	sqlFields.add("ContentId");
	sqlValues.add("?"); // 14

	sqlFields.add("ViewCount");
	sqlValues.add("?"); // 15

	sqlFields.add("UsageCount");
	sqlValues.add("?"); // 16

	sql = DBUtils.combineSQLInsertQuery(sqlFields, sqlValues, tblContents);
	pstmt = conn.prepareStatement(sql);

	pstmt = updateValuesToSQlFields(pstmt);
	pstmt.setLong(8, contentRequest.BannerImage_CMISDocument.Id);
	pstmt.setLong(9, contentRequest.WalkthroughVideo_CMISDocument.Id);
	pstmt.setLong(10, contentRequest.SetupGuide_CMISDocument.Id);
	pstmt.setLong(11, contentRequest.PresenterGuide_CMISDocument.Id);
	pstmt.setNString(12, contentRequest.UserId);
	pstmt.setNString(13, contentRequest.UserId);
	pstmt.setLong(14, contentRequest.ContentId);
	pstmt.setLong(15, 0);
	pstmt.setLong(16, 0);

	pstmt.execute();
	pstmt.close();
    }


    private void updateContent()
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	SQLFieldsAndQueries objSQLFieldsValues = getSQLFields_SQLValues_array();
	List<String> sqlFields = objSQLFieldsValues.SQLFields;
	List<String> sqlValues = objSQLFieldsValues.SQLValues;

	// Banner Image
	if (contentRequest.BannerImage_CMISDocument != null)
	{
	    sqlFields.add("BannerImage_CMIS_DocumentId");
	    sqlValues.add("?"); // 8
	}

	// Walkthrough Video
	if (contentRequest.WalkthroughVideo_CMISDocument != null)
	{
	    sqlFields.add("WalkthroughVideo_CMIS_DocumentId");
	    sqlValues.add("?"); // 9
	}

	// Setup Guide
	if (contentRequest.SetupGuide_CMISDocument != null)
	{
	    sqlFields.add("SetupGuide_CMIS_DocumentId");
	    sqlValues.add("?"); // 10
	}
	// Presenter Guide
	if (contentRequest.PresenterGuide_CMISDocument != null)
	{
	    sqlFields.add("PresenterGuide_CMIS_DocumentId");
	    sqlValues.add("?"); // 11
	}

	String whereCondition = " where \"ContentId\" = ? "; // 13
	sql = DBUtils.combineSQLUpdateQuery(sqlFields, sqlValues, tblContents, whereCondition);

	pstmt = conn.prepareStatement(sql);
	pstmt = updateValuesToSQlFields(pstmt);

	int colId = 7;

	// Banner Image
	if (contentRequest.BannerImage_CMISDocument != null)
	{
	    colId = colId + 1;
	    pstmt.setLong(colId, contentRequest.BannerImage_CMISDocument.Id);
	}

	// Walkthrough Video
	if (contentRequest.WalkthroughVideo_CMISDocument != null)
	{
	    colId = colId + 1;
	    pstmt.setLong(colId, contentRequest.WalkthroughVideo_CMISDocument.Id);
	}

	// Setup Guide
	if (contentRequest.SetupGuide_CMISDocument != null)
	{
	    colId = colId + 1;
	    pstmt.setLong(colId, contentRequest.SetupGuide_CMISDocument.Id);
	}

	// Presenter Guide
	if (contentRequest.PresenterGuide_CMISDocument != null)
	{
	    colId = colId + 1;
	    pstmt.setLong(colId, contentRequest.PresenterGuide_CMISDocument.Id);
	}

	colId = colId + 1;
	pstmt.setLong(colId, contentRequest.ContentId);

	pstmt.execute();
	pstmt.close();
    }
}
