package contents.utils;

import db_operations.CentersDBUtils;
import db_operations.ContentDBUtils;
import db_operations.ParamDBUtils;
import db_operations.StoryDBUtils;
import db_operations.utils.EnmContentSortByFields;
import stories.classes.data.StoryData;
import stories.classes.response.StoriesResponse;

import java.util.ArrayList;
import java.util.List;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import contents.classes.data.ContentData;
import contents.classes.response.ContentsByPagesResponse;
import contents.classes.response.ContentsResponse;
import contents.classes.response.ContentsStoriesByContentResponse;
import contents.classes.response.ContentsStoriesByPagesResponse;
import contents.classes.response.ContentsStoriesByStoryResponse;
import contents.classes.response.ContentsStoriesResponse;
import utils.Utils;
import validation.ValidateNumber;
import validation.ValidateString;
import validation.ValidateStringArray;


public class ContentSearchUtils
{
    private HttpServletRequest	request;
    private HttpServletResponse	response;
    private Connection		conn;

    private String	 ownerId;
    private String	 title;
    private String	 status;
    private String	 assetType;
    private String	 industry;
    private String	 solution;
    private List<String> sizes;
    private String	 description;
    private List<Long>	 centerIds;

    private boolean isAgeProvided;
    private boolean isAgeDaysFrom;
    private int	    ageDaysFrom;
    private int	    ageDaysTo;

    private boolean		   isResponseByPages;
    private int			   pageIndex = 1;
    private int			   pageSize  = 20;
    private EnmContentSortByFields contentSortByFields;
    private boolean		   isAscending;
    private boolean		   includeStories;

    // Validation variables
    private ValidateString	validateString	    = null;
    private ValidateStringArray	validateStringArray = null;
    private ValidateNumber	validateNumber	    = null;


    public ContentSearchUtils(HttpServletRequest _request, HttpServletResponse _response, Connection _conn, boolean _isResponseByPages,
                              boolean _includeStories)
    {
	request = _request;
	response = _response;
	conn = _conn;
	isResponseByPages = _isResponseByPages;
	includeStories = _includeStories;

	setDefaultValues();
    }


    private void setDefaultValues()
    {
	ownerId = null;
	title = null;
	status = null;
	assetType = null;
	industry = null;
	solution = null;
	sizes = null;
	description = null;
	centerIds = null;
	contentSortByFields = EnmContentSortByFields.ContentId;
	isAscending = true;

	isAgeProvided = false;
	isAgeDaysFrom = false;
	ageDaysFrom = 0;
	ageDaysTo = 0;

	validateNumber = new ValidateNumber(response, true);
	validateString = new ValidateString(response, true);
	validateStringArray = new ValidateStringArray(response, true);
    }


    public void setOwnerId(String _ownerId)
    {
	ownerId = _ownerId;
    }


    public boolean setTitleIfValid(String _title, String fieldName)
    {
	if (_title != null)
	{
	    if (_title.trim() != "")
	    {
		validateString.Reset();
		validateString.FieldName = fieldName;
		validateString.Input = _title;
		validateString.HasMaximumLength = true;
		validateString.MaximumLength = 50;

		if (validateString.isValueStringToResponse() == false)
		{
		    return false;
		}

		this.title = _title.trim();
	    }
	}

	return true;
    }


    public boolean setStatusIfValid(String _status, String fieldName)
    {
	if (_status != null)
	{
	    _status = _status.trim();

	    if (_status.trim() != "")
	    {
		List<String> statusesCheckList = ParamDBUtils.getStatuses();

		validateString.Reset();
		validateString.FieldName = fieldName;
		validateString.Input = _status;
		validateString.CheckList = ParamDBUtils.getStatuses();
		validateString.IsValueInCheckList = true;

		if (validateString.isValueStringToResponse() == false)
		{
		    return false;
		}

		status = Utils.getStandardTextForSearchValue(_status, statusesCheckList);
	    }
	}

	return true;
    }


    public boolean setAssetTypeIfValid(String _assetType, String fieldName)
            throws SQLException
    {
	if (_assetType != null)
	{
	    _assetType = _assetType.trim();

	    if (_assetType != "")
	    {
		List<String> assetTypesCheckList = ParamDBUtils.getAssetTypes(conn);

		validateString.Reset();
		validateString.FieldName = fieldName;
		validateString.Input = _assetType;
		validateString.IsRequired = true;
		validateString.IsValueInCheckList = true;
		validateString.CheckList = assetTypesCheckList;

		if (validateString.isValueStringToResponse() == false)
		{
		    return false;
		}

		assetType = Utils.getStandardTextForSearchValue(_assetType, assetTypesCheckList);
	    }
	}

	return true;
    }


    public boolean setAgeIfValid(String _age, String fieldName)
            throws IOException
    {
	if (_age != null)
	{
	    _age = _age.trim();

	    if (_age != "")
	    {
		// checks for hyphen
		String[] strArr = _age.split("-");
		if (strArr.length != 2)
		{
		    Utils.addErrorResponse(response, "Value of " + fieldName + " is invalid");
		    return false;
		}

		// Trims for value
		strArr[0] = strArr[0].trim();
		strArr[1] = strArr[1].trim();

		if (strArr[0] == "" || strArr[1] == "")
		{
		    Utils.addErrorResponse(response, "Value of " + fieldName + " is invalid");
		    return false;
		}

		// Checks both values are number
		if (Utils.isAllCharactersareNumbers2(strArr[0]) == false || Utils.isAllCharactersareNumbers2(strArr[1]) == false)
		{
		    Utils.addErrorResponse(response, "Value of " + fieldName + " is invalid");
		    return false;
		}

		// parse both values
		int firstHalf = 0;
		int secondHalf = 0;
		int tmp = 0;

		firstHalf = Integer.parseInt(strArr[0]);
		secondHalf = Integer.parseInt(strArr[1]);

		// checks both values are same
		if (firstHalf == secondHalf)
		{
		    Utils.addErrorResponse(response, "Value of " + fieldName + " is invalid");
		    return false;
		}

		if (firstHalf < 0 || secondHalf < 0)
		{
		    Utils.addErrorResponse(response, "Value of " + fieldName + " is invalid");
		    return false;
		}

		// checks secondHalf is less than first Half
		if (firstHalf > secondHalf)
		{
		    tmp = firstHalf;
		    firstHalf = secondHalf;
		    secondHalf = tmp;
		}

		if (firstHalf > 0)
		{
		    ageDaysFrom = firstHalf * 30;
		    isAgeDaysFrom = true;
		}

		ageDaysTo = secondHalf * 30;
		isAgeProvided = true;
	    }
	}

	return true;
    }


    public boolean setIndustryIfValid(String _industry, String fieldName)
            throws SQLException
    {
	if (_industry != null)
	{
	    _industry = _industry.trim();

	    if (_industry != "")
	    {
		List<String> industryCheckList = ParamDBUtils.getIndustries(conn);

		validateString.Reset();
		validateString.FieldName = fieldName;
		validateString.Input = _industry;
		validateString.IsRequired = true;
		validateString.IsValueInCheckList = true;
		validateString.CheckList = industryCheckList;

		if (validateString.isValueStringToResponse() == false)
		{
		    return false;
		}

		industry = Utils.getStandardTextForSearchValue(_industry, industryCheckList);
	    }
	}

	return true;
    }


    public boolean setSolutionIfValid(String _solution, String fieldName)
            throws SQLException
    {
	if (_solution != null)
	{
	    _solution = _solution.trim();

	    if (_solution != "")
	    {
		List<String> solutionCheckList = ParamDBUtils.getSolutions(conn);

		validateString.Reset();
		validateString.FieldName = fieldName;
		validateString.Input = _solution;
		validateString.IsRequired = true;
		validateString.IsValueInCheckList = true;
		validateString.CheckList = solutionCheckList;

		if (validateString.isValueStringToResponse() == false)
		{
		    return false;
		}

		solution = Utils.getStandardTextForSearchValue(_solution, solutionCheckList);
	    }
	}

	return true;
    }


    public boolean setSizesIfValid(List<String> _sizes, String fieldName)
            throws IOException
    {
	if (_sizes != null)
	{
	    if (_sizes.size() != 0)
	    {
		List<String> silzesCheckList = ParamDBUtils.getSizes();

		validateStringArray.Reset();
		validateStringArray.FieldName = fieldName;
		validateStringArray.Input = _sizes;
		validateStringArray.CheckDuplicates = true;
		validateStringArray.IsValueWillBeTrimmed = true;
		validateStringArray.IsRequired = true;
		validateStringArray.CheckList = silzesCheckList;
		validateStringArray.IsValueInCheckList = true;

		if (validateStringArray.IsStringArrayToResponse() == false)
		{
		    return false;
		}

		sizes = new ArrayList<String>();
		int i = 0;
		String strSize = "";
		for (i = 0; i < _sizes.size(); i++)
		{
		    strSize = Utils.getStandardTextForSearchValue(_sizes.get(i), silzesCheckList);
		    sizes.add(strSize);
		}
	    }
	}

	return true;
    }


    public boolean setDescriptionIfValid(String _description, String fieldName)
    {
	if (_description != null)
	{
	    if (_description.trim() != "")
	    {
		validateString.Reset();
		validateString.FieldName = fieldName;
		validateString.Input = _description;
		validateString.HasMaximumLength = true;
		validateString.MaximumLength = 5000;

		if (validateString.isValueStringToResponse() == false)
		{
		    return false;
		}

		this.description = _description.trim();
	    }
	}

	return true;
    }


    public boolean setCenterIdsIfValid(List<Long> _centerIds, String fieldName)
            throws SQLException, IOException
    {
	if (_centerIds != null)
	{
	    if (_centerIds.size() > 0)
	    {
		int i = 0;
		List<String> messageList = new ArrayList<String>();

		for (i = 0; i < _centerIds.size(); i++)
		{
		    if (CentersDBUtils.isCenterIdExists(conn, _centerIds.get(i)) == false)
		    {
			messageList.add("Item " + (i + 1) + " of Center Id " + _centerIds.get(i) + " not found.");
		    }
		}

		if (messageList.size() > 0)
		{
		    Utils.addErrorListResponse(response, "Error in the field " + fieldName + ".", messageList);
		    return false;
		}

		centerIds = _centerIds;
	    }
	}

	return true;
    }


    public boolean setSortByIfValid(String _sortBy, String fieldName)
    {
	List<String> SortByFields = new ArrayList<String>();
	SortByFields.add("Age");
	SortByFields.add("Views");
	SortByFields.add("Availability");

	if (_sortBy != null)
	{
	    _sortBy = _sortBy.trim();
	    if (_sortBy.trim() != "")
	    {
		validateString.Reset();
		validateString.FieldName = fieldName;
		validateString.Input = _sortBy;
		validateString.IsRequired = true;
		validateString.IsValueInCheckList = true;
		validateString.CheckList = SortByFields;

		if (validateString.isValueStringToResponse() == false)
		{
		    return false;
		}

		if (_sortBy.toLowerCase().trim().equals("age"))
		{
		    contentSortByFields = EnmContentSortByFields.Age;
		}
		else if (_sortBy.toLowerCase().trim().equals("views"))
		{
		    contentSortByFields = EnmContentSortByFields.Views;
		}
		else if (_sortBy.toLowerCase().trim().equals("availability"))
		{
		    contentSortByFields = EnmContentSortByFields.Availability;
		}
	    }
	}

	return true;
    }


    public boolean setSortOrderIfValid(String _sortOrder, String fieldName)
    {
	List<String> SortByFields = new ArrayList<String>();
	SortByFields.add("Ascending");
	SortByFields.add("Descending");

	if (_sortOrder != null)
	{
	    _sortOrder = _sortOrder.trim();
	    if (_sortOrder.trim() != "")
	    {
		validateString.Reset();
		validateString.FieldName = fieldName;
		validateString.Input = _sortOrder;
		validateString.IsRequired = true;
		validateString.IsValueInCheckList = true;
		validateString.CheckList = SortByFields;

		if (validateString.isValueStringToResponse() == false)
		{
		    return false;
		}

		if (_sortOrder.toLowerCase().trim().equals("ascending"))
		{
		    isAscending = true;
		}
		else if (_sortOrder.toLowerCase().trim().equals("descending"))
		{
		    isAscending = false;
		}

	    }
	}

	return true;
    }


    public boolean setPageSizeIfValid(int _pageSize, String fieldName)
            throws IOException
    {
	validateNumber.Reset();
	validateNumber.IntInput = _pageSize;
	validateNumber.IsInteger = true;
	validateNumber.FieldName = fieldName;
	validateNumber.HasMinValue = true;
	validateNumber.MinimumIntValue = 1;

	if (validateNumber.isValueNumericToResponse() == false)
	{
	    return false;
	}

	pageSize = _pageSize;

	return true;
    }


    public boolean setPageIndexIfValid(int _pageIndex, String fieldName)
            throws IOException
    {
	validateNumber.Reset();
	validateNumber.IntInput = _pageIndex;
	validateNumber.IsInteger = true;
	validateNumber.FieldName = fieldName;
	validateNumber.HasMinValue = true;
	validateNumber.MinimumIntValue = 1;

	if (validateNumber.isValueNumericToResponse() == false)
	{
	    return false;
	}

	pageIndex = _pageIndex;

	return true;
    }


    private List<Long> GetContentIdsByFilters()
            throws SQLException
    {
	List<Long> contentIds = ContentDBUtils.GetContentIds(conn, title, description, status, ownerId);

	// checks for Age
	if (isAgeProvided)
	{
	    List<Long> ageContentIds = ContentDBUtils.GetContentIdsByAging(conn, contentIds, isAgeDaysFrom, ageDaysFrom, ageDaysTo);
	    contentIds.retainAll(ageContentIds);
	}

	// checks for asset Type
	if (assetType != null)
	{
	    if (assetType.trim() != "")
	    {
		List<Long> assetTypeContentIds = ContentDBUtils.GetContentIdsByAssetType(conn, assetType);
		contentIds.retainAll(assetTypeContentIds);
	    }
	}

	// checks for industries
	if (industry != null)
	{
	    if (industry.trim() != "")
	    {
		List<Long> industryContentIds = ContentDBUtils.GetContentIdsByIndustry(conn, industry);
		contentIds.retainAll(industryContentIds);
	    }
	}

	// checks for solution
	if (solution != null)
	{
	    if (solution.trim() != "")
	    {
		List<Long> solutionContentIds = ContentDBUtils.GetContentIdsBySolution(conn, solution);
		contentIds.retainAll(solutionContentIds);
	    }
	}

	// checks for sizes
	if (sizes != null)
	{
	    List<Long> sizesContentIds = ContentDBUtils.GetContentIdsBySizes(conn, sizes);
	    contentIds.retainAll(sizesContentIds);
	}

	// checks for centerIds
	if (centerIds != null)
	{
	    List<Long> centerIdsContentIds = ContentDBUtils.GetContentIdsByCenterIds(conn, centerIds);
	    contentIds.retainAll(centerIdsContentIds);
	}

	return contentIds;
    }


    private List<Long> GetStoryIdsForContentIds(List<Long> contentIds)
            throws SQLException
    {
	List<Long> storyIds = new ArrayList<Long>();
	List<Long> resultStoryIds = null;
	int i = 0;
	List<Long> queryContentIds = null;

	for (; i < contentIds.size(); i++)
	{
	    queryContentIds = new ArrayList<Long>();
	    queryContentIds.add(contentIds.get(i));

	    resultStoryIds = StoryDBUtils.GetStoryIdsByContentIds(conn, queryContentIds);

	    for (Long id : resultStoryIds)
	    {
		if (!storyIds.contains(id))
		{
		    storyIds.add(id);
		}
	    }
	}

	return storyIds;
    }


    private void updateContentsStoriesPlainResponse(List<Long> contentIds)
            throws SQLException, IOException
    {
	contentIds = ContentDBUtils.GetContentIdsSort(conn, contentIds, contentSortByFields, isAscending);
	List<Long> storyIds = GetStoryIdsForContentIds(contentIds);

	List<ContentsStoriesResponse> contentsStories = new ArrayList<ContentsStoriesResponse>();
	ContentsStoriesByContentResponse contentResponse = null;

	int i = 0;
	for (; i < contentIds.size(); i++)
	{
	    ContentData contentData = ContentDBUtils.GetContentByContentId(conn, contentIds.get(i));
	    ContentsResponse contentsResponse = new ContentsResponse(request, contentData);

	    contentResponse = new ContentsStoriesByContentResponse();
	    contentResponse.Content = contentsResponse;

	    contentsStories.add(contentResponse);
	}

	StoriesResponse storiesResponse = null;
	StoryData storyData = null;
	i = 0;
	for (; i < storyIds.size(); i++)
	{
	    storyData = StoryDBUtils.GetStoryById(conn, storyIds.get(i));
	    storiesResponse = new StoriesResponse(storyData);

	    ContentsStoriesByStoryResponse storyResponse = new ContentsStoriesByStoryResponse();
	    storyResponse.Story = storiesResponse;

	    contentsStories.add(storyResponse);
	}

	Utils.addSuccessResponseFromObject(response, contentsStories);
    }


    private void updateContentsStoriesByPagesResponse(List<Long> contentIds)
            throws SQLException, IOException
    {
	contentIds = ContentDBUtils.GetContentIdsSort(conn, contentIds, contentSortByFields, isAscending);
	List<Long> storyIds = GetStoryIdsForContentIds(contentIds);

	int total = contentIds.size() + storyIds.size();
	int pageCount = 0;
	double dblPageCount = 0;
	if (total > 0)
	{
	    dblPageCount = (int) Math.floor(total / pageSize);

	    if (total > (pageSize * dblPageCount))
	    {
		pageCount = (int) dblPageCount + 1;
	    }
	    else
	    {
		pageCount = (int) dblPageCount;
	    }
	}

	int startIndex = (pageIndex - 1) * pageSize;

	if (startIndex < total)
	{
	    int endIndex = startIndex + pageSize;

	    if (total < endIndex)
	    {
		endIndex = startIndex + (total - startIndex);
	    }

	    List<Long> newContentIds = new ArrayList<Long>();
	    List<Long> newStoryIds = new ArrayList<Long>();
	    for (; startIndex < endIndex; startIndex++)
	    {
		if (startIndex < contentIds.size())
		{
		    newContentIds.add(contentIds.get(startIndex));
		}
		else
		{
		    int index = startIndex - contentIds.size();
		    newStoryIds.add(storyIds.get(index));
		}
	    }

	    contentIds = newContentIds;
	    storyIds = newStoryIds;
	}

	List<ContentsStoriesResponse> contentsStories = new ArrayList<ContentsStoriesResponse>();
	ContentsStoriesByContentResponse contentResponse = null;

	int i = 0;
	for (; i < contentIds.size(); i++)
	{
	    ContentData contentData = ContentDBUtils.GetContentByContentId(conn, contentIds.get(i));
	    ContentsResponse contentsResponse = new ContentsResponse(request, contentData);

	    contentResponse = new ContentsStoriesByContentResponse();
	    contentResponse.Content = contentsResponse;

	    contentsStories.add(contentResponse);
	}

	StoriesResponse storiesResponse = null;
	StoryData storyData = null;
	i = 0;
	for (; i < storyIds.size(); i++)
	{
	    storyData = StoryDBUtils.GetStoryById(conn, storyIds.get(i));
	    storiesResponse = new StoriesResponse(storyData);

	    ContentsStoriesByStoryResponse storyResponse = new ContentsStoriesByStoryResponse();
	    storyResponse.Story = storiesResponse;

	    contentsStories.add(storyResponse);
	}

	// Utils.addSuccessResponseFromObject(response, contentsStories);

	ContentsStoriesByPagesResponse byPagesResponse = new ContentsStoriesByPagesResponse();
	byPagesResponse.PageCount = pageCount;
	byPagesResponse.Total = total;
	byPagesResponse.PageIndex = pageIndex;
	byPagesResponse.PageSize = pageSize;
	byPagesResponse.Results = contentsStories;

	Utils.addSuccessResponseFromObject(response, byPagesResponse);
    }


    public void updateResultToResponse()
            throws SQLException, IOException
    {
	List<Long> contentIds = GetContentIdsByFilters();

	if (includeStories == true)
	{
	    if (isResponseByPages)
	    {
		updateContentsStoriesByPagesResponse(contentIds);
	    }
	    else
	    {
		updateContentsStoriesPlainResponse(contentIds);
	    }
	}
	else
	{
	    if (isResponseByPages)
	    {
		updatePagesResponse(contentIds);
	    }
	    else
	    {
		updatePlainResponse(contentIds);
	    }
	}
    }


    private void updatePlainResponse(List<Long> contentIds)
            throws SQLException, IOException
    {
	contentIds = ContentDBUtils.GetContentIdsSort(conn, contentIds, contentSortByFields, isAscending);

	List<ContentsResponse> contentsResponseList = new ArrayList<ContentsResponse>();
	ContentsResponse contentsResponse = null;
	ContentData contentData = null;
	int i = 0;

	for (; i < contentIds.size(); i++)
	{
	    contentData = ContentDBUtils.GetContentByContentId(conn, contentIds.get(i));
	    contentsResponse = new ContentsResponse(request, contentData);

	    contentsResponseList.add(contentsResponse);
	}

	Utils.addSuccessResponseFromObject(response, contentsResponseList);
    }


    private void updatePagesResponse(List<Long> contentIds)
            throws SQLException, IOException
    {
	int total = contentIds.size();
	int pageCount = 0;
	double dblPageCount = 0;
	if (total > 0)
	{
	    dblPageCount = (int) Math.floor(total / pageSize);

	    if (total > (pageSize * dblPageCount))
	    {
		pageCount = (int) dblPageCount + 1;
	    }
	    else
	    {
		pageCount = (int) dblPageCount;
	    }
	}
	contentIds = ContentDBUtils.GetContentIdsSortByPages(conn, contentIds, pageSize, (pageIndex - 1) * pageSize, contentSortByFields,
	                                                     isAscending);

	ContentsByPagesResponse contentsByPagesResponse = new ContentsByPagesResponse();
	contentsByPagesResponse.PageCount = pageCount;
	contentsByPagesResponse.PageSize = pageSize;
	contentsByPagesResponse.PageIndex = pageIndex;
	contentsByPagesResponse.Total = total;
	contentsByPagesResponse.Contents = new ArrayList<ContentsResponse>();

	ContentsResponse contentsResponse = null;
	ContentData contentData = null;
	int i = 0;

	for (; i < contentIds.size(); i++)
	{
	    contentData = ContentDBUtils.GetContentByContentId(conn, contentIds.get(i));
	    contentsResponse = new ContentsResponse(request, contentData);

	    contentsByPagesResponse.Contents.add(contentsResponse);
	}

	Utils.addSuccessResponseFromObject(response, contentsByPagesResponse);
    }
}
