package db_operations;

import cmis_operations.classes.CMISDocument;
import utils.Utils;

import java.util.List;
import java.util.ArrayList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class CMISDocumentDBUtils
{
    public static final String tblCMISDocuments	  = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblCMISDocuments + "\"";
    public static final String sqnceCMISDocuments = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.sqnceCMISDocuments + "\"";


    public static Long GetNextCMISDocumentId(Connection connection)
            throws SQLException
    {
	return DBUtils.getNextSequenceId(connection, sqnceCMISDocuments);
    }


    public static CMISDocument GetCMISDocumentById(Connection conn, Long CMISDocumentId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	CMISDocument cmisDocument = null;

	sql = "SELECT ";
	sql += "\"Id\", ";
	sql += "\"FileName\", ";
	sql += "\"FilePath\", ";
	sql += "\"CMISObjectId\", ";
	sql += "\"FileSize\", ";
	sql += "\"MimeType\" ";
	sql += "FROM " + tblCMISDocuments + " ";
	sql += "where \"Id\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, CMISDocumentId);

	rs = pstmt.executeQuery();

	if (rs.next())
	{
	    cmisDocument = new CMISDocument();

	    cmisDocument.Id = rs.getLong(1);
	    cmisDocument.FileName = rs.getNString(2);
	    cmisDocument.FilePath = rs.getNString(3);
	    cmisDocument.CMISObjectId = rs.getNString(4);
	    cmisDocument.FileSize = rs.getLong(5);
	    cmisDocument.MimeType = rs.getNString(6);
	}

	rs.close();
	pstmt.close();

	return cmisDocument;
    }


    public static CMISDocument GetCmisObjectIdByDocumentId(Connection conn, String DocumentId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	CMISDocument cmisDocument = new CMISDocument();

	sql = "SELECT ";
	sql += "\"Id\", ";
	sql += "\"FileName\", ";
	sql += "\"FilePath\", ";
	sql += "\"CMISObjectId\", ";
	sql += "\"FileSize\", ";
	sql += "\"MimeType\" ";
	sql += "FROM " + tblCMISDocuments + " ";
	sql += "where \"Id\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setNString(1, DocumentId);

	rs = pstmt.executeQuery();
	rs.next();

	cmisDocument.Id = rs.getLong(1);
	cmisDocument.FileName = rs.getNString(2);
	cmisDocument.FilePath = rs.getNString(3);
	cmisDocument.CMISObjectId = rs.getNString(4);
	cmisDocument.FileSize = rs.getLong(5);
	cmisDocument.MimeType = rs.getNString(6);

	rs.close();
	pstmt.close();

	return cmisDocument;
    }


    public static long GetTotalBytesByIds(Connection conn, List<Long> CMISDocumentIds)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	long totalBytes = 0;
	String strIds = Utils.CombineIdsToString(CMISDocumentIds);

	if (strIds == "")
	{
	    return totalBytes;
	}

	sql = "SELECT ";
	sql += "SUM(\"FileSize\") ";
	sql += "FROM " + tblCMISDocuments + " ";
	sql += "where \"Id\" in (" + strIds + ");";

	pstmt = conn.prepareStatement(sql);
	rs = pstmt.executeQuery();
	rs.next();

	totalBytes = rs.getLong(1);

	rs.close();
	pstmt.close();

	return totalBytes;
    }


    public static Boolean IsDocumentIdExists(Connection connection, String DocumentId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Boolean blExists = false;

	sql = "SELECT Count(*) FROM " + tblCMISDocuments + " ";
	sql += "where \"Id\" = ? and \"DeletedOn\" is Null;";

	pstmt = connection.prepareStatement(sql);
	pstmt.setNString(1, DocumentId);

	rs = pstmt.executeQuery();
	rs.next();

	if (rs.getLong(1) > 0)
	{
	    blExists = true;
	}

	rs.close();
	pstmt.close();

	return blExists;
    }


    public static void AddCMISDocumentFromCMISDocument(Connection conn, String userId, CMISDocument cmisDocument)
            throws SQLException
    {
	PreparedStatement pstmt = null;
	String sql = "";
	List<String> sqlFields = new ArrayList<String>();
	List<String> sqlValues = new ArrayList<String>();

	sqlFields.add("Id");
	sqlValues.add("?"); // 1

	sqlFields.add("CreatedOn");
	sqlValues.add("Now()");

	sqlFields.add("CreatedBy");
	sqlValues.add("?"); // 2

	sqlFields.add("FileName");
	sqlValues.add("?"); // 3

	sqlFields.add("FilePath");
	sqlValues.add("?"); // 4

	sqlFields.add("CMISObjectId");
	sqlValues.add("?"); // 5

	sqlFields.add("FileSize");
	sqlValues.add("?"); // 6

	sqlFields.add("MimeType");
	sqlValues.add("?"); // 7

	sql = DBUtils.combineSQLInsertQuery(sqlFields, sqlValues, tblCMISDocuments);

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, cmisDocument.Id);
	pstmt.setNString(2, userId);
	pstmt.setNString(3, cmisDocument.FileName);
	pstmt.setNString(4, cmisDocument.FilePath);
	pstmt.setNString(5, cmisDocument.CMISObjectId);
	pstmt.setLong(6, cmisDocument.FileSize);
	pstmt.setNString(7, cmisDocument.MimeType);

	pstmt.execute();
	pstmt.close();
    }


    public static void DeleteCMIS_Document_DB(Connection conn, long CMISDocumentId, String userId)
            throws SQLException
    {
	PreparedStatement pstmt = null;
	String sql = "";
	List<String> sqlFields = new ArrayList<String>();
	List<String> sqlValues = new ArrayList<String>();

	sqlFields.add("DeletedOn");
	sqlValues.add("Now()");

	sqlFields.add("DeletedBy");
	sqlValues.add("?"); // 1

	sql = DBUtils.combineSQLUpdateQuery(sqlFields, sqlValues, tblCMISDocuments, " where \"Id\" = ?;");

	pstmt = conn.prepareStatement(sql);
	pstmt.setNString(1, userId);
	pstmt.setLong(2, CMISDocumentId);

	pstmt.execute();
	pstmt.close();
    }
}
