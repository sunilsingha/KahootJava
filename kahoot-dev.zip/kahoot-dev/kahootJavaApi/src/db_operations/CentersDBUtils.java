package db_operations;

import java.util.ArrayList;
import java.util.List;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import centers.classes.data.CenterData;
import centers.classes.data.CenterDataFile;
import cmis_operations.classes.CMISDocument;


public class CentersDBUtils
{
    private static final String	tblCenters		 = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblCenters + "\"";
    private static final String	tblCentersContacts	 = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblCentersContacts + "\"";
    private static final String	tblCentersFloormaps	 = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblCentersFloormaps + "\"";
    private static final String	tblCentersOtherDocuments = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblCentersOtherDocuments + "\"";
    private static final String	tblCentersPictures	 = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblCentersPictures + "\"";

    private static final String	sqnceCenters		   = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.sqnceCenters + "\"";
    private static final String	sqnceCentersFloormaps	   = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.sqnceCentersFloormaps + "\"";
    private static final String	sqnceCentersOtherDocuments = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.sqnceCentersOtherDocuments
            + "\"";
    private static final String	sqnceCentersPictures	   = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.sqnceCentersPictures + "\"";


    public static long getNextCenterId(Connection conn)
            throws SQLException
    {
	return DBUtils.getNextSequenceId(conn, sqnceCenters);
    }


    public static long getNextCentersFloormapId(Connection conn)
            throws SQLException
    {
	return DBUtils.getNextSequenceId(conn, sqnceCentersFloormaps);
    }


    public static long getNextCentersOtherDocuments(Connection conn)
            throws SQLException
    {
	return DBUtils.getNextSequenceId(conn, sqnceCentersOtherDocuments);
    }


    public static long getNextCentersPicturesId(Connection conn)
            throws SQLException
    {
	return DBUtils.getNextSequenceId(conn, sqnceCentersPictures);
    }


    public static List<Long> GetAllCenterIds(Connection conn)
            throws SQLException
    {
	List<Long> centerIds = new ArrayList<Long>();
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "\"Id\" ";
	sql += "FROM " + tblCenters + ";";

	pstmt = conn.prepareStatement(sql);
	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    centerIds.add(rs.getLong(1));
	}

	rs.close();
	pstmt.close();

	return centerIds;
    }


    public static List<String> GetContactsByCenterId(Connection conn, long centerId)
            throws SQLException
    {
	List<String> contacts = new ArrayList<String>();
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "\"Contact\" ";
	sql += "FROM " + tblCentersContacts + " ";
	sql += "where \"CenterId\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, centerId);

	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    contacts.add(rs.getString(1));
	}

	rs.close();
	pstmt.close();

	return contacts;
    }


    public static List<CenterDataFile> GetFloormapsByCenterId(Connection conn, long centerId)
            throws SQLException
    {
	List<CenterDataFile> centerDataFloormaps = new ArrayList<CenterDataFile>();
	CenterDataFile centerDataFloormap = null;
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "\"Id\", "; // 1
	sql += "\"Floormap_CMIS_DocumentId\" "; // 2
	sql += "FROM " + tblCentersFloormaps + " ";
	sql += "where \"CenterId\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, centerId);

	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    centerDataFloormap = new CenterDataFile();

	    centerDataFloormap.Id = rs.getLong(1);
	    centerDataFloormap.CMISDocument = CMISDocumentDBUtils.GetCMISDocumentById(conn, rs.getLong(2));

	    centerDataFloormaps.add(centerDataFloormap);
	}

	rs.close();
	pstmt.close();

	return centerDataFloormaps;
    }


    public static List<CenterDataFile> GetPicturesByCenterId(Connection conn, long centerId)
            throws SQLException
    {
	List<CenterDataFile> centerDataPictures = new ArrayList<CenterDataFile>();
	CenterDataFile centerDataPicture = null;
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "\"Id\", "; // 1
	sql += "\"Picture_CMIS_DocumentId\" "; // 2
	sql += "FROM " + tblCentersPictures + " ";
	sql += "where \"CenterId\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, centerId);

	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    centerDataPicture = new CenterDataFile();

	    centerDataPicture.Id = rs.getLong(1);
	    centerDataPicture.CMISDocument = CMISDocumentDBUtils.GetCMISDocumentById(conn, rs.getLong(2));

	    centerDataPictures.add(centerDataPicture);
	}

	rs.close();
	pstmt.close();

	return centerDataPictures;
    }


    public static List<CenterDataFile> GetOtherDocumentsByCenterId(Connection conn, long centerId)
            throws SQLException
    {
	List<CenterDataFile> centerDataOtherDocuments = new ArrayList<CenterDataFile>();
	CenterDataFile centerDataOtherDocument = null;
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "\"Id\", "; // 1
	sql += "\"OtherDocuments_CMIS_DocumentId\" "; // 2
	sql += "FROM " + tblCentersOtherDocuments + " ";
	sql += "where \"CenterId\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, centerId);

	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    centerDataOtherDocument = new CenterDataFile();

	    centerDataOtherDocument.Id = rs.getLong(1);
	    centerDataOtherDocument.CMISDocument = CMISDocumentDBUtils.GetCMISDocumentById(conn, rs.getLong(2));

	    centerDataOtherDocuments.add(centerDataOtherDocument);
	}

	rs.close();
	pstmt.close();

	return centerDataOtherDocuments;
    }


    public static CenterData GetCenterById(Connection conn, long centerId)
            throws SQLException
    {
	CenterData centerData = null;
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "\"Id\", "; // 1
	sql += "\"Name\", "; // 2
	sql += "\"City\", "; // 3
	sql += "\"Country\", "; // 4
	sql += "\"Latitude\", "; // 5
	sql += "\"Longitude\", "; // 6
	sql += "\"Description\", "; // 7
	sql += "\"VirtualTourURL\", "; // 8
	sql += "\"BookVisitURL\", "; // 9
	sql += "\"MarkerColor\", "; // 10
	sql += "\"IntroductionVideo_CMIS_DocumentId\" "; // 11
	sql += "FROM " + tblCenters + " ";
	sql += "where \"Id\" = ?";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, centerId);

	rs = pstmt.executeQuery();

	if (rs.next())
	{
	    centerData = new CenterData();

	    centerData.CenterId = rs.getLong(1);
	    centerData.Name = rs.getNString(2);
	    centerData.City = rs.getNString(3);
	    centerData.Country = rs.getNString(4);
	    centerData.Latitude = rs.getNString(5);
	    centerData.Longitude = rs.getNString(6);
	    centerData.Description = rs.getNString(7);
	    centerData.VirtualTourURL = rs.getNString(8);
	    centerData.BookVisitURL = rs.getNString(9);
	    centerData.MarkerColor = rs.getNString(10);
	    centerData.IntroductionVideo_CMIS_DocumentId = rs.getLong(11);
	    centerData.IntroductionVideo_CMISDocument = CMISDocumentDBUtils.GetCMISDocumentById(conn,
	                                                                                        centerData.IntroductionVideo_CMIS_DocumentId);

	    centerData.Contacts = GetContactsByCenterId(conn, centerId);
	    centerData.Floormaps = GetFloormapsByCenterId(conn, centerId);
	    centerData.Pictures = GetPicturesByCenterId(conn, centerId);
	    centerData.OtherDocuments = GetOtherDocumentsByCenterId(conn, centerId);
	}

	rs.close();
	pstmt.close();

	return centerData;
    }


    public static long GetCMISDocumentIdOfPictureId(Connection conn, long picturerId)
            throws SQLException
    {
	long cmisDocumentId = 0L;
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "\"Picture_CMIS_DocumentId\" ";
	sql += "FROM " + tblCentersPictures + " ";
	sql += "where \"Id\" = ?;"; // 1 pictureId

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, picturerId);

	rs = pstmt.executeQuery();

	if (rs.next())
	{
	    cmisDocumentId = rs.getLong(1);
	}

	rs.close();
	pstmt.close();

	return cmisDocumentId;
    }


    public static long GetCMISDocumentIdOfFloormapId(Connection conn, long floormapId)
            throws SQLException
    {
	long cmisDocumentId = 0L;
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "\"Floormap_CMIS_DocumentId\" ";
	sql += "FROM " + tblCentersFloormaps + " ";
	sql += "where \"Id\" = ?;"; // 1 floormapId

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, floormapId);

	rs = pstmt.executeQuery();

	if (rs.next())
	{
	    cmisDocumentId = rs.getLong(1);
	}

	rs.close();
	pstmt.close();

	return cmisDocumentId;
    }


    public static long GetCMISDocumentIdOfOtherDocumentId(Connection conn, long otherDocumentId)
            throws SQLException
    {
	long cmisDocumentId = 0L;
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "\"OtherDocuments_CMIS_DocumentId\" ";
	sql += "FROM " + tblCentersOtherDocuments + " ";
	sql += "where \"Id\" = ?;"; // 1 otherDocumentId

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, otherDocumentId);

	rs = pstmt.executeQuery();

	if (rs.next())
	{
	    cmisDocumentId = rs.getLong(1);
	}

	rs.close();
	pstmt.close();

	return cmisDocumentId;
    }


    public static boolean isCenterIdExists(Connection conn, long centerId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Boolean blExists = false;

	sql = "SELECT count(*) from " + tblCenters + " ";
	sql += "where \"Id\" = ?;"; // 1 center Id

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, centerId);

	rs = pstmt.executeQuery();
	rs.next();

	if (rs.getLong(1) > 0)
	{
	    blExists = true;
	}

	rs.close();
	pstmt.close();

	return blExists;
    }


    public static boolean isCenterNameExists(Connection conn, String centerName, long centerId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Boolean blExists = false;

	sql = "SELECT count(*) from " + tblCenters + " ";
	sql += "where TRIM(LOWER(\"Name\")) = TRIM(LOWER(?)) "; // 1 center Name
	sql += "and \"Id\" != ?;"; // 2 center Id

	pstmt = conn.prepareStatement(sql);
	pstmt.setNString(1, centerName);
	pstmt.setLong(2, centerId);

	rs = pstmt.executeQuery();
	rs.next();

	if (rs.getLong(1) > 0)
	{
	    blExists = true;
	}

	rs.close();
	pstmt.close();

	return blExists;
    }


    public static boolean isCenterPictureExists(Connection conn, long centerId, long pictureId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Boolean blExists = false;

	sql = "SELECT count(*) from " + tblCentersPictures + " ";
	sql += "where \"CenterId\" = ? "; // 1 center Id
	sql += "and \"Id\" = ?;"; // 2 picture Id

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, centerId);
	pstmt.setLong(2, pictureId);

	rs = pstmt.executeQuery();
	rs.next();

	if (rs.getLong(1) > 0)
	{
	    blExists = true;
	}

	rs.close();
	pstmt.close();

	return blExists;
    }


    public static boolean isCenterFloormapExists(Connection conn, long centerId, long floormapId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Boolean blExists = false;

	sql = "SELECT count(*) from " + tblCentersFloormaps + " ";
	sql += "where \"CenterId\" = ? "; // 1 center Id
	sql += "and \"Id\" = ?;"; // 2 floormap Id

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, centerId);
	pstmt.setLong(2, floormapId);

	rs = pstmt.executeQuery();
	rs.next();

	if (rs.getLong(1) > 0)
	{
	    blExists = true;
	}

	rs.close();
	pstmt.close();

	return blExists;
    }


    public static boolean isCenterOtherDocumentExists(Connection conn, long centerId, long otherDocumentId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Boolean blExists = false;

	sql = "SELECT count(*) from " + tblCentersOtherDocuments + " ";
	sql += "where \"CenterId\" = ? "; // 1 center Id
	sql += "and \"Id\" = ?;"; // 2 other document Id

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, centerId);
	pstmt.setLong(2, otherDocumentId);

	rs = pstmt.executeQuery();
	rs.next();

	if (rs.getLong(1) > 0)
	{
	    blExists = true;
	}

	rs.close();
	pstmt.close();

	return blExists;
    }


    public static void AddContactFromList(Connection conn, long centerId, List<String> contacts, String userId)
            throws SQLException
    {
	String strContact = "";

	List<String> sqlFields = new ArrayList<String>();
	List<String> sqlValues = new ArrayList<String>();

	sqlFields.add("CenterId");
	sqlValues.add("?"); // 1

	sqlFields.add("Contact");
	sqlValues.add("?"); // 2

	sqlFields.add("CreatedOn");
	sqlValues.add("Now()");

	sqlFields.add("CreatedBy");
	sqlValues.add("?"); // 3

	String sql = DBUtils.combineSQLInsertQuery(sqlFields, sqlValues, tblCentersContacts);

	int i = 0;
	for (; i < contacts.size(); i++)
	{
	    strContact = contacts.get(i).trim().toLowerCase();

	    PreparedStatement pstmt = null;
	    pstmt = conn.prepareStatement(sql);

	    pstmt.setLong(1, centerId);
	    pstmt.setNString(2, strContact);
	    pstmt.setNString(3, userId);

	    pstmt.execute();
	    pstmt.close();
	}
    }


    private static void addCentersSubDataForFiles(Connection conn, String tableName, String fieldName, long centerId, String userId,
                                                  CMISDocument cmisDocument, long Id)
            throws SQLException
    {
	List<String> sqlFields = new ArrayList<String>();
	List<String> sqlValues = new ArrayList<String>();

	sqlFields.add("Id");
	sqlValues.add("?"); // 1

	sqlFields.add("CreatedOn");
	sqlValues.add("Now()"); // 2

	sqlFields.add("CreatedBy");
	sqlValues.add("?");

	sqlFields.add("CenterId");
	sqlValues.add("?"); // 3

	sqlFields.add(fieldName);
	sqlValues.add("?"); // 4

	String sql = DBUtils.combineSQLInsertQuery(sqlFields, sqlValues, tableName);
	PreparedStatement pstmt = null;

	pstmt = conn.prepareStatement(sql);

	pstmt.setLong(1, Id);
	pstmt.setNString(2, userId);
	pstmt.setLong(3, centerId);
	pstmt.setLong(4, cmisDocument.Id);

	pstmt.execute();
	pstmt.close();
    }


    public static void AddFloormapsFromList(Connection conn, long centerId, String userId, List<CMISDocument> cmisDocuments)
            throws SQLException
    {
	int i = 0;
	long floormapId = 0L;

	for (; i < cmisDocuments.size(); i++)
	{
	    floormapId = getNextCentersFloormapId(conn);
	    addCentersSubDataForFiles(conn, tblCentersFloormaps, "Floormap_CMIS_DocumentId", centerId, userId, cmisDocuments.get(i),
	                              floormapId);
	}
    }


    public static void AddPicturesFromList(Connection conn, long centerId, String userId, List<CMISDocument> cmisDocuments)
            throws SQLException
    {
	int i = 0;
	long pictureId = 0L;

	for (; i < cmisDocuments.size(); i++)
	{
	    pictureId = getNextCentersPicturesId(conn);
	    addCentersSubDataForFiles(conn, tblCentersPictures, "Picture_CMIS_DocumentId", centerId, userId, cmisDocuments.get(i),
	                              pictureId);
	}
    }


    public static void AddOtherDocumentsFromList(Connection conn, long centerId, String userId, List<CMISDocument> cmisDocuments)
            throws SQLException
    {
	int i = 0;
	long otherDocumentId = 0L;

	for (; i < cmisDocuments.size(); i++)
	{
	    otherDocumentId = getNextCentersOtherDocuments(conn);
	    addCentersSubDataForFiles(conn, tblCentersOtherDocuments, "OtherDocuments_CMIS_DocumentId", centerId, userId,
	                              cmisDocuments.get(i), otherDocumentId);
	}
    }


    public static void DeleteContactsByCenterId(Connection conn, long centerId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;

	sql = "Delete from " + tblCentersContacts + " ";
	sql += "where \"CenterId\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, centerId);

	pstmt.execute();
    }


    public static void DeletePictureById(Connection conn, long pictureId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;

	sql = "Delete from " + tblCentersPictures + " ";
	sql += "where \"Id\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, pictureId);

	pstmt.execute();
    }


    public static void DeleteFloormapById(Connection conn, long floormapId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;

	sql = "Delete from " + tblCentersFloormaps + " ";
	sql += "where \"Id\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, floormapId);

	pstmt.execute();
    }


    public static void DeleteOtherDocumentById(Connection conn, long otherDocumentId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;

	sql = "Delete from " + tblCentersOtherDocuments + " ";
	sql += "where \"Id\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, otherDocumentId);

	pstmt.execute();
    }
}
