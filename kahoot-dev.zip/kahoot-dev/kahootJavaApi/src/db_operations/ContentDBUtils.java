package db_operations;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import utils.Utils;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import contents.classes.data.ContentData;
import contents.classes.data.ContentDataComment;
import contents.classes.data.ContentDataRating;
import db_operations.utils.EnmContentSortByFields;


public class ContentDBUtils
{
    private static final String	tblContents		= "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblContents + "\"";
    private static final String	tblContentsAssetTypes	= "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblContentsAssetTypes + "\"";
    private static final String	tblContentsCenters	= "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblContentsCenters + "\"";
    private static final String	tblContentsContacts	= "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblContentsContacts + "\"";
    private static final String	tblContentsComments	= "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblContentsComments + "\"";
    private static final String	tblContentsIndustries	= "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblContentsIndustries + "\"";
    private static final String	tblContentsInRoleVideos	= "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblContentsInRoleVideos + "\"";
    private static final String	tblContentsSolutions	= "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblContentsSolutions + "\"";
    private static final String	tblContentsRatings	= "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblContentsRatings + "\"";
    private static final String	tblContentsSizes	= "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblContentsSizes + "\"";

    private static final String sqnceContents = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.sqnceContents + "\"";

    private static final String StatusArchived = "Archived";


    public static Long getNextContentId(Connection conn)
            throws SQLException
    {
	return DBUtils.getNextSequenceId(conn, sqnceContents);
    }


    public static Boolean isContentExists(Connection connection, Long contentId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Boolean blExists = false;

	sql = "SELECT count(*) from " + tblContents + " ";
	sql += "where \"ContentId\" = ? "; // 1 content Id

	pstmt = connection.prepareStatement(sql);
	pstmt.setLong(1, contentId);

	rs = pstmt.executeQuery();
	rs.next();

	if (rs.getLong(1) > 0)
	{
	    blExists = true;
	}

	rs.close();
	pstmt.close();

	return blExists;
    }


    public static Boolean isContentOwner(Connection connection, Long contentId, String ownerId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Boolean blOwner = false;

	sql = "SELECT count(*) from " + tblContents + " ";
	sql += "where \"ContentId\" = ? and "; // 1 content Id
	sql += "LOWER(TRIM(\"OwnerId\")) = LOWER(TRIM(?));"; // 2 OwnerId

	pstmt = connection.prepareStatement(sql);
	pstmt.setLong(1, contentId);
	pstmt.setNString(2, ownerId);

	rs = pstmt.executeQuery();
	rs.next();

	if (rs.getLong(1) > 0)
	{
	    blOwner = true;
	}

	rs.close();
	pstmt.close();

	return blOwner;
    }


    private static String _get_Status_of_Content(Connection connection, Long contentId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String status = "";

	sql = "SELECT ";
	sql += "\"Status\" ";
	sql += "FROM " + tblContents + " ";
	sql += "where \"ContentId\" = ?;";

	pstmt = connection.prepareStatement(sql);
	pstmt.setLong(1, contentId);

	rs = pstmt.executeQuery();
	rs.next();

	status = rs.getNString(1);

	rs.close();
	pstmt.close();

	return status;
    }


    public static Boolean isContent_InReview(Connection conn, Long contentId)
            throws SQLException
    {
	String status = _get_Status_of_Content(conn, contentId);
	String inReview = "In Review";

	status = status.toLowerCase().trim();
	inReview = inReview.toLowerCase().trim();

	if (status.equals(inReview))
	{
	    return true;
	}

	return false;
    }


    public static Boolean isContent_Rejected_Or_UpdateNeeded(Connection conn, Long contentId)
            throws SQLException
    {
	String status = _get_Status_of_Content(conn, contentId);

	status = status.toLowerCase().trim();
	String rejected = ParamDBUtils.StatusRejected.toLowerCase().trim();
	String updateNeeded = ParamDBUtils.StatusUpdateNeeded.toLowerCase().trim();

	if (status.equals(rejected) || status.equals(updateNeeded))
	{
	    return true;
	}

	return false;
    }


    public static boolean isContent_Archived(Connection conn, long contentId)
            throws SQLException
    {
	String status = _get_Status_of_Content(conn, contentId);

	status = status.toLowerCase().trim();
	String archived = StatusArchived.toLowerCase().trim();

	if (status.equals(archived))
	{
	    return true;
	}

	return false;
    }


    private static void addContentsSubData(Connection conn, String tableName, long contentId, String userId, String fieldName, String value)
            throws SQLException
    {
	List<String> sqlFields = new ArrayList<String>();
	List<String> sqlValues = new ArrayList<String>();

	sqlFields.add("ContentId");
	sqlValues.add("?"); // 1

	sqlFields.add(fieldName);
	sqlValues.add("?"); // 2

	sqlFields.add("CreatedOn");
	sqlValues.add("Now()");

	sqlFields.add("CreatedBy");
	sqlValues.add("?"); // 3

	String sql = DBUtils.combineSQLInsertQuery(sqlFields, sqlValues, tableName);
	PreparedStatement pstmt = null;

	pstmt = conn.prepareStatement(sql);

	pstmt.setLong(1, contentId);
	pstmt.setNString(2, value);
	pstmt.setNString(3, userId);

	pstmt.execute();
	pstmt.close();
    }


    public static void AddAssetTypeFromList(Connection conn, Long contentId, List<String> assetTypes, String userId)
            throws SQLException
    {
	int i = 0;
	String strAssetType = "";
	List<String> paramAssetTypes = ParamDBUtils.getAssetTypes(conn);

	for (; i < assetTypes.size(); i++)
	{
	    strAssetType = Utils.getStandardTextForSearchValue(assetTypes.get(i), paramAssetTypes);
	    addContentsSubData(conn, tblContentsAssetTypes, contentId, userId, "AssetType", strAssetType);
	}
    }


    public static void AddIndustryFromList(Connection conn, Long contentId, List<String> industries, String userId)
            throws SQLException
    {
	int i = 0;
	String strIndustry = "";
	List<String> paramIndustries = ParamDBUtils.getIndustries(conn);

	for (; i < industries.size(); i++)
	{
	    strIndustry = Utils.getStandardTextForSearchValue(industries.get(i), paramIndustries);
	    addContentsSubData(conn, tblContentsIndustries, contentId, userId, "Industry", strIndustry);
	}
    }


    public static void AddSolutionsFromList(Connection conn, Long contentId, List<String> solutions, String userId)
            throws SQLException
    {
	int i = 0;
	String strSolution = "";
	List<String> paramSolutions = ParamDBUtils.getSolutions(conn);

	for (; i < solutions.size(); i++)
	{
	    strSolution = Utils.getStandardTextForSearchValue(solutions.get(i), paramSolutions);
	    addContentsSubData(conn, tblContentsSolutions, contentId, userId, "Solution", strSolution);
	}
    }


    public static void AddSizeFromList(Connection conn, Long contentId, List<String> sizes, String userId)
            throws SQLException
    {
	int i = 0;
	String strSize = "";
	List<String> paramSizes = ParamDBUtils.getSizes();

	for (; i < sizes.size(); i++)
	{
	    strSize = Utils.getStandardTextForSearchValue(sizes.get(i), paramSizes);
	    addContentsSubData(conn, tblContentsSizes, contentId, userId, "Size", strSize);
	}
    }


    public static void AddContactFromList(Connection conn, Long contentId, List<String> contacts, String userId)
            throws SQLException
    {
	int i = 0;
	String strContact = "";

	for (; i < contacts.size(); i++)
	{
	    strContact = contacts.get(i).trim().toLowerCase();
	    addContentsSubData(conn, tblContentsContacts, contentId, userId, "Contact", strContact);
	}
    }


    public static void AddCommentFromList(Connection conn, long contentId, List<String> comments, String userId)
            throws SQLException
    {
	int i = 0;
	String strComment = "";

	for (; i < comments.size(); i++)
	{
	    strComment = comments.get(i).trim();
	    addContentsSubData(conn, tblContentsComments, contentId, userId, "Comment", strComment);
	}
    }


    public static void AddCentersFromList(Connection conn, long contentId, List<Long> centerIds, String userId)
            throws SQLException
    {
	int i = 0;
	List<String> sqlFields = new ArrayList<String>();
	List<String> sqlValues = new ArrayList<String>();

	sqlFields.add("ContentId");
	sqlValues.add("?"); // 1

	sqlFields.add("CenterId");
	sqlValues.add("?"); // 2

	sqlFields.add("CreatedOn");
	sqlValues.add("Now()");

	sqlFields.add("CreatedBy");
	sqlValues.add("?"); // 3

	String sql = DBUtils.combineSQLInsertQuery(sqlFields, sqlValues, tblContentsCenters);
	PreparedStatement pstmt = null;

	for (; i < centerIds.size(); i++)
	{
	    pstmt = conn.prepareStatement(sql);

	    pstmt.setLong(1, contentId);
	    pstmt.setLong(2, centerIds.get(i));
	    pstmt.setNString(3, userId);

	    pstmt.execute();
	    pstmt.close();
	}
    }


    private static void deleteContentsSubDataByContentId(Connection conn, String tableName, long contentId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;

	sql = "Delete from " + tableName + " ";
	sql += "where \"ContentId\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, contentId);

	pstmt.execute();
    }


    public static void DeleteSizesByContentId(Connection conn, long contentId)
            throws SQLException
    {
	deleteContentsSubDataByContentId(conn, tblContentsSizes, contentId);
    }


    public static void DeleteContactsByContentId(Connection conn, long contentId)
            throws SQLException
    {
	deleteContentsSubDataByContentId(conn, tblContentsContacts, contentId);
    }


    public static void DeleteAssetTypesByContentId(Connection conn, long contentId)
            throws SQLException
    {
	deleteContentsSubDataByContentId(conn, tblContentsAssetTypes, contentId);
    }


    public static void DeleteIndustriesByContentId(Connection conn, long contentId)
            throws SQLException
    {
	deleteContentsSubDataByContentId(conn, tblContentsIndustries, contentId);
    }


    public static void DeleteSolutionsByContentId(Connection conn, long contentId)
            throws SQLException
    {
	deleteContentsSubDataByContentId(conn, tblContentsSolutions, contentId);
    }


    public static void DeleteMappingsContentandCenter(Connection conn, long contentId)
            throws SQLException

    {
	deleteContentsSubDataByContentId(conn, tblContentsCenters, contentId);
    }


    public static List<Long> GetContentIds(Connection conn, String title, String description, String status, String ownerId)
            throws SQLException
    {
	List<Long> contentIds = new ArrayList<Long>();
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String sqlConditions = "";
	int colId = 0;
	int ownerIdCol = 0;
	int titleCol = 0;
	int descriptionCol = 0;
	int statusCol = 0;
	// int ageCol = 0;

	sql = "SELECT distinct ";
	sql += "\"ContentId\" ";
	sql += "FROM " + tblContents + " ";

	// Search by ownerId
	if (ownerId != null)
	{
	    if (ownerId != "")
	    {
		if (sqlConditions == "")
		{
		    sqlConditions += " where ";
		}
		sqlConditions += "LOWER(TRIM(\"OwnerId\")) = LOWER(TRIM(?))";
		colId++;
		ownerIdCol = colId;
	    }
	}

	// Search by title
	if (title != null)
	{
	    if (title != "")
	    {
		if (sqlConditions == "")
		{
		    sqlConditions += " where ";
		}
		else
		{
		    sqlConditions += " and ";
		}
		sqlConditions += "LOWER(\"Title\") like  LOWER(?)";
		colId++;
		titleCol = colId;
	    }
	}

	// Search by description
	if (description != null)
	{
	    if (description != "")
	    {
		if (sqlConditions == "")
		{
		    sqlConditions += " where ";
		}
		else
		{
		    sqlConditions += " and ";
		}
		sqlConditions += "LOWER(\"Description\") like  LOWER(?)";
		colId++;
		descriptionCol = colId;
	    }
	}

	// Search by Status
	if (status != null)
	{
	    if (status != "")
	    {
		if (sqlConditions == "")
		{
		    sqlConditions += " where ";
		}
		else
		{
		    sqlConditions += " and ";
		}
		sqlConditions += "LOWER(TRIM(\"Status\")) = LOWER(TRIM(?))";
		colId++;
		statusCol = colId;
	    }
	}

	sql += sqlConditions;

	pstmt = conn.prepareStatement(sql);

	// Search by ownerId
	if (ownerId != null)
	{
	    if (ownerId != "")
	    {
		pstmt.setNString(ownerIdCol, ownerId);
	    }
	}

	// Search by title
	if (title != null)
	{
	    if (title != "")
	    {
		pstmt.setNString(titleCol, "%" + title + "%");
	    }
	}

	// Search by description
	if (description != null)
	{
	    if (description != "")
	    {
		pstmt.setNString(descriptionCol, "%" + description + "%");
	    }
	}

	// Search by Status
	if (status != null)
	{
	    if (status != "")
	    {
		pstmt.setNString(statusCol, status);
	    }
	}

	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    contentIds.add(rs.getLong(1));
	}

	rs.close();
	pstmt.close();

	return contentIds;
    }


    public static List<Long> GetContentIdsByAging(Connection conn, List<Long> contentIds, boolean isAgeDaysFrom, int ageDaysFrom,
                                                  int ageDaysTo)
            throws SQLException
    {
	if (contentIds.size() == 0)
	{
	    return contentIds;
	}

	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	Long[] contentIdsArr = contentIds.toArray(new Long[contentIds.size()]);
	int i, arrLen = contentIdsArr.length;
	StringBuilder tmp = new StringBuilder();
	for (i = 0; i < arrLen - 1; i++)
	    tmp.append(contentIdsArr[i] + ", ");
	tmp.append(contentIdsArr[arrLen - 1]);

	sql = "SELECT  ";
	sql += "\"ContentId\" ";
	sql += "FROM " + tblContents + " ";
	sql += "where \"ContentId\" in (" + tmp.toString() + ") ";
	sql += " and DAYS_BETWEEN (\"LatestUpdateDate\", Now()) <= ? ";

	if (isAgeDaysFrom)
	{
	    sql += " and DAYS_BETWEEN (\"LatestUpdateDate\", Now()) >= ?;";
	}

	pstmt = conn.prepareStatement(sql);
	pstmt.setInt(1, ageDaysTo);
	if (isAgeDaysFrom)
	{
	    pstmt.setInt(2, ageDaysFrom);
	}
	rs = pstmt.executeQuery();

	contentIds = new ArrayList<Long>();

	while (rs.next())
	{
	    contentIds.add(rs.getLong(1));
	}

	rs.close();
	pstmt.close();

	return contentIds;
    }


    public static List<Long> GetContentIdsSort(Connection conn, List<Long> contentIds, EnmContentSortByFields enmContentSortByFields,
                                               boolean isAscending)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	if (contentIds.size() == 0)
	{
	    return contentIds;
	}

	Long[] contentIdsArr = contentIds.toArray(new Long[contentIds.size()]);
	int i, arrLen = contentIdsArr.length;
	StringBuilder tmp = new StringBuilder();
	for (i = 0; i < arrLen - 1; i++)
	    tmp.append(contentIdsArr[i] + ", ");
	tmp.append(contentIdsArr[arrLen - 1]);

	if (enmContentSortByFields == EnmContentSortByFields.Availability)
	{
	    sql = "SELECT ";
	    sql += "\"ContentId\" ";
	    sql += "FROM " + tblContentsCenters + " ";
	    sql += "where \"ContentId\" in (" + tmp.toString() + ") ";
	    sql += "group by \"ContentId\" order by Count(*) ";
	}
	else
	{
	    sql = "SELECT  ";
	    sql += "\"ContentId\" ";
	    sql += "FROM " + tblContents + " ";
	    sql += "where \"ContentId\" in (" + tmp.toString() + ") ";

	    if (enmContentSortByFields == EnmContentSortByFields.ContentId)
	    {
		sql += " order by \"ContentId\" ";
	    }
	    else if (enmContentSortByFields == EnmContentSortByFields.Age)
	    {
		sql += " order by DAYS_BETWEEN (\"LatestUpdateDate\", Now()) ";
	    }
	    else if (enmContentSortByFields == EnmContentSortByFields.Views)
	    {
		sql += " order by \"ViewCount\" ";
	    }
	}

	if (isAscending == false)
	{
	    sql += " desc;";
	}
	else
	{
	    sql += ";";
	}

	pstmt = conn.prepareStatement(sql);
	rs = pstmt.executeQuery();

	contentIds = new ArrayList<Long>();

	while (rs.next())
	{
	    contentIds.add(rs.getLong(1));
	}

	rs.close();
	pstmt.close();

	return contentIds;
    }


    public static List<Long> GetContentIdsSortByPages(Connection conn, List<Long> contentIds, int limit, int offset,
                                                      EnmContentSortByFields enmContentSortByFields, boolean isAscending)
            throws SQLException
    {
	List<Long> newContentIds = new ArrayList<Long>();

	contentIds = GetContentIdsSort(conn, contentIds, enmContentSortByFields, isAscending);

	int total = contentIds.size();

	if (offset < total)
	{
	    int endIndex = offset + limit;

	    if (total < endIndex)
	    {
		endIndex = offset + (total - offset);
	    }

	    for (; offset < endIndex; offset++)
	    {
		newContentIds.add(contentIds.get(offset));
	    }
	}

	return newContentIds;
    }


    public static List<Long> getContentIdsFromSubDataByValue(Connection conn, String tableName, String fieldName, String value)
            throws SQLException
    {
	List<Long> contentIds = new ArrayList<Long>();
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT distinct ";
	sql += "\"ContentId\" ";
	sql += "FROM " + tableName + " ";
	sql += "where TRIM(LOWER(\"" + fieldName + "\")) = LOWER(TRIM(?)) ; ";

	pstmt = conn.prepareStatement(sql);
	pstmt.setNString(1, value);

	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    contentIds.add(rs.getLong(1));
	}

	rs.close();
	pstmt.close();

	return contentIds;
    }


    public static List<Long> GetContentIdsByAssetType(Connection conn, String assetType)
            throws SQLException
    {
	return getContentIdsFromSubDataByValue(conn, tblContentsAssetTypes, "AssetType", assetType);
    }


    public static List<Long> GetContentIdsByIndustry(Connection conn, String industry)
            throws SQLException
    {
	return getContentIdsFromSubDataByValue(conn, tblContentsIndustries, "Industry", industry);
    }


    public static List<Long> GetContentIdsBySolution(Connection conn, String solution)
            throws SQLException
    {
	return getContentIdsFromSubDataByValue(conn, tblContentsSolutions, "Solution", solution);
    }


    public static List<Long> GetContentIdsBySize(Connection conn, String size)
            throws SQLException
    {
	return getContentIdsFromSubDataByValue(conn, tblContentsSizes, "Size", size);
    }


    public static List<Long> GetContentIdsBySizes(Connection conn, List<String> sizes)
            throws SQLException
    {
	List<Long> contentIds = new ArrayList<Long>();
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	String[] sizesArr = sizes.toArray(new String[sizes.size()]);
	String sizeFilter = "";
	if (sizesArr.length > 0)
	{
	    sizeFilter = "'" + String.join("', '", sizesArr) + "'";
	}

	sql = "SELECT distinct ";
	sql += "\"ContentId\" ";
	sql += "FROM " + tblContentsSizes + " ";
	sql += "where \"Size\" in (" + sizeFilter + "); ";

	pstmt = conn.prepareStatement(sql);

	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    contentIds.add(rs.getLong(1));
	}

	rs.close();
	pstmt.close();

	return contentIds;
    }


    public static List<Long> GetContentIdsByContact(Connection conn, String contact)
            throws SQLException
    {
	return getContentIdsFromSubDataByValue(conn, tblContentsContacts, "Contact", contact);
    }


    public static List<Long> GetContentIdsByCenterIds(Connection conn, List<Long> centerIds)
            throws SQLException
    {
	if (centerIds.size() == 0)
	{
	    return centerIds;
	}

	Long[] centerIdsArr = centerIds.toArray(new Long[centerIds.size()]);
	int i, arrLen = centerIdsArr.length;
	StringBuilder tmp = new StringBuilder();
	for (i = 0; i < arrLen - 1; i++)
	    tmp.append(centerIdsArr[i] + ", ");
	tmp.append(centerIdsArr[arrLen - 1]);

	List<Long> contentIds = new ArrayList<Long>();
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT distinct ";
	sql += "\"ContentId\" ";
	sql += "FROM " + tblContentsCenters + " ";
	sql += "where \"CenterId\" in (" + tmp.toString() + ");";

	pstmt = conn.prepareStatement(sql);
	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    contentIds.add(rs.getLong(1));
	}

	rs.close();
	pstmt.close();

	return contentIds;
    }


    private static List<String> getContentsSubDataByContentId(Connection conn, String tableName, String fieldName, long contentId)
            throws SQLException
    {
	List<String> valueList = new ArrayList<String>();
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "\"" + fieldName + "\" ";
	sql += "FROM " + tableName + " ";
	sql += "where \"ContentId\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, contentId);

	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    valueList.add(rs.getNString(1));
	}

	rs.close();
	pstmt.close();

	return valueList;
    }


    public static List<String> GetAssetTypesByContentId(Connection conn, long contentId)
            throws SQLException
    {
	return getContentsSubDataByContentId(conn, tblContentsAssetTypes, "AssetType", contentId);
    }


    public static List<String> GetIndustriesByContentId(Connection conn, long contentId)
            throws SQLException
    {
	return getContentsSubDataByContentId(conn, tblContentsIndustries, "Industry", contentId);
    }


    public static List<String> GetSolutionsByContentId(Connection conn, long contentId)
            throws SQLException
    {
	return getContentsSubDataByContentId(conn, tblContentsSolutions, "Solution", contentId);
    }


    public static List<String> GetSizesByContentId(Connection conn, long contentId)
            throws SQLException
    {
	return getContentsSubDataByContentId(conn, tblContentsSizes, "Size", contentId);
    }


    public static List<String> GetContactsByContentId(Connection conn, long contentId)
            throws SQLException
    {
	return getContentsSubDataByContentId(conn, tblContentsContacts, "Contact", contentId);
    }


    public static List<Long> GetCenterIdsByContentId(Connection conn, long contentId)
            throws SQLException
    {
	List<Long> centerIds = new ArrayList<Long>();
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT  ";
	sql += "\"CenterId\" ";
	sql += "FROM " + tblContentsCenters + " ";
	sql += "where \"ContentId\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, contentId);

	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    centerIds.add(rs.getLong(1));
	}

	rs.close();
	pstmt.close();

	return centerIds;
    }


    public static List<ContentDataComment> GetCommentsByContentId(Connection conn, long contentId)
            throws SQLException
    {
	List<ContentDataComment> contentDataComments = new ArrayList<ContentDataComment>();
	ContentDataComment contentDataComment = null;
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "\"ContentId\", ";
	sql += "\"Comment\", ";
	sql += "\"CreatedOn\", ";
	sql += "\"CreatedBy\" ";
	sql += "FROM " + tblContentsComments + " ";
	sql += "where \"ContentId\" = ? ";
	sql += "order by \"CreatedOn\" desc;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, contentId);

	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    contentDataComment = new ContentDataComment();
	    contentDataComment.ContentId = rs.getLong(1);
	    contentDataComment.Comment = rs.getNString(2);
	    contentDataComment.CommentedOn = rs.getTimestamp(3);
	    contentDataComment.CommentedById = rs.getNString(4);
	    contentDataComment.CommentedBy = UserDBUtils.GetUsersDataByUsersId(conn, rs.getNString(4));

	    contentDataComments.add(contentDataComment);
	}

	rs.close();
	pstmt.close();

	return contentDataComments;
    }


    public static ContentDataRating GetContentRatingDetails(Connection conn, long contentId, String userId)
            throws SQLException
    {
	ContentDataRating contentDataRating = null;
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "\"ContentId\", "; // 1
	sql += "\"Rating\", "; // 2
	sql += "\"CreatedOn\", "; // 3
	sql += "\"CreatedBy\" "; // 4
	sql += "FROM " + tblContentsRatings + " ";
	sql += "where Lower(TriM(\"CreatedBy\")) = Lower(Trim(?)) "; // 1
	sql += "and \"ContentId\" = ?;"; // 2

	pstmt = conn.prepareStatement(sql);
	pstmt.setNString(1, userId);
	pstmt.setLong(2, contentId);

	rs = pstmt.executeQuery();

	if (rs.next())
	{
	    contentDataRating = new ContentDataRating();

	    contentDataRating.ContentId = rs.getLong(1);
	    contentDataRating.Rating = rs.getInt(2);
	    contentDataRating.CreatedOn = rs.getTimestamp(3);
	    contentDataRating.CreatedBy = rs.getString(4);
	}

	rs.close();
	pstmt.close();

	return contentDataRating;
    }


    public static long GetCountRatingByContentId(Connection conn, long contentId)
            throws SQLException
    {
	long count = 0;

	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "Count(*) ";
	sql += "FROM " + tblContentsRatings + " ";
	sql += "where \"ContentId\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, contentId);

	rs = pstmt.executeQuery();
	if (rs.next())
	{
	    count = rs.getLong(1);
	}

	rs.close();
	pstmt.close();

	return count;
    }


    public static double GetAverageRatingByContentId(Connection conn, long contentId)
            throws SQLException
    {
	double rating = 0;

	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "IfNull(AVG(\"Rating\"), 0) ";
	sql += "FROM " + tblContentsRatings + " ";
	sql += "where \"ContentId\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, contentId);

	rs = pstmt.executeQuery();
	if (rs.next())
	{
	    rating = rs.getDouble(1);
	    rating = (double) Math.round(rating * 100) / 100;
	}

	rs.close();
	pstmt.close();

	return rating;
    }


    public static ContentData GetContentByContentId(Connection conn, long contentId)
            throws SQLException
    {
	ContentData contentData = null;
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "\"ContentId\", "; // 1
	sql += "\"Title\", "; // 2
	sql += "\"Description\", "; // 3
	sql += "\"ReleaseDate\", "; // 4
	sql += "\"Status\", "; // 5
	sql += "\"LatestUpdateDate\", "; // 6
	sql += "\"LatestUpdatedByUser\", "; // 7
	sql += "\"OwnerId\", "; // 8
	sql += "\"SubmittedOn\", "; // 9
	sql += "\"BannerImage_CMIS_DocumentId\", "; // 10
	sql += "\"WalkthroughVideo_CMIS_DocumentId\", "; // 11
	sql += "\"SetupGuide_CMIS_DocumentId\", "; // 12
	sql += "\"PresenterGuide_CMIS_DocumentId\", "; // 13
	sql += "\"ViewCount\", "; // 14
	sql += "\"UsageCount\", "; // 15
	sql += "DAYS_BETWEEN (\"LatestUpdateDate\", Now()) as \"Age\" "; // 16
	sql += "FROM " + tblContents + " ";
	sql += "where \"ContentId\" = ?; "; // 1

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, contentId);

	rs = pstmt.executeQuery();

	if (rs.next())
	{
	    contentData = new ContentData();

	    contentData.ContentId = rs.getLong(1);
	    contentData.Title = rs.getString(2);
	    contentData.Description = rs.getString(3);
	    contentData.CenterIds = GetCenterIdsByContentId(conn, rs.getLong(1));
	    contentData.ReleaseDate = rs.getDate(4);
	    contentData.Status = rs.getString(5);
	    contentData.LatestUpdateDate = rs.getDate(6);
	    contentData.LatestUpdateByUser = rs.getString(7);
	    contentData.OwnerId = rs.getString(8);
	    contentData.SubmittedOn = rs.getDate(9);
	    contentData.BannerImage_CMIS_DocumentId = rs.getLong(10);
	    contentData.WalkthroughVideo_CMIS_DocumentId = rs.getLong(11);
	    contentData.SetupGuide_CMIS_DocumentId = rs.getLong(12);
	    contentData.PresenterGuide_CMIS_DocumentId = rs.getLong(13);
	    contentData.ViewCount = rs.getLong(14);
	    contentData.UsageCount = rs.getLong(15);
	    contentData.Age = rs.getLong(16);

	    contentData.UsersCount = UserDBUtils.GetUsersCount(conn);
	    contentData.AssetTypes = GetAssetTypesByContentId(conn, contentId);
	    contentData.Industries = GetIndustriesByContentId(conn, contentId);
	    contentData.Solutions = GetSolutionsByContentId(conn, contentId);
	    contentData.Sizes = GetSizesByContentId(conn, contentId);
	    contentData.Contacts = GetContactsByContentId(conn, contentId);
	    contentData.CountRating = GetCountRatingByContentId(conn, contentId);
	    contentData.AverageRating = GetAverageRatingByContentId(conn, contentId);

	    contentData.BannerImage_CMISDocument = CMISDocumentDBUtils.GetCMISDocumentById(conn, contentData.BannerImage_CMIS_DocumentId);
	    contentData.WalkthroughVideo_CMISDocument = CMISDocumentDBUtils.GetCMISDocumentById(conn,
	                                                                                        contentData.WalkthroughVideo_CMIS_DocumentId);
	    contentData.SetupGuide_CMISDocument = CMISDocumentDBUtils.GetCMISDocumentById(conn, contentData.SetupGuide_CMIS_DocumentId);
	    contentData.ShowcaseOnePager_CMISDocument = CMISDocumentDBUtils.GetCMISDocumentById(conn, contentData.ShowcaseOnePager_CMIS_DocumentId);
	    contentData.PresenterGuide_CMISDocument = CMISDocumentDBUtils.GetCMISDocumentById(conn,
	                                                                                      contentData.PresenterGuide_CMIS_DocumentId);
	    contentData.InRoleVideoDataList = InRoleVideoDBUtils.GetInRoleVideoDataByContentId(conn, contentId);
	}

	rs.close();
	pstmt.close();

	return contentData;
    }


    public static long GetCMISDocumentIdOfInRoleVideoId(Connection conn, long inRoleVideoId)
            throws SQLException
    {
	long cmisDocumentId = 0L;
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "\"InRoleVideo_CMIS_DocumentId\" ";
	sql += "FROM " + tblContentsInRoleVideos + " ";
	sql += "where \"Id\" = ?;"; // 1 pictureId

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, inRoleVideoId);

	rs = pstmt.executeQuery();

	if (rs.next())
	{
	    cmisDocumentId = rs.getLong(1);
	}

	rs.close();
	pstmt.close();

	return cmisDocumentId;
    }


    public static void addViewCount(Connection conn, long contentId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;

	sql = "update " + tblContents + " ";
	sql += "set  \"ViewCount\" = ifnull(\"ViewCount\", 0) + 1 ";
	sql += "where \"ContentId\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, contentId);

	pstmt.execute();
	pstmt.close();
    }


    public static void addUsageCount(Connection conn, long contentId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;

	sql = "update " + tblContents + " ";
	sql += "set  \"UsageCount\" = ifnull(\"UsageCount\", 0) + 1 ";
	sql += "where \"ContentId\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, contentId);

	pstmt.execute();
	pstmt.close();
    }


    public static void addRating(Connection conn, long contentId, int rating, String userId)
            throws SQLException
    {
	List<String> sqlFields = new ArrayList<String>();
	List<String> sqlValues = new ArrayList<String>();
	String sql = "";
	PreparedStatement pstmt = null;

	sqlFields.add("ContentId");
	sqlValues.add("?"); // 1

	sqlFields.add("Rating");
	sqlValues.add("?"); // 2

	sqlFields.add("CreatedOn");
	sqlValues.add("Now()");

	sqlFields.add("CreatedBy");
	sqlValues.add("?"); // 3

	sql = DBUtils.combineSQLInsertQuery(sqlFields, sqlValues, tblContentsRatings);
	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, contentId);
	pstmt.setInt(2, rating);
	pstmt.setNString(3, userId.toUpperCase());

	pstmt.execute();
	pstmt.close();
    }


    public static void updateRating(Connection conn, long contentId, int rating, String userId)
            throws SQLException
    {
	List<String> sqlFields = new ArrayList<String>();
	List<String> sqlValues = new ArrayList<String>();
	String sql = "";
	String sqlConditions = "";
	PreparedStatement pstmt = null;

	sqlFields.add("Rating");
	sqlValues.add("?"); // 1

	sqlConditions = " where \"ContentId\"  = ? ";
	sqlConditions += "and Lower(Trim(\"CreatedBy\")) = Lower(Trim(?));";

	sql = DBUtils.combineSQLUpdateQuery(sqlFields, sqlValues, tblContentsRatings, sqlConditions);

	pstmt = conn.prepareStatement(sql);
	pstmt.setInt(1, rating);
	pstmt.setLong(2, contentId);
	pstmt.setNString(3, userId.toUpperCase());

	pstmt.execute();
	pstmt.close();
    }


    private static void updateStatus(Connection conn, long contentId, String userId, String status)
            throws SQLException
    {
	List<String> sqlFields = new ArrayList<String>();
	List<String> sqlValues = new ArrayList<String>();
	String sql = "";
	String sqlConditions = "";
	PreparedStatement pstmt = null;

	sqlFields.add("UpdatedOn");
	sqlValues.add("Now()");

	sqlFields.add("UpdatedBy");
	sqlValues.add("?"); // 1

	sqlFields.add("Status");
	sqlValues.add("?"); // 2

	sqlConditions = " where \"ContentId\"  = ? "; // 3

	sql = DBUtils.combineSQLUpdateQuery(sqlFields, sqlValues, tblContents, sqlConditions);

	pstmt = conn.prepareStatement(sql);
	pstmt.setNString(1, userId);
	pstmt.setNString(2, status);
	pstmt.setLong(3, contentId);

	pstmt.execute();
	pstmt.close();
    }


    public static void updateStatus_To_Published(Connection conn, long contentId, String administratorId)
            throws SQLException
    {
	updateStatus(conn, contentId, administratorId, "Published");
    }


    public static void DeleteInRoleVideoById(Connection conn, long inRoleVideoId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;

	sql = "Delete from " + tblContentsInRoleVideos + " ";
	sql += "where \"Id\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, inRoleVideoId);

	pstmt.execute();
	pstmt.close();
    }
}
