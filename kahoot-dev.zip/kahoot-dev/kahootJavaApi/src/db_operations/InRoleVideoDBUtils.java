package db_operations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cmis_operations.classes.CMISDocument;
import contents.classes.data.ContentDataInRoleVideo;
import inrolevideos.classes.data.InRoleVideoData;
import inrolevideos.classes.data.InRoleVideoDataRating;
import utils.Utils;


public class InRoleVideoDBUtils
{
    private static final String	tblContentsInRoleVideoRatings = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblContentsInRoleVideoRatings
            + "\"";
    private static final String	tblContentsInRoleVideos	      = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblContentsInRoleVideos
            + "\"";

    private static String	sqnceContentsInRoleVideos	= "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.sqnceContentsInRoleVideos
            + "\"";
    private static final String	sqnceContentsInRoleVideoRatings	= "\"" + DBUtils.SchemaName + "\".\""
            + DBUtils.sqnceContentsInRoleVideoRatings + "\"";


    public static Long getNextContentInRoleVideosId(Connection connection)
            throws SQLException
    {
	return DBUtils.getNextSequenceId(connection, sqnceContentsInRoleVideos);
    }


    public static Long getNextContentInRoleVideoRatingId(Connection conn)
            throws SQLException
    {
	return DBUtils.getNextSequenceId(conn, sqnceContentsInRoleVideoRatings);
    }


    public static List<Long> GetCMISDocumentIdsByContentIdNotInInRoleVideoIds(Connection conn, long contentId, List<Long> notInRoleVideoIds)

            throws SQLException
    {
	List<Long> cmisDocumentIds = new ArrayList<Long>();
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	String strIds = Utils.CombineIdsToString(notInRoleVideoIds);

	sql = "SELECT ";
	sql += "\"InRoleVideo_CMIS_DocumentId\" ";
	sql += "FROM " + tblContentsInRoleVideos + " ";
	sql += "where \"ContentId\" = ? ";

	if (strIds.length() > 0)
	{
	    sql += "and \"Id\" not in (" + strIds + ");";
	}
	else
	{
	    sql += ";";
	}

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, contentId);

	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    cmisDocumentIds.add(rs.getLong(1));
	}

	rs.close();
	pstmt.close();

	return cmisDocumentIds;
    }


    public static boolean isInRoleVideoExists(Connection conn, long inRoleVideoId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Boolean blExists = false;

	sql = "SELECT count(*) from " + tblContentsInRoleVideos + " ";
	sql += "where \"Id\" = ?;"; // 1 In Role Video Id

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, inRoleVideoId);

	rs = pstmt.executeQuery();
	rs.next();

	if (rs.getLong(1) > 0)
	{
	    blExists = true;
	}

	rs.close();
	pstmt.close();

	return blExists;
    }


    public static boolean isInRoleVideoExists(Connection conn, long contentId, long inRoleVideoId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Boolean blExists = false;

	sql = "SELECT count(*) from " + tblContentsInRoleVideos + " ";
	sql += "where \"ContentId\" = ? "; // 1 content Id
	sql += "and \"Id\" = ?;"; // 2 picture Id

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, contentId);
	pstmt.setLong(2, inRoleVideoId);

	rs = pstmt.executeQuery();
	rs.next();

	if (rs.getLong(1) > 0)
	{
	    blExists = true;
	}

	rs.close();
	pstmt.close();

	return blExists;
    }


    public static int GetInRoleVideoCountByContentId(Connection conn, long contentId)
            throws SQLException
    {
	int count = 0;
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "Count(*) ";
	sql += "FROM " + tblContentsInRoleVideos + " ";
	sql += "where \"ContentId\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, contentId);

	rs = pstmt.executeQuery();
	rs.next();

	count = rs.getInt(1);

	rs.close();
	pstmt.close();

	return count;
    }


    public static List<ContentDataInRoleVideo> GetInRoleVideoDataByContentId(Connection conn, long contentId)
            throws SQLException
    {
	List<ContentDataInRoleVideo> contentInRoleVideoList = new ArrayList<ContentDataInRoleVideo>();
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	ContentDataInRoleVideo contentInRoleVideoData = null;

	sql = "SELECT ";
	sql += "\"Id\", ";
	sql += "\"InRoleVideo_CMIS_DocumentId\" ";
	sql += "FROM " + tblContentsInRoleVideos + " ";
	sql += "where \"ContentId\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, contentId);

	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    contentInRoleVideoData = new ContentDataInRoleVideo();

	    contentInRoleVideoData.Id = rs.getLong(1);
	    contentInRoleVideoData.CMISDocument = CMISDocumentDBUtils.GetCMISDocumentById(conn, rs.getLong(2));
	    contentInRoleVideoData.AverageRating = InRoleVideoDBUtils.GetAverageRatingByInRoleVideoId(conn, rs.getLong(1));
	    contentInRoleVideoData.CountRating = InRoleVideoDBUtils.GetCountRatingByInRoleVideoId(conn, rs.getLong(1));

	    contentInRoleVideoList.add(contentInRoleVideoData);
	}

	rs.close();
	pstmt.close();

	return contentInRoleVideoList;
    }


    public static List<InRoleVideoData> GetInRoleVideoDataByContentId(Connection conn, long contentId, String userId, int limit, int offset)
            throws SQLException
    {
	List<InRoleVideoData> inRoleVideoDatas = new ArrayList<InRoleVideoData>();
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	InRoleVideoData inRoleVideoData = null;

	sql = "SELECT ";
	sql += "\"Id\", "; // 1
	sql += "\"ContentId\", "; // 2
	sql += "\"CreatedOn\", "; // 3
	sql += "\"CreatedBy\", "; // 4
	sql += "\"InRoleVideo_CMIS_DocumentId\" "; // 5
	sql += "FROM " + tblContentsInRoleVideos + " ";
	sql += "where \"ContentId\" = ? ";

	if (limit > 0)
	{
	    sql += " limit " + limit + " offset " + offset;
	}

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, contentId);

	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    inRoleVideoData = new InRoleVideoData();

	    inRoleVideoData.Id = rs.getLong(1);
	    inRoleVideoData.ContentId = rs.getLong(2);
	    inRoleVideoData.CreatedOn = rs.getTimestamp(3);
	    inRoleVideoData.CreatedBy = rs.getString(4);
	    inRoleVideoData.CMISDocumentId = rs.getLong(5);

	    inRoleVideoData.CMISDocument = CMISDocumentDBUtils.GetCMISDocumentById(conn, rs.getLong(5));
	    inRoleVideoData.AverageRating = InRoleVideoDBUtils.GetAverageRatingByInRoleVideoId(conn, rs.getLong(1));
	    inRoleVideoData.CountRating = InRoleVideoDBUtils.GetCountRatingByInRoleVideoId(conn, rs.getLong(1));

	    inRoleVideoData.Rating = GetInRoleVideoRatingDetails(conn, rs.getLong(1), userId);

	    inRoleVideoDatas.add(inRoleVideoData);
	}

	rs.close();
	pstmt.close();

	return inRoleVideoDatas;
    }


    public static void AddInRoleVideo(Connection conn, long inRoleVideoId, long contentId, CMISDocument inRoleVideo_CMISDocument,
                                      String userId)
            throws SQLException
    {
	List<String> sqlFields = new ArrayList<String>();
	List<String> sqlValues = new ArrayList<String>();

	sqlFields.add("Id");
	sqlValues.add("?"); // 1

	sqlFields.add("ContentId");
	sqlValues.add("?"); // 2

	sqlFields.add("CreatedOn");
	sqlValues.add("Now()");

	sqlFields.add("CreatedBy");
	sqlValues.add("?"); // 3

	sqlFields.add("InRoleVideo_CMIS_DocumentId");
	sqlValues.add("?"); // 4

	String sql = DBUtils.combineSQLInsertQuery(sqlFields, sqlValues, tblContentsInRoleVideos);

	PreparedStatement pstmt = conn.prepareStatement(sql);

	pstmt.setLong(1, inRoleVideoId);
	pstmt.setLong(2, contentId);
	pstmt.setNString(3, userId);
	pstmt.setLong(4, inRoleVideo_CMISDocument.Id);

	pstmt.execute();
	pstmt.close();
    }


    public static void AddInRoleVideoFromList(Connection conn, long contentId, List<CMISDocument> inRoleVideos_CMISDocuments, String userId)
            throws SQLException
    {
	int i = 0;
	long InRoleVideoId = 0;

	for (; i < inRoleVideos_CMISDocuments.size(); i++)
	{
	    InRoleVideoId = InRoleVideoDBUtils.getNextContentInRoleVideosId(conn);
	    AddInRoleVideo(conn, InRoleVideoId, contentId, inRoleVideos_CMISDocuments.get(i), userId);
	}
    }


    public static InRoleVideoDataRating GetInRoleVideoRatingDetails(Connection conn, long inRoleVideoId, String userId)
            throws SQLException
    {
	InRoleVideoDataRating inRoleVideoDataRating = null;
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "\"Id\", "; // 1
	sql += "\"InRoleVideoId\", "; // 2
	sql += "\"Rating\", "; // 3
	sql += "\"CreatedOn\", "; // 4
	sql += "\"CreatedBy\" "; // 5
	sql += "FROM " + tblContentsInRoleVideoRatings + " ";
	sql += "where Lower(TriM(\"CreatedBy\")) = Lower(Trim(?)) "; // 1
	sql += "and \"InRoleVideoId\" = ?;"; // 2

	pstmt = conn.prepareStatement(sql);
	pstmt.setNString(1, userId);
	pstmt.setLong(2, inRoleVideoId);

	rs = pstmt.executeQuery();

	if (rs.next())
	{
	    inRoleVideoDataRating = new InRoleVideoDataRating();

	    inRoleVideoDataRating.RatingId = rs.getLong(1);
	    inRoleVideoDataRating.InRoleVideoId = rs.getLong(2);
	    inRoleVideoDataRating.Rating = rs.getInt(3);
	    inRoleVideoDataRating.CreatedOn = rs.getTimestamp(4);
	    inRoleVideoDataRating.CreatedBy = rs.getString(5);
	}

	rs.close();
	pstmt.close();

	return inRoleVideoDataRating;
    }


    public static long GetCountRatingByInRoleVideoId(Connection conn, long inRoleVideoId)
            throws SQLException
    {
	long count = 0;

	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "Count(*) ";
	sql += "FROM " + tblContentsInRoleVideoRatings + " ";
	sql += "where \"InRoleVideoId\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, inRoleVideoId);

	rs = pstmt.executeQuery();
	if (rs.next())
	{
	    count = rs.getLong(1);
	}

	rs.close();
	pstmt.close();

	return count;
    }


    public static double GetAverageRatingByInRoleVideoId(Connection conn, long inRoleVideoId)
            throws SQLException
    {
	double rating = 0;

	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "IfNull(AVG(\"Rating\"), 0) ";
	sql += "FROM " + tblContentsInRoleVideoRatings + " ";
	sql += "where \"InRoleVideoId\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, inRoleVideoId);

	rs = pstmt.executeQuery();
	if (rs.next())
	{
	    rating = rs.getDouble(1);
	    rating = (double) Math.round(rating * 100) / 100;
	}

	rs.close();
	pstmt.close();

	return rating;
    }


    public static void AddInRoleVideoRating(Connection conn, long ratingId, long inRoleVideoId, int rating, String userId)
            throws SQLException
    {
	List<String> sqlFields = new ArrayList<String>();
	List<String> sqlValues = new ArrayList<String>();
	String sql = "";
	PreparedStatement pstmt = null;

	sqlFields.add("Id");
	sqlValues.add("?"); // 1

	sqlFields.add("InRoleVideoId");
	sqlValues.add("?"); // 2

	sqlFields.add("Rating");
	sqlValues.add("?"); // 3

	sqlFields.add("CreatedOn");
	sqlValues.add("Now()");

	sqlFields.add("CreatedBy");
	sqlValues.add("?"); // 4

	sql = DBUtils.combineSQLInsertQuery(sqlFields, sqlValues, tblContentsInRoleVideoRatings);
	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, ratingId);
	pstmt.setLong(2, inRoleVideoId);
	pstmt.setInt(3, rating);
	pstmt.setNString(4, userId.toUpperCase());

	pstmt.execute();
    }


    public static void UpdateInRoleVideoRating(Connection conn, long inRoleVideoId, int rating, String userId)
            throws SQLException
    {
	List<String> sqlFields = new ArrayList<String>();
	List<String> sqlValues = new ArrayList<String>();
	String sql = "";
	String sqlConditions = "";
	PreparedStatement pstmt = null;

	sqlFields.add("Rating");
	sqlValues.add("?"); // 1

	sqlConditions = " where \"InRoleVideoId\"  = ? ";
	sqlConditions += "and Lower(Trim(\"CreatedBy\")) = Lower(Trim(?));";

	sql = DBUtils.combineSQLUpdateQuery(sqlFields, sqlValues, tblContentsInRoleVideoRatings, sqlConditions);

	pstmt = conn.prepareStatement(sql);
	pstmt.setInt(1, rating);
	pstmt.setLong(2, inRoleVideoId);
	pstmt.setNString(3, userId.toUpperCase());

	pstmt.execute();
	pstmt.close();
    }
}
