package db_operations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;


public class ParamDBUtils
{
    private static final String	sqlVwAssetTypes		   = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.sqlVwAssetTypes + "\"";
    private static final String	sqlVwIndustries		   = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.sqlVwIndustries + "\"";
    private static final String	sqlVwSolutions		   = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.sqlVwSolutions + "\"";
    private static final String	sqlVwRejectionCategoryList = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.sqlVwRejectionCategoryList
            + "\"";

    public static final String StatusInReview	  = "In Review";
    public static final String StatusPublished	  = "Published";
    public static final String StatusRejected	  = "Rejected";
    public static final String StatusArchived	  = "Archived";
    public static final String StatusUpdateNeeded = "Update Needed";


    public static List<String> getAssetTypes(Connection conn)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	List<String> assetTypes = new ArrayList<String>();

	sql = "SELECT ";
	sql += "\"Name\" from ";
	sql += sqlVwAssetTypes + ";";

	pstmt = conn.prepareStatement(sql);
	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    assetTypes.add(rs.getNString(1));
	}

	rs.close();
	pstmt.close();

	return assetTypes;
    }


    public static List<String> getIndustries(Connection conn)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	List<String> industries = new ArrayList<String>();

	sql = "SELECT ";
	sql += "\"Name\" from ";
	sql += sqlVwIndustries + ";";

	pstmt = conn.prepareStatement(sql);
	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    industries.add(rs.getNString(1));
	}

	rs.close();
	pstmt.close();

	return industries;
    }


    public static List<String> getRejectionCategoryList(Connection conn)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	List<String> rejectionCategoryList = new ArrayList<String>();

	sql = "SELECT ";
	sql += "\"Name\" from ";
	sql += sqlVwRejectionCategoryList + ";";

	pstmt = conn.prepareStatement(sql);
	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    rejectionCategoryList.add(rs.getNString(1));
	}

	rs.close();
	pstmt.close();

	return rejectionCategoryList;
    }


    public static List<String> getSolutions(Connection conn)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	List<String> solutions = new ArrayList<String>();

	sql = "SELECT ";
	sql += "\"Name\" from ";
	sql += sqlVwSolutions + ";";

	pstmt = conn.prepareStatement(sql);
	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    solutions.add(rs.getNString(1));
	}

	rs.close();
	pstmt.close();

	return solutions;
    }


    public static List<String> getSizes()
    {
	List<String> sizes = new ArrayList<String>();

	sizes.add("Small");
	sizes.add("Medium");
	sizes.add("Large");

	return sizes;
    }


    public static List<String> getStatuses()
    {
	List<String> statuses = new ArrayList<String>();

	statuses.add(StatusInReview);
	statuses.add(StatusPublished);
	statuses.add(StatusRejected);
	statuses.add(StatusArchived);
	statuses.add(StatusUpdateNeeded);

	return statuses;
    }
}
