package db_operations;

import java.util.List;


public class SQLFieldsAndQueries
{
    public List<String>	SQLFields;
    public List<String>	SQLValues;
}
