package db_operations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cmis_operations.classes.CMISDocument;
import db_operations.utils.EnmStorySortByFields;
import stories.classes.data.StoryData;
import stories.classes.data.StoryDataContent;
import stories.classes.data.StoryDataDocument;


public class StoryDBUtils
{
    private static final String	tblStories	    = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblStories + "\"";
    private static final String	tblStoriesContents  = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblStoriesContents + "\"";
    private static final String	tblStoriesDocuments = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblStoriesDocuments + "\"";

    private static final String	sqnceStories	      = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.sqnceStories + "\"";
    private static final String	sqnceStoriesDocuments = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.sqnceStoriesDocuments + "\"";


    public static Long getNextStoryId(Connection conn)
            throws SQLException
    {
	return DBUtils.getNextSequenceId(conn, sqnceStories);
    }


    public static Long getNextStoriesDocumentId(Connection conn)
            throws SQLException
    {
	return DBUtils.getNextSequenceId(conn, sqnceStoriesDocuments);
    }


    public static boolean isStoryIdExists(Connection conn, long storyId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	boolean blExists = false;

	sql = "SELECT count(*) from " + tblStories + " ";
	sql += "where \"Id\" = ? "; // 1 story Id

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, storyId);

	rs = pstmt.executeQuery();
	rs.next();

	if (rs.getLong(1) > 0)
	{
	    blExists = true;
	}

	rs.close();
	pstmt.close();

	return blExists;
    }


    public static boolean isStoryDocumentIdExists(Connection conn, long storyDocumentId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	boolean blExists = false;

	sql = "SELECT count(*) from " + tblStoriesDocuments + " ";
	sql += "where \"Id\" = ? "; // 1 story Document Id

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, storyDocumentId);

	rs = pstmt.executeQuery();
	rs.next();

	if (rs.getLong(1) > 0)
	{
	    blExists = true;
	}

	rs.close();
	pstmt.close();

	return blExists;
    }


    public static List<Long> GetStoryIds(Connection conn, String title)
            throws SQLException
    {
	List<Long> storyIds = new ArrayList<Long>();
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String sqlConditions = "";
	int colId = 0;
	int titleCol = 0;

	sql = "SELECT distinct ";
	sql += "\"Id\" ";
	sql += "FROM " + tblStories + " ";

	// Search by title
	if (title != null)
	{
	    if (title != "")
	    {
		if (sqlConditions == "")
		{
		    sqlConditions += " where ";
		}
		else
		{
		    sqlConditions += " and ";
		}
		sqlConditions += "LOWER(\"Title\") like  LOWER(?)";
		colId++;
		titleCol = colId;
	    }
	}

	sql += sqlConditions;

	pstmt = conn.prepareStatement(sql);

	// Search by title
	if (title != null)
	{
	    if (title != "")
	    {
		pstmt.setNString(titleCol, "%" + title + "%");
	    }
	}

	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    storyIds.add(rs.getLong(1));
	}

	rs.close();
	pstmt.close();

	return storyIds;
    }


    public static List<Long> GetStoryIdsSort(Connection conn, List<Long> storyIds, EnmStorySortByFields enmStorySortByFields,
                                             boolean isAscending)
            throws SQLException
    {
	if (storyIds.size() == 0)
	{
	    return storyIds;
	}

	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	Long[] storyIdsArr = storyIds.toArray(new Long[storyIds.size()]);
	int i, arrLen = storyIdsArr.length;
	StringBuilder tmp = new StringBuilder();
	for (i = 0; i < arrLen - 1; i++)
	    tmp.append(storyIdsArr[i] + ", ");
	tmp.append(storyIdsArr[arrLen - 1]);

	sql = "SELECT distinct ";
	sql += "\"Id\" ";
	sql += "FROM " + tblStories + " ";
	sql += "where \"Id\" in (" + tmp.toString() + ") ";

	if (enmStorySortByFields == EnmStorySortByFields.StoryId)
	{
	    sql += "order by \"Id\"";
	}

	if (isAscending == false)
	{
	    sql += "desc";
	}
	sql += ";";

	pstmt = conn.prepareStatement(sql);
	rs = pstmt.executeQuery();

	storyIds = new ArrayList<Long>();

	while (rs.next())
	{
	    storyIds.add(rs.getLong(1));
	}

	rs.close();
	pstmt.close();

	return storyIds;
    }


    public static List<Long> GetStoryIdsSortByPages(Connection conn, List<Long> storyIds, int limit, int offset,
                                                    EnmStorySortByFields enmStorySortByFields, boolean isAscending)
            throws SQLException
    {
	if (storyIds.size() == 0)
	{
	    return storyIds;
	}

	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	Long[] storyIdsArr = storyIds.toArray(new Long[storyIds.size()]);
	int i, arrLen = storyIdsArr.length;
	StringBuilder tmp = new StringBuilder();
	for (i = 0; i < arrLen - 1; i++)
	    tmp.append(storyIdsArr[i] + ", ");
	tmp.append(storyIdsArr[arrLen - 1]);

	sql = "SELECT distinct ";
	sql += "\"Id\" ";
	sql += "FROM " + tblStories + " ";
	sql += "where \"Id\" in (" + tmp.toString() + ") ";

	if (enmStorySortByFields == EnmStorySortByFields.StoryId)
	{
	    sql += "order by \"Id\"";
	}

	if (isAscending == false)
	{
	    sql += "desc";
	}
	sql += " limit " + limit + " offset " + offset + ";";

	pstmt = conn.prepareStatement(sql);
	rs = pstmt.executeQuery();

	storyIds = new ArrayList<Long>();

	while (rs.next())
	{
	    storyIds.add(rs.getLong(1));
	}

	rs.close();
	pstmt.close();

	return storyIds;
    }


    public static List<Long> GetStoryIdsByContentIds(Connection conn, List<Long> contentIds)
            throws SQLException
    {
	if (contentIds.size() == 0)
	{
	    return contentIds;
	}

	Long[] contentIdsArr = contentIds.toArray(new Long[contentIds.size()]);
	int i, arrLen = contentIdsArr.length;
	StringBuilder tmp = new StringBuilder();
	for (i = 0; i < arrLen - 1; i++)
	    tmp.append(contentIdsArr[i] + ", ");
	tmp.append(contentIdsArr[arrLen - 1]);

	List<Long> storyIds = new ArrayList<Long>();
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT distinct ";
	sql += "\"StoryId\" ";
	sql += "FROM " + tblStoriesContents + " ";
	sql += "where \"ContentId\" in (" + tmp.toString() + ");";

	pstmt = conn.prepareStatement(sql);
	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    storyIds.add(rs.getLong(1));
	}

	rs.close();
	pstmt.close();

	return storyIds;
    }


    public static List<StoryDataContent> GetStoryContentsByStoryId(Connection conn, long storyId)
            throws SQLException
    {
	List<StoryDataContent> storyContents = new ArrayList<StoryDataContent>();
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	StoryDataContent storyDataContent = null;

	sql = "SELECT ";
	sql += "\"ContentId\", ";
	sql += "\"StoryId\", ";
	sql += "\"CreatedOn\", ";
	sql += "\"CreatedBy\" ";
	sql += "FROM " + tblStoriesContents + " ";
	sql += "where \"StoryId\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, storyId);

	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    storyDataContent = new StoryDataContent();

	    storyDataContent.ContentId = rs.getLong(1);
	    storyDataContent.StoryId = rs.getLong(2);
	    storyDataContent.CreatedOn = rs.getTimestamp(3);
	    storyDataContent.CreatedBy = rs.getString(4);

	    storyContents.add(storyDataContent);
	}

	rs.close();
	pstmt.close();

	return storyContents;
    }


    public static StoryDataDocument GetStoryDocumentById(Connection conn, long storyDocumentId)
            throws SQLException
    {
	StoryDataDocument storyDataDocument = null;
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "\"Id\", ";
	sql += "\"StoryId\", ";
	sql += "\"CreatedOn\", ";
	sql += "\"CreatedBy\", ";
	sql += "\"StoryDocument_CMIS_DocumentId\" ";
	sql += "FROM " + tblStoriesDocuments + " ";
	sql += "where \"Id\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, storyDocumentId);

	rs = pstmt.executeQuery();

	if (rs.next())
	{
	    storyDataDocument = new StoryDataDocument();

	    storyDataDocument.Id = rs.getLong(1);
	    storyDataDocument.StoryId = rs.getLong(2);
	    storyDataDocument.CreatedOn = rs.getTimestamp(3);
	    storyDataDocument.CreatedBy = rs.getString(4);
	    storyDataDocument.CMISDocumentId = rs.getLong(5);
	    storyDataDocument.CMISDocument = CMISDocumentDBUtils.GetCMISDocumentById(conn, rs.getLong(5));
	}

	rs.close();
	pstmt.close();

	return storyDataDocument;
    }


    public static List<StoryDataDocument> GetStoryDocumentsByStoryId(Connection conn, long storyId)
            throws SQLException
    {
	List<StoryDataDocument> storyDocuments = new ArrayList<StoryDataDocument>();
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "\"Id\" ";
	sql += "FROM " + tblStoriesDocuments + " ";
	sql += "where \"StoryId\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, storyId);

	rs = pstmt.executeQuery();
	while (rs.next())
	{
	    storyDocuments.add(GetStoryDocumentById(conn, rs.getLong(1)));
	}

	rs.close();
	pstmt.close();
	return storyDocuments;
    }


    public static StoryData GetStoryById(Connection conn, long storyId)
            throws SQLException
    {
	StoryData storyData = null;
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "\"Id\", "; // 1
	sql += "\"CreatedOn\", "; // 2
	sql += "\"CreatedBy\", "; // 3
	sql += "\"UpdatedOn\", "; // 4
	sql += "\"UpdatedBy\", "; // 5
	sql += "\"Description\", "; // 6
	sql += "\"Title\" "; // 7
	sql += "FROM " + tblStories + " ";
	sql += "where \"Id\" = ?;";// 1

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, storyId);

	rs = pstmt.executeQuery();

	if (rs.next())
	{
	    storyData = new StoryData();

	    storyData.StoryId = rs.getLong(1);
	    storyData.CreatedOn = rs.getTimestamp(2);
	    storyData.CreatedBy = rs.getString(3);
	    storyData.UpdatedOn = rs.getTimestamp(4);
	    storyData.UpdatedBy = rs.getString(5);
	    storyData.Description = rs.getString(6);
	    storyData.Title = rs.getString(7);

	    storyData.StoryContents = GetStoryContentsByStoryId(conn, storyId);
	    storyData.Documents = GetStoryDocumentsByStoryId(conn, storyId);
	}

	rs.close();
	pstmt.close();

	return storyData;
    }


    public static void AddContentsFromList(Connection conn, long storyId, List<Long> contentIds, String userId)
            throws SQLException
    {
	int i = 0;
	List<String> sqlFields = new ArrayList<String>();
	List<String> sqlValues = new ArrayList<String>();

	sqlFields.add("StoryId");
	sqlValues.add("?"); // 1

	sqlFields.add("ContentId");
	sqlValues.add("?"); // 2

	sqlFields.add("CreatedOn");
	sqlValues.add("Now()");

	sqlFields.add("CreatedBy");
	sqlValues.add("?"); // 3

	String sql = DBUtils.combineSQLInsertQuery(sqlFields, sqlValues, tblStoriesContents);
	PreparedStatement pstmt = null;

	for (; i < contentIds.size(); i++)
	{
	    pstmt = conn.prepareStatement(sql);

	    pstmt.setLong(1, storyId);
	    pstmt.setLong(2, contentIds.get(i));
	    pstmt.setNString(3, userId);

	    pstmt.execute();
	    pstmt.close();
	}
    }


    public static void AddDocumentRecord(Connection conn, long documentId, long storyId, CMISDocument document_CMISDocument, String userId)
            throws SQLException
    {
	List<String> sqlFields = new ArrayList<String>();
	List<String> sqlValues = new ArrayList<String>();

	sqlFields.add("Id");
	sqlValues.add("?"); // 1

	sqlFields.add("StoryId");
	sqlValues.add("?"); // 2

	sqlFields.add("CreatedOn");
	sqlValues.add("Now()");

	sqlFields.add("CreatedBy");
	sqlValues.add("?"); // 3

	sqlFields.add("StoryDocument_CMIS_DocumentId");
	sqlValues.add("?"); // 4

	String sql = DBUtils.combineSQLInsertQuery(sqlFields, sqlValues, tblStoriesDocuments);

	PreparedStatement pstmt = conn.prepareStatement(sql);

	pstmt.setLong(1, documentId);
	pstmt.setLong(2, storyId);
	pstmt.setNString(3, userId);
	pstmt.setLong(4, document_CMISDocument.Id);

	pstmt.execute();
	pstmt.close();
    }


    public static void AddDocumentFromList(Connection conn, long storyId, List<CMISDocument> documents_CMISDocuments, String userId)
            throws SQLException
    {
	int i = 0;
	long DocumentId = 0;

	for (; i < documents_CMISDocuments.size(); i++)
	{
	    DocumentId = getNextStoriesDocumentId(conn);
	    AddDocumentRecord(conn, DocumentId, storyId, documents_CMISDocuments.get(i), userId);
	}
    }


    public static void DeleteMappingsStoryandContent(Connection conn, long storyId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;

	sql = "Delete from " + tblStoriesContents + " ";
	sql += "where \"StoryId\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, storyId);

	pstmt.execute();
    }


    public static void DeleteDocumentById(Connection conn, long documentId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;

	sql = "Delete from " + tblStoriesDocuments + " ";
	sql += "where \"Id\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, documentId);

	pstmt.execute();
	pstmt.close();
    }
}
