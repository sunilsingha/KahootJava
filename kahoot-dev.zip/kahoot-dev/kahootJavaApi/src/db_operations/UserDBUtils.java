package db_operations;

import java.util.List;
import java.util.ArrayList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import users.classes.data.UserData;


public class UserDBUtils
{
    public static final String sqlVwUsers     = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.sqlVwUsers + "\"";
    public static final String sqlVwUserRoles = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.sqlVwUserRoles + "\"";

    public static final String RoleNameContentAdministrator	= "Content Administrator";
    public static final String RoleNameSAPCommunity		= "SAP Community";
    public static final String RoleNameExperienceCenterEmployee	= "Experience Center Employee";
    public static final String RoleNameContentCreator		= "Content Creator";


    public static Boolean IsUserExists(Connection conn, String userId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Boolean blExists = false;

	sql = "SELECT Count(*) FROM " + sqlVwUsers + " ";
	sql += "where LOWER(TRIM(\"UserId\")) = LOWER(TRIM(?));";

	pstmt = conn.prepareStatement(sql);
	pstmt.setNString(1, userId);

	rs = pstmt.executeQuery();
	rs.next();

	if (rs.getLong(1) > 0)
	{
	    blExists = true;
	}

	rs.close();
	pstmt.close();

	return blExists;
    }


    public static long getIdOfUserId(Connection conn, String userId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Long Id = null;

	sql = "SELECT ";
	sql += "\"Id\" "; // 1
	sql += "FROM " + sqlVwUsers + " ";
	sql += "where LOWER(TRIM(\"UserId\")) = LOWER(TRIM(?));";

	pstmt = conn.prepareStatement(sql);
	pstmt.setNString(1, userId);

	rs = pstmt.executeQuery();
	rs.next();

	Id = rs.getLong(1);

	rs.close();
	pstmt.close();

	return Id;
    }


    public static List<String> getUserRoles(Connection conn, long Id)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	List<String> roles = new ArrayList<String>();

	sql = "select ";
	sql += "\"Role\" ";
	sql += "from " + sqlVwUserRoles + " ";
	sql += "where \"UserId\" = ?;";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, Id);

	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    roles.add(rs.getString(1));
	}

	rs.close();
	pstmt.close();

	return roles;
    }


    public static Boolean IsUserContentCreatorOrAdministrator(Connection conn, String userId)
            throws SQLException
    {
	Boolean blIsCreatorOrAdministrator = false;

	Long Id = getIdOfUserId(conn, userId);
	List<String> roles = getUserRoles(conn, Id);

	for (String role : roles)
	{
	    if (role.equals(RoleNameContentCreator) || role.equals(RoleNameContentAdministrator))
	    {
		blIsCreatorOrAdministrator = true;
		break;
	    }
	}

	return blIsCreatorOrAdministrator;
    }


    public static Boolean IsUserContentAdministrator(Connection conn, String userId)
            throws SQLException
    {
	Boolean blIsCreatorOrAdministrator = false;

	Long Id = getIdOfUserId(conn, userId);
	List<String> roles = getUserRoles(conn, Id);

	for (String role : roles)
	{
	    if (role.equals(RoleNameContentAdministrator))
	    {
		blIsCreatorOrAdministrator = true;
		break;
	    }
	}

	return blIsCreatorOrAdministrator;
    }


    public static boolean IsUserContentCreatorOrExperienceCenterEmployee(Connection conn, String userId)
            throws SQLException
    {
	boolean IsCreatorOrExperienceCenterEmployee = false;

	Long Id = getIdOfUserId(conn, userId);
	List<String> roles = getUserRoles(conn, Id);

	for (String role : roles)
	{
	    if (role.equals(RoleNameContentCreator) || role.equals(RoleNameContentAdministrator))
	    {
		IsCreatorOrExperienceCenterEmployee = true;
		break;
	    }
	}

	return IsCreatorOrExperienceCenterEmployee;

    }


    public static long GetUsersCount(Connection conn)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	long count = 0;

	sql = "SELECT Count(*) ";
	sql += "FROM " + sqlVwUsers;

	pstmt = conn.prepareStatement(sql);
	rs = pstmt.executeQuery();
	rs.next();

	count = rs.getLong(1);

	rs.close();
	pstmt.close();

	return count;
    }


    public static UserData GetUsersDataById(Connection conn, long Id)
            throws SQLException
    {
	UserData usersData = null;
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	sql = "SELECT ";
	sql += "\"Id\", "; // 1
	sql += "\"CreatedOn\", "; // 2
	sql += "\"CreatedBy\", "; // 3
	sql += "\"UpdatedOn\", "; // 4
	sql += "\"UpdatedBy\", "; // 5
	sql += "\"UserId\", "; // 6
	sql += "\"Name\", "; // 7
	sql += "\"Email\", "; // 8
	sql += "\"IsAdmin\", "; // 9
	sql += "\"IsSuperAdmin\" "; // 10
	sql += "FROM " + sqlVwUsers + " ";
	sql += "where \"Id\" = ?";

	pstmt = conn.prepareStatement(sql);
	pstmt.setLong(1, Id);

	rs = pstmt.executeQuery();

	while (rs.next())
	{
	    usersData = new UserData();

	    usersData.Id = rs.getLong(1);
	    usersData.CreatedOn = rs.getTimestamp(2);
	    usersData.CreatedBy = rs.getNString(3);
	    usersData.UpdatedOn = rs.getTimestamp(4);
	    usersData.UpdatedBy = rs.getNString(5);
	    usersData.UserId = rs.getNString(6);
	    usersData.Name = rs.getNString(7);
	    usersData.Email = rs.getNString(8);
	    usersData.IsAdmin = rs.getNString(9).equals("Yes") ? true : false;
	    usersData.IsSuperAdmin = rs.getNString(10).equals("Yes") ? true : false;
	    usersData.Roles = getUserRoles(conn, usersData.Id);
	}

	rs.close();
	pstmt.close();

	return usersData;
    }


    public static UserData GetUsersDataByUsersId(Connection conn, String userId)
            throws SQLException
    {
	UserData usersData = new UserData();
	long Id = getIdOfUserId(conn, userId);
	usersData = GetUsersDataById(conn, Id);

	return usersData;
    }
}
