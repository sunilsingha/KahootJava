package db_operations.utils;

public enum EnmContentSortByFields {
    ContentId, Age, Views, Availability
}
