package db_operations.utils;

public enum EnmStorySortByFields {
    StoryId;
}
