package download;

import java.io.InputStream;
import java.io.IOException;
import java.io.PrintWriter;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import cmis_operations.classes.CMISDocument;
import db_operations.CMISDocumentDBUtils;
import utils.Utils;

import org.apache.chemistry.opencmis.client.api.Document;

import cmis_operations.CMISRepository;


/**
 * Servlet implementation class DownloadAssetsServlet
 */
@WebServlet("/content-assets")
public class DownloadAssetsServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public DownloadAssetsServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub
	String docid = request.getParameter("docid");

	if (docid == null)
	{
	    Utils.addErrorResponse(response, "Invalid request");
	    return;
	}

	// Connect to database
	InitialContext ctx;
	DataSource ds;
	Connection connection;

	try
	{
	    ctx = new InitialContext();
	    ds = (DataSource) ctx.lookup("java:comp/env/jdbc/DefaultDB");
	    connection = ds.getConnection();
	}
	catch (Exception e)
	{
	    Utils.addErrorResponse(response, "Error occurred while connecting to database.");
	    return;
	}

	// Checks Document Id exists
	CMISDocument cmisDocument = null;
	try
	{
	    if (CMISDocumentDBUtils.IsDocumentIdExists(connection, docid) == false)
	    {
		Utils.addErrorResponse(response, "Document Id deosn't exists.");
		try
		{
		    connection.close();
		}
		catch (Exception e)
		{
		    e.printStackTrace();
		    return;
		}
		return;
	    }
	    else
	    {
		cmisDocument = CMISDocumentDBUtils.GetCmisObjectIdByDocumentId(connection, docid);
	    }

	}
	catch (Exception e)
	{
	    Utils.addErrorResponse(response, "Error occurred.");
	    e.printStackTrace();

	    try
	    {
		connection.close();
	    }
	    catch (Exception ex)
	    {
		ex.printStackTrace();
		return;
	    }
	    return;
	}

	// Closes the connection
	try
	{
	    connection.close();
	}
	catch (Exception ex)
	{
	    ex.printStackTrace();
	    return;
	}

	// Opens the CMIS session,
	CMISRepository cmisRepository = null;

	try
	{
	    cmisRepository = new CMISRepository();
	    cmisRepository.sessionLogin();
	}
	catch (Exception e)
	{
	    e.printStackTrace();
	    Utils.addErrorResponse(response, "Error occurred while opening Repository session.");

	    try
	    {
		connection.close();
	    }
	    catch (Exception ex)
	    {
		ex.printStackTrace();
		return;
	    }
	    return;
	}

	Document newDocument = (Document) cmisRepository.session.getObject(cmisDocument.CMISObjectId);

	String filename = cmisDocument.FileName;
	response.setContentType("APPLICATION/OCTET-STREAM");
	response.setHeader("Content-Disposition", "attachment; filename=\"" + filename + "\"");
	PrintWriter out = response.getWriter();

	try
	{
	    InputStream fileInputStream = newDocument.getContentStream().getStream();

	    int i;
	    while ((i = fileInputStream.read()) != -1)
	    {
		out.write(i);
	    }
	    fileInputStream.close();
	    out.close();
	}
	catch (IOException e)
	{
	    throw new RuntimeException(e.getLocalizedMessage());
	}
    }
}
