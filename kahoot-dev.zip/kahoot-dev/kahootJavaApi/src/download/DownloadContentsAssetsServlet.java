package download;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.chemistry.opencmis.client.api.Document;

import cmis_operations.CMISRepository;
import utils.Utils;


/**
 * Servlet implementation class ContentsAssets
 */
@WebServlet("/download/assets")
public class DownloadContentsAssetsServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public DownloadContentsAssetsServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub
	String path = request.getParameter("p");

	if (path == null)
	{
	    Utils.addErrorResponse(response, "Invalid request");
	    return;
	}

	// Opens the CMIS session,
	CMISRepository cmisRepository = null;

	try
	{
	    cmisRepository = new CMISRepository();
	    cmisRepository.sessionLogin();
	}
	catch (Exception e)
	{
	    e.printStackTrace();
	    Utils.addErrorResponse(response, "Error occurred while opening Repository session.");
	    return;
	}

	Document newDocument = (Document) cmisRepository.session.getObjectByPath(path);

	if (newDocument == null)
	{
	    cmisRepository.session.clear();
	    Utils.addErrorResponse(response, "Document not found.");
	    return;
	}

	String filename = newDocument.getName();
	response.setContentType("APPLICATION/OCTET-STREAM");
	response.setHeader("Content-Disposition", "attachment; filename=\"" + filename + "\"");
	PrintWriter out = response.getWriter();

	try
	{
	    InputStream fileInputStream = newDocument.getContentStream().getStream();

	    int i;
	    while ((i = fileInputStream.read()) != -1)
	    {
		out.write(i);
	    }
	    fileInputStream.close();
	    out.close();
	}
	catch (IOException e)
	{
	    throw new RuntimeException(e.getLocalizedMessage());
	}

	cmisRepository.session.clear();
    }

}
