package inrolevideos;

import inrolevideos.classes.response.InRoleVideoAddResponse;
import inrolevideos.utils.AddOrUpdateInRoleVideoUtils;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cmis_operations.CMISRepository;
import cmis_operations.ContentCMISRepository;
import cmis_operations.classes.ContentFolders;
import db_operations.DBUtils;
import db_operations.InRoleVideoDBUtils;
import utils.RequestHelper;
import utils.Utils;


/**
 * Servlet implementation class AddInRoleVideoServlet
 */
@WebServlet("/api/in-role-videos/add-in-role-video")
public class AddInRoleVideoServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddInRoleVideoServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub
	String userId = new RequestHelper().getUserIdToResponse(response);
	if (userId == "")
	{
	    return;
	}

	// Connect to database
	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	// Reads Request Data and validates it
	AddOrUpdateInRoleVideoUtils addOrUpdateInRoleVideoUtils = new AddOrUpdateInRoleVideoUtils(request, response, conn);
	boolean blValidRequestData = false;

	try
	{
	    blValidRequestData = addOrUpdateInRoleVideoUtils.IsValidRequestData();
	}
	catch (Exception e)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while validating the fields - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	if (blValidRequestData == false)
	{
	    DBUtils.CloseConnection(conn);
	    return;
	}

	// Opens session in repository
	CMISRepository cmisRepository;

	try
	{
	    cmisRepository = new CMISRepository();
	    cmisRepository.sessionLogin();
	}
	catch (Exception e)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while connecting to CMIS repository - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	// Gets New Content Id
	try
	{
	    // Gets Next Sequence Id
	    addOrUpdateInRoleVideoUtils.setInRoleVideoId(InRoleVideoDBUtils.getNextContentInRoleVideosId(conn));

	}
	catch (Exception e)
	{
	    cmisRepository.session.clear();
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while retrieving Sequence Id - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	// Gets Folder Structure for Content in Document Repository
	ContentFolders contentFolders = null;
	ContentCMISRepository contentCMISRepository = new ContentCMISRepository(cmisRepository);

	try
	{
	    contentFolders = contentCMISRepository.GetContentFolders(addOrUpdateInRoleVideoUtils.getContentId());
	}
	catch (Exception e)
	{
	    cmisRepository.session.clear();
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while getting folder structure - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	// updates files and documents in database and repository
	try
	{
	    addOrUpdateInRoleVideoUtils.processUpdatingContent(cmisRepository, contentFolders);
	}
	catch (Exception e)
	{
	    cmisRepository.session.clear();
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while upading data and documents - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	// Closes connection and clears the session
	DBUtils.CloseConnection(conn);
	cmisRepository.session.clear();

	// Creates object to send response
	InRoleVideoAddResponse contentAddOrUpdateResponse = new InRoleVideoAddResponse();
	contentAddOrUpdateResponse.InRoleVideoId = addOrUpdateInRoleVideoUtils.getInRoleVideoId();
	contentAddOrUpdateResponse.Message = "New In-Role Video added.";

	// Sends the response back
	Utils.addSuccessResponseFromObject(response, contentAddOrUpdateResponse);
    }
}
