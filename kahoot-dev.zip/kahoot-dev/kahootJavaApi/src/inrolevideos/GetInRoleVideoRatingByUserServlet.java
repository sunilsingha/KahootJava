package inrolevideos;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db_operations.DBUtils;
import db_operations.InRoleVideoDBUtils;
import inrolevideos.classes.data.InRoleVideoDataRating;
import inrolevideos.classes.response.InRoleVideoRatingResponse;
import utils.RequestHelper;
import utils.Utils;
import validation.ValidateNumber;


/**
 * Servlet implementation class GetInRoleVideoRatingByUserServlet
 */
@WebServlet("/api/in-role-videos/get-in-role-video-rating-by-user")
public class GetInRoleVideoRatingByUserServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetInRoleVideoRatingByUserServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub

	// Gets UserId
	String userId = new RequestHelper().getUserIdToResponse(response);
	if (userId == "")
	{
	    return;
	}

	// Gets ContentId
	String strInRoleVideoId = request.getParameter("inRoleVideoId");

	if (strInRoleVideoId == null || strInRoleVideoId == "")
	{
	    Utils.addErrorResponse(response, "Provide 'inRoleVideoId'.");
	    return;
	}

	// Validates Content Id
	ValidateNumber validateNumber = new ValidateNumber(response, true);
	validateNumber.IsStringInput = true;
	validateNumber.StrInput = strInRoleVideoId;
	validateNumber.FieldName = "'inRoleVideoId'";
	validateNumber.IsRequired = true;
	validateNumber.IsAllCharactersNumber = true;
	validateNumber.IsLong = true;

	if (validateNumber.isValueNumericToResponse() == false)
	{
	    return;
	}

	// Parses Content Id
	long InRoleVideoId = Long.parseLong(strInRoleVideoId);

	// Connect to database
	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	try
	{
	    // Checks content Id exists
	    if (InRoleVideoDBUtils.isInRoleVideoExists(conn, InRoleVideoId) == false)
	    {
		Utils.addErrorResponse(response, "In-Role Video Id " + Long.toString(InRoleVideoId) + " not found.");
		DBUtils.CloseConnection(conn);
		return;
	    }

	    InRoleVideoRatingResponse inRoleVideoRatingResponse = null;
	    InRoleVideoDataRating inRoleVideoDataRating = InRoleVideoDBUtils.GetInRoleVideoRatingDetails(conn, InRoleVideoId, userId);

	    if (inRoleVideoDataRating == null)
	    {
		inRoleVideoRatingResponse = new InRoleVideoRatingResponse(userId);
	    }
	    else
	    {
		inRoleVideoRatingResponse = new InRoleVideoRatingResponse(inRoleVideoDataRating);
	    }

	    Utils.addSuccessResponseFromObject(response, inRoleVideoRatingResponse);

	}
	catch (Exception ex)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while retrieving data - " + ex.getMessage());
	    ex.printStackTrace();
	    return;
	}

	DBUtils.CloseConnection(conn);
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub
	doGet(request, response);
    }
}
