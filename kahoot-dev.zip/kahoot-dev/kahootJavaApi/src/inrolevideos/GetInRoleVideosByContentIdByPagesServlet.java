package inrolevideos;

import java.util.ArrayList;
import java.util.List;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db_operations.ContentDBUtils;
import db_operations.DBUtils;
import db_operations.InRoleVideoDBUtils;
import inrolevideos.classes.data.InRoleVideoData;
import inrolevideos.classes.response.InRoleVideoResponse;
import inrolevideos.classes.response.InRoleVideosByPagesResponse;
import utils.RequestHelper;
import utils.Utils;
import validation.ValidateNumber;


/**
 * Servlet implementation class GetInRoleVideosByContentIdByPages
 */
@WebServlet("/api/in-role-videos/get-in-role-videos-by-content-id-by-pages")
public class GetInRoleVideosByContentIdByPagesServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetInRoleVideosByContentIdByPagesServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub
	// Gets UserId
	String userId = new RequestHelper().getUserIdToResponse(response);
	if (userId == "")
	{
	    return;
	}

	// TODO Auto-generated method stub
	int pageSize = 20;
	int pageIndex = 1;

	// get request parameters
	String strPageIndex = request.getParameter("page_index");
	String strPageSize = request.getParameter("page_size");

	ValidateNumber validateNumber = new ValidateNumber(response, true);

	// checks for Page Index
	if (strPageIndex != null)
	{
	    if (strPageIndex != "")
	    {
		strPageIndex = strPageIndex.trim();

		validateNumber.IsStringInput = true;
		validateNumber.FieldName = "page_index";
		validateNumber.StrInput = strPageIndex;
		validateNumber.IsInteger = true;
		validateNumber.IsRequired = true;

		if (validateNumber.isValueNumericToResponse() == false)
		{
		    return;
		}

		pageIndex = Integer.parseInt(strPageIndex);
	    }
	}

	// checks for Page Size
	if (strPageSize != null)
	{
	    if (strPageSize != "")
	    {
		strPageSize = strPageSize.trim();

		validateNumber.IsStringInput = true;
		validateNumber.FieldName = "page_size";
		validateNumber.StrInput = strPageSize;
		validateNumber.IsInteger = true;
		validateNumber.IsRequired = true;

		if (validateNumber.isValueNumericToResponse() == false)
		{
		    return;
		}

		pageSize = Integer.parseInt(strPageSize);
	    }
	}

	// Gets ContentId
	String strContentId = request.getParameter("contentId");

	if (strContentId == null || strContentId == "")
	{
	    Utils.addErrorResponse(response, "Provide 'contentId'.");
	    return;
	}

	// Validates Content Id
	validateNumber.Reset();
	validateNumber.IsStringInput = true;
	validateNumber.StrInput = strContentId;
	validateNumber.FieldName = "'contentId'";
	validateNumber.IsRequired = true;
	validateNumber.IsAllCharactersNumber = true;
	validateNumber.IsLong = true;

	if (validateNumber.isValueNumericToResponse() == false)
	{
	    return;
	}

	// Parses Content Id
	long ContentId = Long.parseLong(strContentId);

	// Connect to database
	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	try
	{
	    if (ContentDBUtils.isContentExists(conn, ContentId) == false)
	    {
		Utils.addErrorResponse(response, "Content Id " + strContentId + " not found.");
		DBUtils.CloseConnection(conn);
		return;
	    }

	    int inRoleVideosCount = InRoleVideoDBUtils.GetInRoleVideoCountByContentId(conn, ContentId);
	    int total = inRoleVideosCount;
	    int pageCount = 0;
	    double dblPageCount = 0;
	    if (total > 0)
	    {
		dblPageCount = (int) Math.floor(total / pageSize);

		if (total > (pageSize * dblPageCount))
		{
		    pageCount = (int) dblPageCount + 1;
		}
		else
		{
		    pageCount = (int) dblPageCount;
		}
	    }

	    List<InRoleVideoData> inRoleVideoDatas = InRoleVideoDBUtils.GetInRoleVideoDataByContentId(conn, ContentId, userId, pageSize,
	                                                                                              (pageIndex - 1) * pageSize);
	    List<InRoleVideoResponse> inRoleVideosResponses = new ArrayList<InRoleVideoResponse>();
	    InRoleVideoResponse inRoleVideoResponse = null;

	    int i = 0;
	    for (; i < inRoleVideoDatas.size(); i++)
	    {
		inRoleVideoResponse = new InRoleVideoResponse(inRoleVideoDatas.get(i), userId);
		inRoleVideosResponses.add(inRoleVideoResponse);
	    }

	    InRoleVideosByPagesResponse inRoleVideosByPagesResponse = new InRoleVideosByPagesResponse();
	    inRoleVideosByPagesResponse.PageCount = pageCount;
	    inRoleVideosByPagesResponse.PageSize = pageSize;
	    inRoleVideosByPagesResponse.PageIndex = pageIndex;
	    inRoleVideosByPagesResponse.Total = total;
	    inRoleVideosByPagesResponse.InRoleVideos = inRoleVideosResponses;

	    Utils.addSuccessResponseFromObject(response, inRoleVideosByPagesResponse);
	}
	catch (Exception ex)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while retrieving data - " + ex.getMessage());
	    ex.printStackTrace();
	    return;
	}

	DBUtils.CloseConnection(conn);
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub
	doGet(request, response);
    }

}
