package inrolevideos;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

import db_operations.DBUtils;
import db_operations.InRoleVideoDBUtils;
import inrolevideos.classes.data.InRoleVideoDataRating;
import inrolevideos.classes.request.InRoleVideoRateRequest;
import utils.RequestHelper;
import utils.Utils;
import validation.ValidateNumber;
import validation.ValidateRequest;


/**
 * Servlet implementation class RateInRoleVideoServlet
 */
@WebServlet("/api/in-role-videos/rate-in-role-video")
public class RateInRoleVideoServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public RateInRoleVideoServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub

	String userId = new RequestHelper().getUserIdToResponse(response);
	if (userId == "")
	{
	    return;
	}

	// checks content type
	if (ValidateRequest.IsJSONRequest(request, response) == false)
	{
	    return;
	}

	// reads request data
	StringBuffer jb = new StringBuffer();
	String line = null;
	try
	{
	    BufferedReader reader = request.getReader();
	    while ((line = reader.readLine()) != null)
		jb.append(line);
	}
	catch (Exception e)
	{
	    Utils.addErrorResponse(response, "Invalid request.");
	    e.printStackTrace();
	    return;
	}

	// Parses JSOn String to object
	ObjectMapper mapper = new ObjectMapper();
	InRoleVideoRateRequest inRoleVideoRateRequest;

	// Parse JSON string to JSON object
	try
	{
	    String requestJson = jb.toString();
	    inRoleVideoRateRequest = mapper.readValue(requestJson, InRoleVideoRateRequest.class);
	}
	catch (Exception e)
	{
	    Utils.addErrorResponse(response, "Invalid request.");
	    e.printStackTrace();
	    return;
	}

	if (inRoleVideoRateRequest.InRoleVideoId == 0)
	{
	    Utils.addErrorResponse(response, "Invalid request.");
	    return;
	}

	// Validates Rating
	ValidateNumber validateNumber = new ValidateNumber(response, true);
	validateNumber.FieldName = "'Rating'";
	validateNumber.IntInput = inRoleVideoRateRequest.Rating;
	validateNumber.IsRequired = true;
	validateNumber.HasMaxValue = true;
	validateNumber.HasMinValue = true;
	validateNumber.MinimumIntValue = 1;
	validateNumber.MaximumIntValue = 5;

	if (validateNumber.isValueNumericToResponse() == false)
	{
	    return;
	}

	// Connects to database
	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	// Checks Content Id exists
	try
	{
	    // Checks content Id exists
	    if (InRoleVideoDBUtils.isInRoleVideoExists(conn, inRoleVideoRateRequest.InRoleVideoId) == false)
	    {
		Utils.addErrorResponse(response, "In-Role Video Id " + Long.toString(inRoleVideoRateRequest.InRoleVideoId) + " not found.");
		DBUtils.CloseConnection(conn);
		return;
	    }

	    InRoleVideoDataRating inRoleVideoDataRating = InRoleVideoDBUtils.GetInRoleVideoRatingDetails(conn,
	                                                                                                 inRoleVideoRateRequest.InRoleVideoId,
	                                                                                                 userId);

	    if (inRoleVideoDataRating == null)
	    {
		// Inserts rating in the database
		long ratingId = InRoleVideoDBUtils.getNextContentInRoleVideoRatingId(conn);
		InRoleVideoDBUtils.AddInRoleVideoRating(conn, ratingId, inRoleVideoRateRequest.InRoleVideoId, inRoleVideoRateRequest.Rating,
		                                        userId);
	    }
	    else
	    {
		InRoleVideoDBUtils.UpdateInRoleVideoRating(conn, inRoleVideoRateRequest.InRoleVideoId, inRoleVideoRateRequest.Rating,
		                                           userId);
	    }

	    DBUtils.CloseConnection(conn);
	}
	catch (Exception e)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	Utils.addSuccessResponse(response, "Rating updated.");
    }

}
