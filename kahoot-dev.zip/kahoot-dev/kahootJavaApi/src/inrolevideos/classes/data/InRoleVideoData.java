package inrolevideos.classes.data;

import java.sql.Timestamp;

import cmis_operations.classes.CMISDocument;


public class InRoleVideoData
{
    public long			 Id;
    public long			 ContentId;
    public Timestamp		 CreatedOn;
    public String		 CreatedBy;
    public long			 CMISDocumentId;
    public CMISDocument		 CMISDocument;
    public long			 CountRating;
    public double		 AverageRating;
    public InRoleVideoDataRating Rating;
}
