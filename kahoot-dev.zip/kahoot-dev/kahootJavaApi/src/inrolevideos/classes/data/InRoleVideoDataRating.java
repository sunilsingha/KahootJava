package inrolevideos.classes.data;

import java.sql.Timestamp;


public class InRoleVideoDataRating
{
    public long	     RatingId;
    public long	     InRoleVideoId;
    public Timestamp CreatedOn;
    public String    CreatedBy;
    public int	     Rating;
}
