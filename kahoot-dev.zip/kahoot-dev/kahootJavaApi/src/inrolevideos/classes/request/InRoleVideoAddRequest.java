package inrolevideos.classes.request;

import org.apache.commons.fileupload.FileItem;

import cmis_operations.classes.CMISDocument;


public class InRoleVideoAddRequest
{
    public String   strContentId;
    public FileItem InRoleVideoFile;

    // Assigned Dynamically
    public long		ContentId;
    public long		InRoleVideoId;
    public String	UserId;
    public CMISDocument	InRoleVideo_CMISDocument;
}
