package inrolevideos.classes.request;

public class InRoleVideoRateRequest
{
    public long	InRoleVideoId;
    public int	Rating;
}
