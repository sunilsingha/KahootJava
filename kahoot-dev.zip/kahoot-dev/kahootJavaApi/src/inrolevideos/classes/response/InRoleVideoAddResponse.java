package inrolevideos.classes.response;

public class InRoleVideoAddResponse
{
    public long	  InRoleVideoId;
    public String Message;
}
