package inrolevideos.classes.response;

import java.time.format.DateTimeFormatter;

import inrolevideos.classes.data.InRoleVideoDataRating;


public class InRoleVideoRatingResponse
{
    public InRoleVideoRatingResponse(InRoleVideoDataRating contentDataRating)
    {
	this.UserId = contentDataRating.CreatedBy;
	this.RatingOn = DateTimeFormatter.ISO_INSTANT.format(contentDataRating.CreatedOn.toInstant());
	this.Rating = contentDataRating.Rating;
	this.IsRatingProvided = true;
    }


    public InRoleVideoRatingResponse(String userId)
    {
	this.UserId = userId;
	this.IsRatingProvided = false;
    }

    public String  UserId;
    public String  RatingOn;
    public int	   Rating;
    public boolean IsRatingProvided;
}
