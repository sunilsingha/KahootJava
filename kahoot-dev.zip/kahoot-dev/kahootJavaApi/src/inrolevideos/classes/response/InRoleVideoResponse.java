package inrolevideos.classes.response;

import inrolevideos.classes.data.InRoleVideoData;


public class InRoleVideoResponse
{
    public InRoleVideoResponse(InRoleVideoData inRoleVideoData, String userId)
    {
	this.Id = inRoleVideoData.Id;
	this.Path = inRoleVideoData.CMISDocument.FilePath;
	this.FileSize = inRoleVideoData.CMISDocument.FileSize;
	this.CountRating = inRoleVideoData.CountRating;
	this.AverageRating = inRoleVideoData.AverageRating;

	if (inRoleVideoData.Rating != null)
	{
	    this.UserRating = new InRoleVideoRatingResponse(inRoleVideoData.Rating);
	}
	else
	{
	    this.UserRating = new InRoleVideoRatingResponse(userId);
	}
    }

    public long			     Id;
    public String		     Path;
    public long			     FileSize;
    public long			     CountRating;
    public double		     AverageRating;
    public InRoleVideoRatingResponse UserRating;
}
