package inrolevideos.classes.response;

import java.util.List;


public class InRoleVideosByPagesResponse
{
    public int			     PageCount;
    public int			     PageIndex;
    public int			     PageSize;
    public int			     Total;
    public List<InRoleVideoResponse> InRoleVideos;
}
