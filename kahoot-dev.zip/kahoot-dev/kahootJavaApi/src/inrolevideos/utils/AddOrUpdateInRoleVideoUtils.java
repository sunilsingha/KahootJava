package inrolevideos.utils;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import cmis_operations.CMISRepository;
import cmis_operations.classes.ContentFolders;
import db_operations.CMISDocumentDBUtils;
import db_operations.ContentDBUtils;
import db_operations.InRoleVideoDBUtils;
import db_operations.UserDBUtils;
import inrolevideos.classes.request.InRoleVideoAddRequest;
import utils.RequestHelper;
import utils.Utils;
import validation.ValidateFile;
import validation.ValidateFormFields;
import validation.ValidateNumber;
import validation.classes.EnumFieldType;
import validation.classes.FormField;


public class AddOrUpdateInRoleVideoUtils
{
    private HttpServletRequest	  request;
    private HttpServletResponse	  response;
    private Connection		  conn;
    private InRoleVideoAddRequest inRoleVideoAddRequest;


    public AddOrUpdateInRoleVideoUtils(HttpServletRequest _httpServletRequest, HttpServletResponse _httpServletResponse, Connection _conn)
    {
	request = _httpServletRequest;
	response = _httpServletResponse;
	conn = _conn;
    }


    public void setInRoleVideoId(long inRoleVideoId)
    {
	inRoleVideoAddRequest.InRoleVideoId = inRoleVideoId;
    }


    public long getInRoleVideoId()
    {
	return inRoleVideoAddRequest.InRoleVideoId;
    }


    public long getContentId()
    {
	return inRoleVideoAddRequest.ContentId;
    }


    public boolean IsValidRequestData()
            throws IOException, SQLException
    {
	// process only if its MultiPart content
	if (!ServletFileUpload.isMultipartContent(request))
	{
	    Utils.addErrorResponse(response, "Invalid request");
	    return false;
	}

	inRoleVideoAddRequest = new InRoleVideoAddRequest();
	inRoleVideoAddRequest.UserId = (new RequestHelper().getUser()).getName();

	DiskFileItemFactory factory = new DiskFileItemFactory();
	// factory.setSizeThreshold(209715200);
	ServletFileUpload upload = new ServletFileUpload(factory);
	// upload.setFileSizeMax(209715200);

	ValidateFormFields validateFormFields = getValidateFormFieldsList();

	try
	{
	    List<FileItem> fileItems = upload.parseRequest(request);
	    Iterator<FileItem> iterator = fileItems.iterator();

	    while (iterator.hasNext())
	    {
		FileItem fileItem = (FileItem) iterator.next();
		if (fileItem.isFormField())
		{
		    addValuesToObject(fileItem);
		}
		else
		{
		    addFilesToObject(fileItem);
		}

		validateFormFields.updateRequestFieldCount(fileItem);
	    }
	}
	catch (Exception e)
	{
	    Utils.addErrorResponse(response, "Error occurred while reading request items - " + e.getMessage());
	    e.printStackTrace();
	    return false;
	}

	// Validates Form fields
	if (validateFormFields.IsValidToResponse() == false)
	{
	    return false;
	}

	// Creates objects for validations.
	ValidateNumber validateNumber = new ValidateNumber(response, true);
	ValidateFile validateFile = new ValidateFile(response, true);

	// checks for contentId field
	validateNumber.Reset();
	validateNumber.IsStringInput = true;
	validateNumber.StrInput = inRoleVideoAddRequest.strContentId;
	validateNumber.FieldName = "'ContentId'";
	validateNumber.IsRequired = true;
	validateNumber.IsLong = true;
	validateNumber.IsAllCharactersNumber = true;

	if (validateNumber.isValueNumericToResponse() == false)
	{
	    return false;
	}

	inRoleVideoAddRequest.ContentId = Long.parseLong(inRoleVideoAddRequest.strContentId);

	// check contentId exists
	if (ContentDBUtils.isContentExists(conn, inRoleVideoAddRequest.ContentId) == false)
	{
	    Utils.addErrorResponse(response, "Content Id " + inRoleVideoAddRequest.ContentId + " not found.");
	    return false;
	}

	// Checks file item for In-Role Video
	validateFile.Reset();
	validateFile.InputFile = inRoleVideoAddRequest.InRoleVideoFile;
	validateFile.FieldName = "'InRoleVideo'";
	validateFile.IsRequired = true;
	validateFile.IsVideo = true;

	if (validateFile.IsValidFileToResponse() == false)
	{
	    return false;
	}

	// checks for user details
	try
	{
	    // Check User Exists
	    if (UserDBUtils.IsUserExists(conn, inRoleVideoAddRequest.UserId) == false)
	    {
		Utils.addErrorResponse(response, "User " + inRoleVideoAddRequest.UserId + " not found.");
		return false;
	    }

	    // Check User is Content Creator or Experience Center Employee
	    if (UserDBUtils.IsUserContentCreatorOrExperienceCenterEmployee(conn, inRoleVideoAddRequest.UserId) == false)
	    {
		Utils.addErrorResponse(response,
		                       "User " + inRoleVideoAddRequest.UserId + " is not Content Creator/Experience Center Employee.");
		return false;
	    }
	}
	catch (Exception e)
	{
	    Utils.addErrorResponse(response, "Error occurred while checking user details - " + e.getMessage());
	    e.printStackTrace();
	    return false;
	}

	return true;
    }


    private ValidateFormFields getValidateFormFieldsList()
    {
	ValidateFormFields validateFormFields = new ValidateFormFields(response);

	validateFormFields.addFormField(new FormField("contentid", EnumFieldType.Text, true));
	validateFormFields.addFormField(new FormField("inrolevideo", EnumFieldType.File, true));

	return validateFormFields;
    }


    private void addValuesToObject(FileItem fileItem)
            throws Exception
    {
	String fieldName = fileItem.getFieldName().toLowerCase();
	String value = "";

	try
	{
	    value = fileItem.getString("UTF-8");
	}
	catch (UnsupportedEncodingException ex)
	{
	    throw new Exception("UTF-8 is unsupported encoding !?");
	}

	switch (fieldName)
	{
	    case "contentid":
		inRoleVideoAddRequest.strContentId = value;
		break;
	}
    }


    private void addFilesToObject(FileItem fileItem)
    {
	String fieldName = fileItem.getFieldName().toLowerCase();

	switch (fieldName)
	{
	    case "inrolevideo":
		inRoleVideoAddRequest.InRoleVideoFile = fileItem;
		break;
	}
    }


    public void processUpdatingContent(CMISRepository cmisRepository, ContentFolders contentFolders)
            throws IOException, SQLException

    {
	long cmisDocumentId = 0L;

	cmisDocumentId = CMISDocumentDBUtils.GetNextCMISDocumentId(conn);
	inRoleVideoAddRequest.InRoleVideo_CMISDocument = cmisRepository.AddCMIS_Document(contentFolders.InRoleVideosFolder, cmisDocumentId,
	                                                                                 inRoleVideoAddRequest.InRoleVideoFile);

	CMISDocumentDBUtils.AddCMISDocumentFromCMISDocument(conn, inRoleVideoAddRequest.UserId,
	                                                    inRoleVideoAddRequest.InRoleVideo_CMISDocument);

	InRoleVideoDBUtils.AddInRoleVideo(conn, inRoleVideoAddRequest.InRoleVideoId, inRoleVideoAddRequest.ContentId,
	                                  inRoleVideoAddRequest.InRoleVideo_CMISDocument, inRoleVideoAddRequest.UserId);
    }
}
