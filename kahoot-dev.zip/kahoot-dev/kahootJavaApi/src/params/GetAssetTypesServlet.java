package params;

import java.util.List;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db_operations.DBUtils;
import db_operations.ParamDBUtils;
import params.classes.response.AssetTypesResponse;
import utils.Utils;


/**
 * Servlet implementation class GetAssetTypesServlet
 */
@WebServlet("/api/params/get-asset-types")
public class GetAssetTypesServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetAssetTypesServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub

	// Connect to database
	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	// Gets all asset types
	List<String> assetTypes = null;
	try
	{
	    assetTypes = ParamDBUtils.getAssetTypes(conn);
	}
	catch (Exception ex)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while retrieving asset types - " + ex.getMessage());
	    ex.printStackTrace();
	    return;
	}

	DBUtils.CloseConnection(conn);

	AssetTypesResponse assetTypesResponse = new AssetTypesResponse();
	assetTypesResponse.AssetTypes = assetTypes;

	Utils.addSuccessResponseFromObject(response, assetTypesResponse);
    }

}
