package params;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db_operations.DBUtils;
import db_operations.ParamDBUtils;
import params.classes.response.RejectionCategoryListResponse;
import utils.Utils;


/**
 * Servlet implementation class GetRejectionCategoryListServlet
 */
@WebServlet("/api/params/get-rejection-category-list")
public class GetRejectionCategoryListServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetRejectionCategoryListServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub

	// Connect to database
	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	// Gets all Rejection Category List
	List<String> rejectionCategoryList = null;
	try
	{
	    rejectionCategoryList = ParamDBUtils.getRejectionCategoryList(conn);
	}
	catch (Exception ex)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while retrieving rejection category list - " + ex.getMessage());
	    ex.printStackTrace();
	    return;
	}

	DBUtils.CloseConnection(conn);

	RejectionCategoryListResponse rejectionCategoryListResponse = new RejectionCategoryListResponse();
	rejectionCategoryListResponse.RejectionCategoryList = rejectionCategoryList;

	Utils.addSuccessResponseFromObject(response, rejectionCategoryListResponse);
    }
}
