package params;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db_operations.DBUtils;
import db_operations.ParamDBUtils;
import params.classes.response.SolutionsResponse;
import utils.Utils;


/**
 * Servlet implementation class GetSolutionsServlet
 */
@WebServlet("/api/params/get-solutions")
public class GetSolutionsServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetSolutionsServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub

	// Connect to database
	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	// Gets all asset types
	List<String> solutions = null;
	try
	{
	    solutions = ParamDBUtils.getSolutions(conn);
	}
	catch (Exception ex)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while retrieving solutions - " + ex.getMessage());
	    ex.printStackTrace();
	    return;
	}

	DBUtils.CloseConnection(conn);

	SolutionsResponse solutionsResponse = new SolutionsResponse();
	solutionsResponse.Solutions = solutions;

	Utils.addSuccessResponseFromObject(response, solutionsResponse);
    }
}
