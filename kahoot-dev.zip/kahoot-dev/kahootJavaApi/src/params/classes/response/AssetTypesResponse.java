package params.classes.response;

import java.util.List;


public class AssetTypesResponse
{
    public List<String> AssetTypes;
}
