package params.classes.response;

import java.util.List;

public class IndustriesResponse
{
    public List<String> Industries;
}
