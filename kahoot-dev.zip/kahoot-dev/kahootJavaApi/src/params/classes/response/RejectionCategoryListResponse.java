package params.classes.response;

import java.util.List;

public class RejectionCategoryListResponse
{
    public List<String> RejectionCategoryList;
}
