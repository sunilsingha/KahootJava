package params.classes.response;

import java.util.List;

public class SolutionsResponse
{
    public List<String> Solutions;
}
