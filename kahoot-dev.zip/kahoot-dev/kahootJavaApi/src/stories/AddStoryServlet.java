package stories;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cmis_operations.CMISRepository;
import cmis_operations.StoryCMISRepository;
import cmis_operations.classes.StoryFolders;
import db_operations.DBUtils;
import db_operations.StoryDBUtils;
import stories.classes.response.StoryAddResponse;
import stories.utils.AddOrUpdateStoryUtils;
import utils.RequestHelper;
import utils.RequestType;
import utils.Utils;


/**
 * Servlet implementation class AddStoryServlet
 */
@WebServlet("/api/stories/add-story")
public class AddStoryServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddStoryServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub
	String userId = new RequestHelper().getUserIdToResponse(response);
	if (userId == "")
	{
	    return;
	}

	// Connect to database
	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	// Reads Request Data and validates it
	AddOrUpdateStoryUtils addOrUpdateStoryUtils = new AddOrUpdateStoryUtils(request, response, conn, RequestType.Add);
	boolean blValidRequestData = false;

	try
	{
	    blValidRequestData = addOrUpdateStoryUtils.IsValidRequestData();
	}
	catch (Exception e)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while validating the fields - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	if (blValidRequestData == false)
	{
	    DBUtils.CloseConnection(conn);
	    return;
	}

	// Opens session in repository
	CMISRepository cmisRepository;

	try
	{
	    cmisRepository = new CMISRepository();
	    cmisRepository.sessionLogin();
	}
	catch (Exception e)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while connecting to CMIS repository - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	// Gets New Story Id
	try
	{
	    // Gets Next Sequence Id
	    addOrUpdateStoryUtils.setStoryId(StoryDBUtils.getNextStoryId(conn));

	}
	catch (Exception e)
	{
	    cmisRepository.session.clear();
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while retrieving Sequence Id - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	// Creates Folder Structure in Document Repository
	StoryFolders storyFolders = null;
	StoryCMISRepository storyCMISRespository = new StoryCMISRepository(cmisRepository);
	try
	{
	    storyFolders = storyCMISRespository.CreateFolderStructure(addOrUpdateStoryUtils.getStoryId());
	}
	catch (Exception e)
	{
	    cmisRepository.session.clear();
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while createing folder structure - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}
	
	try
	{
	    addOrUpdateStoryUtils.processUpdatingContent(cmisRepository, storyFolders);
	}
	catch (Exception e)
	{
	    cmisRepository.session.clear();
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while upading data and documents - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	// Closes connection and clears the session
	DBUtils.CloseConnection(conn);
	cmisRepository.session.clear();

	// Creates object to send response
	StoryAddResponse storyAddResponse = new StoryAddResponse();
	storyAddResponse.StoryId = addOrUpdateStoryUtils.getStoryId();
	storyAddResponse.Message = "New Story Added";

	// Sends the response back
	Utils.addSuccessResponseFromObject(response, storyAddResponse);
    }

}
