package stories;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db_operations.DBUtils;
import db_operations.StoryDBUtils;
import stories.classes.data.StoryData;
import stories.classes.response.StoriesResponse;
import utils.Utils;
import validation.ValidateNumber;


/**
 * Servlet implementation class GetStoryById
 */
@WebServlet("/api/stories/get-story-by-id")
public class GetStoryByIdServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetStoryByIdServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub

	String strStoryId = request.getParameter("storyId");

	if (strStoryId == null || strStoryId == "")
	{
	    Utils.addErrorResponse(response, "Provide 'storyId'.");
	    return;
	}

	// Validates Content Id
	ValidateNumber validateNumber = new ValidateNumber(response, true);
	validateNumber.IsStringInput = true;
	validateNumber.StrInput = strStoryId;
	validateNumber.FieldName = "'id'";
	validateNumber.IsRequired = true;
	validateNumber.IsAllCharactersNumber = true;
	validateNumber.IsLong = true;

	if (validateNumber.isValueNumericToResponse() == false)
	{
	    return;
	}

	// Parses Content Id
	long StoryId = Long.parseLong(strStoryId);

	Connection connection = null;
	connection = DBUtils.ConnectToDatabase(response);
	if (connection == null)
	{
	    return;
	}

	try
	{
	    if (StoryDBUtils.isStoryIdExists(connection, StoryId) == false)
	    {
		Utils.addErrorResponse(response, "Stroy Id " + StoryId + " not found");
		DBUtils.CloseConnection(connection);
		return;
	    }

	    StoryData storyData = StoryDBUtils.GetStoryById(connection, StoryId);
	    Utils.addSuccessResponseFromObject(response, new StoriesResponse(storyData));
	    DBUtils.CloseConnection(connection);
	}
	catch (Exception ex)
	{
	    DBUtils.CloseConnection(connection);
	    Utils.addErrorResponse(response, "Error occurred while retrieving data - " + ex.getMessage());
	    ex.printStackTrace();
	    return;
	}
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub
	doGet(request, response);
    }

}
