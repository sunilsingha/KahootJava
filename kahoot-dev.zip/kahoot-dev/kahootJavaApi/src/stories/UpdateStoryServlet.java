package stories;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cmis_operations.CMISRepository;
import cmis_operations.StoryCMISRepository;
import cmis_operations.classes.StoryFolders;
import db_operations.DBUtils;
import stories.classes.response.StoryUpdateResponse;
import stories.utils.AddOrUpdateStoryUtils;
import utils.RequestHelper;
import utils.RequestType;
import utils.Utils;


/**
 * Servlet implementation class UpdateStoryServlet
 */
@WebServlet("/api/stories/update-story")
public class UpdateStoryServlet
        extends HttpServlet
{
    private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateStoryServlet()
    {
	super();
	// TODO Auto-generated constructor stub
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
	// TODO Auto-generated method stub
	String userId = new RequestHelper().getUserIdToResponse(response);
	if (userId == "")
	{
	    return;
	}

	// Connect to database
	Connection conn = null;
	conn = DBUtils.ConnectToDatabase(response);
	if (conn == null)
	{
	    return;
	}

	// validating request
	AddOrUpdateStoryUtils addOrUpdateStoryUtils = new AddOrUpdateStoryUtils(request, response, conn, RequestType.Update);
	boolean blValidRequestData = false;

	try
	{
	    blValidRequestData = addOrUpdateStoryUtils.IsValidRequestData();
	}
	catch (Exception e)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while validating the fields.");
	    return;
	}

	if (blValidRequestData == false)
	{
	    return;
	}

	// Opens session in repository
	CMISRepository cmisRepository;

	try
	{
	    cmisRepository = new CMISRepository();
	    cmisRepository.sessionLogin();
	}
	catch (Exception e)
	{
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while connecting to CMIS repository - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	// Gets Folder Structure for Story in Document Repository
	StoryFolders storyFolders = null;
	StoryCMISRepository storyCMISRespository = new StoryCMISRepository(cmisRepository);

	try
	{
	    storyFolders = storyCMISRespository.GetStoryFolders(addOrUpdateStoryUtils.getStoryId());
	}
	catch (Exception e)
	{
	    cmisRepository.session.clear();
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while getting folder structure - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	try
	{
	    addOrUpdateStoryUtils.processUpdatingContent(cmisRepository, storyFolders);
	}
	catch (Exception e)
	{
	    cmisRepository.session.clear();
	    DBUtils.CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while upading data and documents - " + e.getMessage());
	    e.printStackTrace();
	    return;
	}

	// Closes connection
	DBUtils.CloseConnection(conn);
	cmisRepository.session.clear();

	// Send the response back
	StoryUpdateResponse storyUpdateResponse = new StoryUpdateResponse();
	storyUpdateResponse.Message = "Story details updated.";
	Utils.addSuccessResponseFromObject(response, storyUpdateResponse);
    }

}
