package stories.classes.data;

import java.sql.Timestamp;
import java.util.List;

import cmis_operations.classes.StoryFolders;


public class StoryData
{
    public long			   StoryId;
    public Timestamp		   CreatedOn;
    public String		   CreatedBy;
    public Timestamp		   UpdatedOn;
    public String		   UpdatedBy;
    public String		   Title;
    public String		   Description;
    
    public List<StoryDataContent>  StoryContents;
    public List<StoryDataDocument> Documents;

    public StoryFolders StoryFolders;
}
