package stories.classes.data;

import java.sql.Timestamp;

public class StoryDataContent
{
    public long ContentId;
    public long StoryId;
    public Timestamp CreatedOn;
    public String CreatedBy;
}
