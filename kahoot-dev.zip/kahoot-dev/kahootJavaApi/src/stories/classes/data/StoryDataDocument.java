package stories.classes.data;

import java.sql.Timestamp;
import cmis_operations.classes.CMISDocument;


public class StoryDataDocument
{
    public long	     Id;
    public Timestamp CreatedOn;
    public String    CreatedBy;
    public long	     CMISDocumentId;
    public long	     StoryId;

    public CMISDocument CMISDocument;
}
