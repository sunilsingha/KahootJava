package stories.classes.request;

import java.util.List;
import org.apache.commons.fileupload.FileItem;

import cmis_operations.classes.CMISDocument;
import stories.classes.data.StoryDataDocument;


public class StoryRequest
{
    // Retrieved from request
    public String	  Title;
    public String	  Description;
    public List<String>	  strContentIds;
    public List<FileItem> DocumentFiles;

    public String	strStoryId;		 // For Update
    public List<String>	strRemoveDocumentsByIds; // For Update

    // Values will be assigned dynamically
    public long	      StoryId;
    public List<Long> ContentIds;
    public String     UserId;

    public List<CMISDocument> Documents_CMISDocuments;

    public List<StoryDataDocument> RemoveDocuments;
}
