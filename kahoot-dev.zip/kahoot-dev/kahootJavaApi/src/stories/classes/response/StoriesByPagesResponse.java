package stories.classes.response;

import java.util.List;


public class StoriesByPagesResponse
{
    public int			 PageCount;
    public int			 PageIndex;
    public int			 PageSize;
    public int			 Total;
    public List<StoriesResponse> Stories;
}
