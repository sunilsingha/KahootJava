package stories.classes.response;

import java.util.ArrayList;
import java.util.List;

import stories.classes.data.StoryData;


public class StoriesResponse
{
    public StoriesResponse(StoryData storyData)
    {
	this.StoryId = storyData.StoryId;
	this.Title = storyData.Title;
	this.Description = storyData.Description;

	this.ContentIds = new ArrayList<Long>();
	int i = 0;
	for (; i < storyData.StoryContents.size(); i++)
	{
	    this.ContentIds.add(storyData.StoryContents.get(i).ContentId);
	}

	this.Documents = new ArrayList<StoriesResponseDocuments>();
	i = 0;
	for (; i < storyData.Documents.size(); i++)
	{
	    this.Documents.add(new StoriesResponseDocuments(storyData.Documents.get(i)));
	}
    }

    public long				  StoryId;
    public String			  Title;
    public String			  Description;
    public List<Long>			  ContentIds;
    public List<StoriesResponseDocuments> Documents;
}
