package stories.classes.response;

import stories.classes.data.StoryDataDocument;


public class StoriesResponseDocuments
{
    public StoriesResponseDocuments(StoryDataDocument storyDataDocument)
    {
	this.Id = storyDataDocument.Id;
	this.Path = storyDataDocument.CMISDocument.FilePath;
    }

    public long	  Id;
    public String Path;
}
