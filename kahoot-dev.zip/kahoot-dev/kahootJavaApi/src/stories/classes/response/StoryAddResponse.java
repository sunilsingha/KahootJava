package stories.classes.response;

public class StoryAddResponse
{
    public long StoryId;
    public String Message;
}
