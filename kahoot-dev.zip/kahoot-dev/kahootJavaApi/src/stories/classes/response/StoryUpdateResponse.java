package stories.classes.response;

public class StoryUpdateResponse
{
    public String Message;
}
