package stories.utils;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import cmis_operations.CMISRepository;
import cmis_operations.classes.CMISDocument;
import cmis_operations.classes.StoryFolders;
import db_operations.CMISDocumentDBUtils;
import db_operations.ContentDBUtils;
import db_operations.DBUtils;
import db_operations.SQLFieldsAndQueries;
import db_operations.StoryDBUtils;
import db_operations.UserDBUtils;
import stories.classes.data.StoryDataDocument;
import stories.classes.request.StoryRequest;
import utils.RequestHelper;
import utils.RequestType;
import utils.Utils;
import validation.ValidateFileArray;
import validation.ValidateFormFields;
import validation.ValidateNumber;
import validation.ValidateNumberArray;
import validation.ValidateString;
import validation.classes.EnumFieldType;
import validation.classes.FormField;


public class AddOrUpdateStoryUtils
{
    private HttpServletRequest	request;
    private HttpServletResponse	response;
    private RequestType		requestType;
    private Connection		conn;
    private StoryRequest	storyRequest;

    private static final String tblStories = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblStories + "\"";


    public AddOrUpdateStoryUtils(HttpServletRequest _httpServletRequest, HttpServletResponse _httpServletResponse, Connection _conn,
                                 RequestType _requestType)
    {
	request = _httpServletRequest;
	response = _httpServletResponse;
	requestType = _requestType;
	conn = _conn;
    }


    public void setStoryId(long storyId)
    {
	storyRequest.StoryId = storyId;
    }


    public long getStoryId()
    {
	return storyRequest.StoryId;
    }


    public boolean IsValidRequestData()
            throws IOException, SQLException
    {
	// process only if its MultiPart content
	if (!ServletFileUpload.isMultipartContent(request))
	{
	    Utils.addErrorResponse(response, "Invalid request");
	    return false;
	}

	storyRequest = new StoryRequest();
	storyRequest.UserId = (new RequestHelper().getUser()).getName();

	DiskFileItemFactory factory = new DiskFileItemFactory();
	// factory.setSizeThreshold(209715200);
	ServletFileUpload upload = new ServletFileUpload(factory);
	// upload.setFileSizeMax(209715200);

	ValidateFormFields validateFormFields = getValidateFormFieldsList();

	try
	{
	    List<FileItem> fileItems = upload.parseRequest(request);
	    Iterator<FileItem> iterator = fileItems.iterator();

	    while (iterator.hasNext())
	    {
		FileItem fileItem = (FileItem) iterator.next();
		if (fileItem.isFormField())
		{
		    addValuesToObject(fileItem);
		}
		else
		{
		    addFilesToObject(fileItem);
		}

		validateFormFields.updateRequestFieldCount(fileItem);
	    }
	}
	catch (Exception e)
	{
	    Utils.addErrorResponse(response, "Error occurred while reading request items - " + e.getMessage());
	    e.printStackTrace();
	    return false;
	}

	// Validates Form fields
	if (validateFormFields.IsValidToResponse() == false)
	{
	    return false;
	}

	// Creates objects for validations.
	ValidateString validateString = new ValidateString(response, true);
	ValidateNumber validateNumber = new ValidateNumber(response, true);
	ValidateNumberArray validateNumberArray = new ValidateNumberArray(response, true);
	ValidateFileArray validateFileArray = new ValidateFileArray(response, true);

	// Checks Request Type is Update
	if (requestType == RequestType.Update)
	{
	    // checks for storyId field
	    validateNumber.Reset();
	    validateNumber.IsStringInput = true;
	    validateNumber.StrInput = storyRequest.strStoryId;
	    validateNumber.FieldName = "'StoryId'";
	    validateNumber.IsRequired = true;
	    validateNumber.IsLong = true;
	    validateNumber.IsAllCharactersNumber = true;

	    if (validateNumber.isValueNumericToResponse() == false)
	    {
		return false;
	    }

	    storyRequest.StoryId = Long.parseLong(storyRequest.strStoryId);

	    // check contentId exists
	    if (StoryDBUtils.isStoryIdExists(conn, storyRequest.StoryId) == false)
	    {
		Utils.addErrorResponse(response, "Story Id " + storyRequest.StoryId + " not found.");
		return false;
	    }
	}
	else
	{
	    storyRequest.StoryId = 0;
	}

	// checks for Title field
	validateString.Reset();
	validateString.Input = storyRequest.Title;
	validateString.FieldName = "'Title'";
	validateString.IsRequired = true;
	validateString.IsValueWillBeTrimmed = true;
	validateString.HasMaximumLength = true;
	validateString.MaximumLength = 50;

	if (validateString.isValueStringToResponse() == false)
	{
	    return false;
	}

	// checks for description field
	validateString.Reset();
	validateString.Input = storyRequest.Description;
	validateString.FieldName = "'Description'";
	validateString.IsRequired = true;
	validateString.IsValueWillBeTrimmed = true;
	validateString.HasMinimumLength = true;
	validateString.MinimumLength = 1;

	if (validateString.isValueStringToResponse() == false)
	{
	    return false;
	}

	// checks for CenterIds field
	validateNumberArray.Reset();
	validateNumberArray.IsStringInput = true;
	validateNumberArray.StringArrayInput = storyRequest.strContentIds;
	validateNumberArray.FieldName = "'ContentIds'";
	validateNumberArray.IsRequired = true;
	validateNumberArray.HasMinimumItemsCount = true;
	validateNumberArray.MinimumItemsCount = 1;
	validateNumberArray.IsLong = true;
	validateNumberArray.IsAllCharactersNumber = true;
	validateNumberArray.CheckDuplicates = true;
	validateNumberArray.HasMinValue = true;
	validateNumberArray.MinimumLongValue = 1;

	if (validateNumberArray.IsNumberArrayToResponse() == false)
	{
	    return false;
	}

	List<String> messageList = new ArrayList<String>();
	int i = 0;
	long contentId;

	storyRequest.ContentIds = new ArrayList<Long>();
	for (i = 0; i < storyRequest.strContentIds.size(); i++)
	{
	    // strRemoveId = contentRequest.strRemoveInRoleVideosByIds.get(i);
	    contentId = Long.parseLong(storyRequest.strContentIds.get(i));

	    if (ContentDBUtils.isContentExists(conn, contentId) == false)
	    {
		messageList.add("Item " + (i + 1) + " of Content Id " + contentId + " not found.");
	    }
	    else
	    {
		storyRequest.ContentIds.add(contentId);
	    }
	}

	if (messageList.size() > 0)
	{
	    Utils.addErrorListResponse(response, "Error in the field 'ContentIds'.", messageList);
	    return false;
	}

	// Checks file item for documents
	validateFileArray.Reset();
	validateFileArray.InputFiles = storyRequest.DocumentFiles;
	validateFileArray.FieldName = "'Documents'";
	validateFileArray.IsRequired = requestType == RequestType.Add;
	validateFileArray.IsDocument = true;

	if (validateFileArray.IsValidFileArrayToResponse() == false)
	{
	    return false;
	}

	try
	{
	    // Check User Exists
	    if (UserDBUtils.IsUserExists(conn, storyRequest.UserId) == false)
	    {
		Utils.addErrorResponse(response, "User " + storyRequest.UserId + " not found.");
		return false;
	    }

	    // Check User is Content Creator or Administrator
	    if (UserDBUtils.IsUserContentAdministrator(conn, storyRequest.UserId) == false)
	    {
		Utils.addErrorResponse(response, "User " + storyRequest.UserId + " is not Content Administrator.");
		return false;
	    }
	}
	catch (Exception e)
	{
	    Utils.addErrorResponse(response, "Error occurred while checking user details - " + e.getMessage());
	    e.printStackTrace();
	    return false;
	}

	if (requestType == RequestType.Update)
	{
	    String strRemoveId = "";
	    long lRemoveId = 0L;

	    messageList = new ArrayList<String>();

	    // checks for documents
	    if (storyRequest.strRemoveDocumentsByIds != null)
	    {
		validateNumberArray.Reset();
		validateNumberArray.IsStringInput = true;
		validateNumberArray.StringArrayInput = storyRequest.strRemoveDocumentsByIds;
		validateNumberArray.FieldName = "'RemoveDocumentsByIds'";
		validateNumberArray.IsLong = true;

		if (validateNumberArray.IsNumberArrayToResponse() == false)
		{
		    return false;
		}

		storyRequest.RemoveDocuments = new ArrayList<StoryDataDocument>();
		for (i = 0; i < storyRequest.strRemoveDocumentsByIds.size(); i++)
		{
		    strRemoveId = storyRequest.strRemoveDocumentsByIds.get(i);
		    lRemoveId = Long.parseLong(strRemoveId);

		    if (StoryDBUtils.isStoryDocumentIdExists(conn, lRemoveId) == false)
		    {
			messageList.add("Item " + (i + 1) + " of Story Document Id " + lRemoveId + " doesn't exists.");
		    }
		    else
		    {
			storyRequest.RemoveDocuments.add(StoryDBUtils.GetStoryDocumentById(conn, lRemoveId));
		    }
		}

		if (messageList.size() > 0)
		{
		    Utils.addErrorListResponse(response, "Error in the field 'RemoveDocumentsByIds'.", messageList);
		    return false;
		}
	    }
	}

	return true;
    }


    private ValidateFormFields getValidateFormFieldsList()
    {
	ValidateFormFields validateFormFields = new ValidateFormFields(response);

	validateFormFields.addFormField(new FormField("title", EnumFieldType.Text, false));
	validateFormFields.addFormField(new FormField("description", EnumFieldType.Text, false));
	validateFormFields.addFormField(new FormField("contentids[]", EnumFieldType.Text, true));
	validateFormFields.addFormField(new FormField("documents[]", EnumFieldType.File, true));

	validateFormFields.addFormField(new FormField("storyid", EnumFieldType.Text, false));
	validateFormFields.addFormField(new FormField("removedocumentsbyids[]", EnumFieldType.Text, true));

	return validateFormFields;
    }


    private void addValuesToObject(FileItem fileItem)
            throws Exception
    {
	String fieldName = fileItem.getFieldName().toLowerCase();
	String value = "";

	try
	{
	    value = fileItem.getString("UTF-8");
	}
	catch (UnsupportedEncodingException ex)
	{
	    throw new Exception("UTF-8 is unsupported encoding !?");
	}

	switch (fieldName)
	{
	    case "title":
		storyRequest.Title = value;
		break;

	    case "description":
		storyRequest.Description = value;
		break;

	    case "contentids[]":
		if (storyRequest.strContentIds == null)
		{
		    storyRequest.strContentIds = new ArrayList<String>();
		}
		value = value.trim();
		storyRequest.strContentIds.add(value);
		break;

	    case "storyid":
		storyRequest.strStoryId = value;
		break;

	    case "removedocumentsbyids[]":
		if (storyRequest.strRemoveDocumentsByIds == null)
		{
		    storyRequest.strRemoveDocumentsByIds = new ArrayList<String>();
		}
		value = value.trim();
		storyRequest.strRemoveDocumentsByIds.add(value);
		break;
	}
    }


    private void addFilesToObject(FileItem fileItem)
    {
	String fieldName = fileItem.getFieldName().toLowerCase();

	switch (fieldName)
	{
	    case "documents[]":
		if (storyRequest.DocumentFiles == null)
		{
		    storyRequest.DocumentFiles = new ArrayList<FileItem>();
		}
		storyRequest.DocumentFiles.add(fileItem);
		break;
	}
    }


    public void processUpdatingContent(CMISRepository cmisRepository, StoryFolders storyFolders)
            throws IOException, SQLException

    {
	long cmisDocumentId = 0L;
	int i = 0;
	CMISDocument cmisDocument = null;

	// Gets all documents
	if (requestType == RequestType.Update)
	{
	    if (storyRequest.RemoveDocuments != null)
	    {
		for (i = 0; i < storyRequest.RemoveDocuments.size(); i++)
		{
		    storyRequest.RemoveDocuments.get(i).CMISDocument = cmisRepository.updateCMIS_DocumentbyDetails(storyFolders.DocumentsFolder,
		                                                                                                   storyRequest.RemoveDocuments.get(i).CMISDocument);
		}
	    }
	}

	// Adds Document Files
	if (storyRequest.DocumentFiles != null)
	{
	    FileItem fileItemDocument = null;
	    storyRequest.Documents_CMISDocuments = new ArrayList<CMISDocument>();

	    for (; i < storyRequest.DocumentFiles.size(); i++)
	    {
		fileItemDocument = storyRequest.DocumentFiles.get(i);
		cmisDocumentId = CMISDocumentDBUtils.GetNextCMISDocumentId(conn);
		cmisDocument = cmisRepository.AddCMIS_Document(storyFolders.DocumentsFolder, cmisDocumentId, fileItemDocument);
		CMISDocumentDBUtils.AddCMISDocumentFromCMISDocument(conn, storyRequest.UserId, cmisDocument);

		storyRequest.Documents_CMISDocuments.add(cmisDocument);
	    }
	}

	// Begins Transaction
	conn.setAutoCommit(false);

	// Insert Story
	if (requestType == RequestType.Add)
	{
	    insertStory();
	}
	else if (requestType == RequestType.Update)
	{
	    updateStory();
	}

	// Contents
	StoryDBUtils.DeleteMappingsStoryandContent(conn, storyRequest.StoryId);
	StoryDBUtils.AddContentsFromList(conn, storyRequest.StoryId, storyRequest.ContentIds, storyRequest.UserId);

	// Add Stories Documents
	if (storyRequest.Documents_CMISDocuments != null)
	{
	    StoryDBUtils.AddDocumentFromList(conn, storyRequest.StoryId, storyRequest.Documents_CMISDocuments,
	                                              storyRequest.UserId);
	}

	// Removes Documents Record
	if (storyRequest.RemoveDocuments != null)
	{
	    for (i = 0; i < storyRequest.RemoveDocuments.size(); i++)
	    {
		CMISDocumentDBUtils.DeleteCMIS_Document_DB(conn, storyRequest.RemoveDocuments.get(i).CMISDocument.Id, storyRequest.UserId);
		StoryDBUtils.DeleteDocumentById(conn, storyRequest.RemoveDocuments.get(i).Id);
	    }
	}

	// Commits Transaction
	conn.commit();
	conn.setAutoCommit(true);

	// Deletes Files from Document Repository

	// Delete In-Role Video file
	if (storyRequest.RemoveDocuments != null)
	{
	    for (i = 0; i < storyRequest.RemoveDocuments.size(); i++)
	    {
		cmisRepository.DeleteCMISDocument(storyRequest.RemoveDocuments.get(i).CMISDocument);
	    }
	}
    }


    private SQLFieldsAndQueries getSQLFields_SQLValues_array()
    {
	List<String> sqlFields = new ArrayList<String>();
	List<String> sqlValues = new ArrayList<String>();

	sqlFields.add("Title");
	sqlValues.add("?"); // 1

	sqlFields.add("Description");
	sqlValues.add("?"); // 2

	sqlFields.add("UpdatedOn");
	sqlValues.add("Now()");

	sqlFields.add("UpdatedBy");
	sqlValues.add("?"); // 3

	SQLFieldsAndQueries sqlFieldsAndQueries = new SQLFieldsAndQueries();

	sqlFieldsAndQueries.SQLFields = sqlFields;
	sqlFieldsAndQueries.SQLValues = sqlValues;

	return sqlFieldsAndQueries;
    }


    private PreparedStatement updateValuesToSQlFields(PreparedStatement pstmt)
            throws SQLException
    {
	pstmt.setNString(1, storyRequest.Title);
	pstmt.setNString(2, storyRequest.Description);
	pstmt.setNString(3, storyRequest.UserId);

	return pstmt;
    }


    private void insertStory()
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	SQLFieldsAndQueries objSQLFieldsValues = getSQLFields_SQLValues_array();
	List<String> sqlFields = objSQLFieldsValues.SQLFields;
	List<String> sqlValues = objSQLFieldsValues.SQLValues;

	sqlFields.add("CreatedOn");
	sqlValues.add("Now()");

	sqlFields.add("CreatedBy");
	sqlValues.add("?"); // 4

	sqlFields.add("Id");
	sqlValues.add("?"); // 5

	sql = DBUtils.combineSQLInsertQuery(sqlFields, sqlValues, tblStories);
	pstmt = conn.prepareStatement(sql);

	pstmt = updateValuesToSQlFields(pstmt);
	pstmt.setNString(4, storyRequest.UserId);
	pstmt.setLong(5, storyRequest.StoryId);

	pstmt.execute();
	pstmt.close();
    }


    private void updateStory()
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	SQLFieldsAndQueries objSQLFieldsValues = getSQLFields_SQLValues_array();
	List<String> sqlFields = objSQLFieldsValues.SQLFields;
	List<String> sqlValues = objSQLFieldsValues.SQLValues;

	String whereCondition = " where \"Id\" = ? "; // 4
	sql = DBUtils.combineSQLUpdateQuery(sqlFields, sqlValues, tblStories, whereCondition);

	pstmt = conn.prepareStatement(sql);
	pstmt = updateValuesToSQlFields(pstmt);
	pstmt.setLong(4, storyRequest.StoryId);

	pstmt.execute();
	pstmt.close();
    }
}
