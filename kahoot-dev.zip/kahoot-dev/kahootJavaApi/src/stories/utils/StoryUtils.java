package stories.utils;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import db_operations.ContentDBUtils;
import db_operations.StoryDBUtils;
import db_operations.utils.EnmStorySortByFields;
import stories.classes.data.StoryData;
import stories.classes.response.StoriesByPagesResponse;
import stories.classes.response.StoriesResponse;
import utils.Utils;
import validation.ValidateNumber;
import validation.ValidateString;


public class StoryUtils
{
    private HttpServletResponse	response;
    private Connection		conn;

    private String     title;
    private List<Long> contentIds;

    private boolean		 isResponseByPages;
    private int			 pageIndex = 1;
    private int			 pageSize  = 20;
    private EnmStorySortByFields storySortByFields;
    private boolean		 isAscending;

    // Validation variables
    private ValidateString validateString = null;
    private ValidateNumber validateNumber = null;


    public StoryUtils(HttpServletResponse _response, Connection _conn, boolean _isResponseByPages)
    {
	response = _response;
	conn = _conn;
	isResponseByPages = _isResponseByPages;

	setDefaultValues();
    }


    private void setDefaultValues()
    {
	title = null;
	contentIds = null;

	storySortByFields = EnmStorySortByFields.StoryId;
	isAscending = false;

	validateString = new ValidateString(response, true);
	validateNumber = new ValidateNumber(response, true);
    }


    public boolean setTitleIfValid(String _title, String fieldName)
    {
	if (_title != null)
	{
	    if (_title.trim() != "")
	    {
		validateString.Reset();
		validateString.FieldName = fieldName;
		validateString.Input = _title;
		validateString.HasMaximumLength = true;
		validateString.MaximumLength = 50;

		if (validateString.isValueStringToResponse() == false)
		{
		    return false;
		}

		this.title = _title.trim();
	    }
	}

	return true;
    }


    public boolean setContentIdIfValid(String strContentId, String fieldName)
            throws SQLException, IOException
    {
	if (strContentId != null)
	{
	    strContentId = strContentId.trim();

	    if (strContentId != "")
	    {
		validateNumber.Reset();
		validateNumber.StrInput = strContentId;
		validateNumber.IsStringInput = true;
		validateNumber.IsLong = true;
		validateNumber.FieldName = fieldName;
		validateNumber.IsRequired = true;

		if (validateNumber.isValueNumericToResponse() == false)
		{
		    return false;
		}

		return setContentIdIfValid(Long.parseLong(strContentId), fieldName);
	    }
	}

	return true;
    }


    public boolean setContentIdIfValid(long _contentId, String fieldName)
            throws SQLException, IOException
    {
	if (ContentDBUtils.isContentExists(conn, _contentId) == false)
	{
	    Utils.addErrorResponse(response, "Content Id " + _contentId + " not found.");
	    return false;
	}

	contentIds = new ArrayList<Long>();
	contentIds.add(_contentId);

	return true;
    }


    public boolean setContentIdsIfValid(List<Long> _contentIds, String fieldName)
            throws SQLException, IOException
    {
	if (_contentIds != null)
	{
	    if (_contentIds.size() > 0)
	    {
		int i = 0;
		List<String> messageList = new ArrayList<String>();

		for (i = 0; i < _contentIds.size(); i++)
		{
		    if (ContentDBUtils.isContentExists(conn, _contentIds.get(i)) == false)
		    {
			messageList.add("Item " + (i + 1) + " of Content Id " + _contentIds.get(i) + " not found.");
		    }
		}

		if (messageList.size() > 0)
		{
		    Utils.addErrorListResponse(response, "Error in the field " + fieldName + ".", messageList);
		    return false;
		}

		contentIds = _contentIds;
	    }
	}

	return true;
    }


    public boolean setPageSizeIfValid(String strpageSize, String fieldName)
            throws IOException
    {
	if (strpageSize != null)
	{
	    strpageSize = strpageSize.trim();
	    if (strpageSize != "")
	    {
		validateNumber.Reset();
		validateNumber.StrInput = strpageSize;
		validateNumber.IsStringInput = true;
		validateNumber.IsInteger = true;
		validateNumber.FieldName = fieldName;
		validateNumber.HasMinValue = true;
		validateNumber.MinimumIntValue = 1;

		if (validateNumber.isValueNumericToResponse() == false)
		{
		    return false;
		}

		pageSize = Integer.parseInt(strpageSize);
	    }
	}

	return true;
    }


    public boolean setPageIndexIfValid(String strPageIndex, String fieldName)
            throws IOException
    {
	if (strPageIndex != null)
	{
	    strPageIndex = strPageIndex.trim();
	    if (strPageIndex != "")
	    {
		validateNumber.Reset();
		validateNumber.StrInput = strPageIndex;
		validateNumber.IsStringInput = true;
		validateNumber.IsInteger = true;
		validateNumber.FieldName = fieldName;
		validateNumber.HasMinValue = true;
		validateNumber.MinimumIntValue = 1;

		if (validateNumber.isValueNumericToResponse() == false)
		{
		    return false;
		}

		pageIndex = Integer.parseInt(strPageIndex);
	    }
	}

	return true;
    }


    private List<Long> GetStoryIdsByFilters()
            throws SQLException
    {
	List<Long> storyIds = StoryDBUtils.GetStoryIds(conn, title);

	// checks for centerIds
	if (contentIds != null)
	{
	    List<Long> contentIdsStoryIds = StoryDBUtils.GetStoryIdsByContentIds(conn, contentIds);
	    storyIds.retainAll(contentIdsStoryIds);
	}

	return storyIds;
    }


    public void udpateResultToResponse()
            throws SQLException, IOException
    {
	List<Long> storyIds = GetStoryIdsByFilters();

	if (isResponseByPages)
	{
	    updatePagesResponse(storyIds);
	}
	else
	{
	    updatePlainResponse(storyIds);
	}
    }


    private void updatePlainResponse(List<Long> storyIds)
            throws SQLException, IOException
    {
	storyIds = StoryDBUtils.GetStoryIdsSort(conn, storyIds, storySortByFields, isAscending);

	List<StoriesResponse> storiesResponseList = new ArrayList<StoriesResponse>();
	StoriesResponse storiesResponse = null;
	StoryData storyData = null;
	int i = 0;

	for (; i < storyIds.size(); i++)
	{
	    storyData = StoryDBUtils.GetStoryById(conn, storyIds.get(i));
	    storiesResponse = new StoriesResponse(storyData);

	    storiesResponseList.add(storiesResponse);
	}

	Utils.addSuccessResponseFromObject(response, storiesResponseList);
    }


    private void updatePagesResponse(List<Long> storyIds)
            throws SQLException, IOException
    {
	int total = storyIds.size();
	int pageCount = 0;
	double dblPageCount = 0;
	if (total > 0)
	{
	    dblPageCount = (int) Math.floor(total / pageSize);

	    if (total > (pageSize * dblPageCount))
	    {
		pageCount = (int) dblPageCount + 1;
	    }
	    else
	    {
		pageCount = (int) dblPageCount;
	    }
	}

	storyIds = StoryDBUtils.GetStoryIdsSortByPages(conn, storyIds, pageSize, (pageIndex - 1) * pageSize, storySortByFields,
	                                               isAscending);

	StoriesByPagesResponse storiesByPagesResponse = new StoriesByPagesResponse();
	storiesByPagesResponse.PageCount = pageCount;
	storiesByPagesResponse.PageSize = pageSize;
	storiesByPagesResponse.PageIndex = pageIndex;
	storiesByPagesResponse.Total = total;
	storiesByPagesResponse.Stories = new ArrayList<StoriesResponse>();

	StoriesResponse storiesResponse = null;
	StoryData storyDta = null;
	int i = 0;

	for (; i < storyIds.size(); i++)
	{
	    storyDta = StoryDBUtils.GetStoryById(conn, storyIds.get(i));
	    storiesResponse = new StoriesResponse(storyDta);

	    storiesByPagesResponse.Stories.add(storiesResponse);
	}

	Utils.addSuccessResponseFromObject(response, storiesByPagesResponse);
    }
}
