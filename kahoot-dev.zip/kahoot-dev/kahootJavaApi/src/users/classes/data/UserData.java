package users.classes.data;

import java.util.List;
import java.sql.Timestamp;


public class UserData
{
    public long	     Id;
    public Timestamp CreatedOn;
    public String    CreatedBy;
    public Timestamp UpdatedOn;
    public String    UpdatedBy;
    public String    UserId;
    public String    Name;
    public String    Email;
    public boolean   IsAdmin;
    public boolean   IsSuperAdmin;
    public List<String> Roles;
}
