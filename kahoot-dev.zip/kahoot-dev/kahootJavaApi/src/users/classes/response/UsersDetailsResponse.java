package users.classes.response;

import java.util.List;

import users.classes.data.UserData;


public class UsersDetailsResponse
{
    public UsersDetailsResponse(UserData usersData)
    {
	this.Name = usersData.Name;
	this.Email = usersData.Email;
	this.Roles = usersData.Roles;
	this.UserId = usersData.UserId;
    }

    public String	UserId;
    public String	Name;
    public String	Email;
    public List<String>	Roles;
}
