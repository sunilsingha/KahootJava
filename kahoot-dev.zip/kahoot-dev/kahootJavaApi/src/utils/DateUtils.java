package utils;

import java.util.Calendar;
import java.util.Date;

public class DateUtils
{
    public static Date getDate_From_FormattedDate_YYYY_MM_DD(String strDate)
    {
	// Get Date output from the formatted date YYYY-MM-DD or YYYY-MM-DD
	// argument strDate is of type String
	// Output value is date

	Date dt = null;
	String[] arrDate;

	arrDate = strDate.split("/");
	if (arrDate.length != 3) {
	    arrDate = strDate.split("-");
	    if (arrDate.length != 3) {
		return null;
	    }
	}

	int year = Integer.parseInt(arrDate[0]);
	int month = Integer.parseInt(arrDate[1]);
	int day = Integer.parseInt(arrDate[2]);

	if (year < 2000 || year > 2100) {
	    return null;
	}

	if (month < 1 || month > 12) {
	    return null;
	}

	if (day < 1 || day > 31) {
	    return null;
	}

	if (month == 4 || month == 6 || month == 9 || month == 11) {
	    if (day > 30) {
		return null;
	    }
	}

	if (month == 2) {
	    if (year % 4 == 0 && day > 29) {
		return null;
	    }
	    else if (year % 4 != 0 && day > 28) {
		return null;
	    }
	}

	try {
	    Calendar c = Calendar.getInstance();
	    c.set(year, month - 1, day, 0, 0);
	    dt = c.getTime();
	}
	catch (Exception e) {
	    return null;
	}

	return dt;
    }
}
