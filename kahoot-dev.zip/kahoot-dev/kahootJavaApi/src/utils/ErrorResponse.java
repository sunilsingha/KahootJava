package utils;

public class ErrorResponse
{
    public String errorMessage;
}
