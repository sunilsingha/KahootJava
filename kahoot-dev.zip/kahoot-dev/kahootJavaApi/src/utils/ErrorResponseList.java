package utils;

import java.util.List;

public class ErrorResponseList
{
    public String	errorMessage;
    public List<String>	messageList;
}
