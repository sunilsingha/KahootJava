package utils;

public class FieldErrorResponse
        extends ErrorResponse
{
    public String fieldName;
}
