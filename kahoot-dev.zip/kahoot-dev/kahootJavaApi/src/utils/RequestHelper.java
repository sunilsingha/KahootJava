package utils;

import java.io.IOException;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sap.security.um.service.UserManagementAccessor;
import com.sap.security.um.user.PersistenceException;
import com.sap.security.um.user.User;
import com.sap.security.um.user.UserProvider;


public class RequestHelper
{
    private static Logger LOGGER = LoggerFactory.getLogger(RequestHelper.class);


    public User getUser()
    {
	User user = null;

	try
	{
	    UserProvider userProvider = UserManagementAccessor.getUserProvider();
	    user = userProvider.getCurrentUser();
	}
	catch (PersistenceException e)
	{
	    LOGGER.error("Failed to get user", e);
	}

	return user;
    }


    public String getUserIdToResponse(HttpServletResponse response)
            throws IOException
    {
	User user = getUser();
	if (user == null)
	{
	    Utils.addErrorResponse(response, "Invalid user.");
	    return "";
	}

	return user.getName();
    }
}
