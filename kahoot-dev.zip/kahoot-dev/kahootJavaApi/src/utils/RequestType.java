package utils;

public enum RequestType {
    Add, Update
}
