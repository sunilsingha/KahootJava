package utils;

import java.util.List;


public class StringUtils
{
    public static Boolean isValue_in_List(String SearchValue, List<String> checkList)
    {
	int i = 0;
	Boolean blFound = false;

	for (; i < checkList.size(); i++)
	{
	    String value1 = checkList.get(i).toLowerCase().trim();
	    String value2 = SearchValue.toLowerCase();

	    if (value1.equals(value2))
	    {
		blFound = true;
	    }
	}

	return blFound;
    }
}
