package utils;

public class SuccessResponse {
	public String message;
}
