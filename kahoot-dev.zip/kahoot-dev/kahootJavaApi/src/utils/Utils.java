package utils;

import java.io.IOException;

import java.util.List;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.PrintWriter;


public class Utils
{

    public static final String[] DocumentTypes = { "Banner Image","Thumbnail Image", "Walkthrough Video", "Setup Guide", "Presenter Guide", "In-Role Video" };


    private static void updateToResponse(HttpServletResponse response, int statusNo, String jsonString)
            throws IOException
    {
	PrintWriter out = response.getWriter();

	response.setStatus(statusNo);
	response.setContentType("application/json");
	response.setCharacterEncoding("UTF-8");

	out.print(jsonString);
	out.flush();
    }


    private static void updateToResponseFromObject(HttpServletResponse response, int statusNo, Object object)
            throws IOException
    {
	ObjectMapper mapper = new ObjectMapper();
	String jsonString = mapper.writeValueAsString(object);

	updateToResponse(response, statusNo, jsonString);
    }


    public static void addSuccessResponse(HttpServletResponse response, String message)
            throws IOException
    {
	SuccessResponse successResponse = new SuccessResponse();
	successResponse.message = message;

	updateToResponseFromObject(response, 200, successResponse);
    }


    public static void addSuccessResponseFromObject(HttpServletResponse response, Object object)
            throws IOException
    {
	updateToResponseFromObject(response, 200, object);
    }


    public static void addErrorResponse(HttpServletResponse response, String errorMessage, int statusNo)
            throws IOException
    {
	ErrorResponse errorResponse = new ErrorResponse();
	errorResponse.errorMessage = errorMessage;

	ObjectMapper mapper = new ObjectMapper();
	String jsonString = mapper.writeValueAsString(errorResponse);

	updateToResponse(response, statusNo, jsonString);
    }


    public static void addFieldErrorResponse(HttpServletResponse response, String fieldName, String errorMessage, int statusNo)
            throws IOException
    {
	FieldErrorResponse fieldErrorResponse = new FieldErrorResponse();
	fieldErrorResponse.fieldName = fieldName;
	fieldErrorResponse.errorMessage = errorMessage;

	updateToResponseFromObject(response, statusNo, fieldErrorResponse);
    }


    public static void addErrorResponse(HttpServletResponse response, String errorMessage)
            throws IOException
    {
	addErrorResponse(response, errorMessage, 400);
    }


    public static void addErrorListResponse(HttpServletResponse response, String errorMessage, List<String> messageList, int statusNo)
            throws JsonProcessingException, IOException
    {
	response.setContentType("application/json");
	response.setCharacterEncoding("UTF-8");
	response.setStatus(statusNo);

	ErrorResponseList errorResponseList = new ErrorResponseList();
	errorResponseList.errorMessage = errorMessage;
	errorResponseList.messageList = messageList;

	ObjectMapper mapper = new ObjectMapper();
	String jsonString = mapper.writeValueAsString(errorResponseList);

	response.getWriter().write(jsonString);
    }


    public static void addErrorListResponse(HttpServletResponse response, String errorMessage, List<String> messageList)
            throws JsonProcessingException, IOException
    {
	addErrorListResponse(response, errorMessage, messageList, 400);
    }


    public static Boolean validateEmail(String email)
    {
	Pattern pattern = Pattern.compile("(([^<>()\\[\\]\\\\.,;:\\s@\"]+(\\.[^<>()\\[\\]\\\\.,;:\\s@\"]+)*)|(\".+\"))@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))");
	return pattern.matcher(email).matches();
    }


    public static String getCorrectDocumentType(String documentType)
    {
	String newDocumentType = "";

	for (String strNewValue : DocumentTypes)
	{
	    String strOldDocumentType = documentType.trim().toLowerCase();
	    String strLowerNewValue = strNewValue.toLowerCase();

	    if (strLowerNewValue.equals(strOldDocumentType))
	    {
		newDocumentType = strNewValue;
	    }
	}

	return newDocumentType;

    }


    public static Boolean isAllCharactersareNumbers(String Input)
    {
	// Checks all characters are numeric
	Pattern pattern = Pattern.compile("[1-9]\\d*");
	Boolean blMatched = pattern.matcher(Input).matches();

	return blMatched;
    }


    public static Boolean isAllCharactersareNumbers2(String Input)
    {
	// Checks all characters are numeric
	Pattern pattern = Pattern.compile("\\d*");
	Boolean blMatched = pattern.matcher(Input).matches();

	return blMatched;
    }


    public static Boolean isValueLatitudeOrLongitude(String Input)
    {
	// Checks whether input value is Latitude or Latitude
	Pattern pattern = Pattern.compile("\\-?\\d+\\.\\d+");
	Boolean blMatched = pattern.matcher(Input).matches();

	return blMatched;
    }


    public static String getStandardTextForSearchValue(String searchValue, List<String> StandardList)
    {
	String newValue = "";
	String strOldSeardValue = searchValue.trim().toLowerCase();

	for (String strNewValue : StandardList)
	{
	    String strLowerNewValue = strNewValue.toLowerCase();
	    if (strLowerNewValue.equals(strOldSeardValue))
	    {
		newValue = strNewValue;
	    }
	}

	return newValue;
    }


    public static String CombineIdsToString(List<Long> Ids)
    {
	Long[] idsArr = Ids.toArray(new Long[Ids.size()]);
	int i, arrLen = idsArr.length;

	StringBuilder tmp = new StringBuilder();
	for (i = 0; i < arrLen - 1; i++)
	{
	    tmp.append(idsArr[i] + ", ");
	}
	if (arrLen > 0)
	{
	    tmp.append(idsArr[arrLen - 1]);
	}

	return tmp.toString();
    }
}
