package validation;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletResponse;

import utils.Utils;

public class ValidateDate
{
    public HttpServletResponse HttpServletResponse;
    public boolean	       UpdateToHttpServletResponse;
    public String	       Input;
    public String	       FieldName;
    public boolean	       IsRequired;
    public boolean	       IsInputFormt_YYYY_MM_DD;

    public boolean HasMinDate;
    public boolean HasMaxDate;
    public Date	   minDate;
    public Date	   maxDate;

    public ValidateDate(HttpServletResponse httpServletResponse, Boolean updateToHttpServletResponse)
    {
	HttpServletResponse = httpServletResponse;
	UpdateToHttpServletResponse = updateToHttpServletResponse;

	Reset();
    }

    public void Reset()
    {
	Input = "";
	FieldName = "";
	IsRequired = false;
	IsInputFormt_YYYY_MM_DD = false;
	HasMinDate = false;
	HasMaxDate = false;
	minDate = null;
	maxDate = null;
    }

    private String checkInputRequired()
    {
	// Checks field is Required
	if (IsRequired == true) {
	    if (Input == null) {
		return "Provide date value for " + FieldName + ".";
	    }
	    else if (Input.length() == 0) {
		return "Provide date value for " + FieldName + ".";
	    }
	}

	return "";
    }

    public String isDateFormat_YYYY_MM_DD()
    {
	// Checks date format is YYYY_MM_DD and returns error message

	Date dt = null;
	String[] arrDate;

	Pattern pattern = Pattern.compile("((19|[2-9]\\d)\\d{2})[\\/\\-](0?[1-9]|1[0-2])[\\/\\-](0?[1-9]|[12]\\d|3[01])");

	Boolean result = pattern.matcher(Input).matches();
	if (result == false) {
	    return FieldName + " is invalid. Format of date should be YYYY-MM-DD.";
	}

	arrDate = Input.split("/");
	if (arrDate.length != 3) {
	    arrDate = Input.split("-");
	    if (arrDate.length != 3) {
		return FieldName + " is invalid. Format of date should be YYYY-MM-DD";
	    }
	}

	int year = 0;
	int month = 0;
	int day = 0;

	try {
	    year = Integer.parseInt(arrDate[0]);
	    month = Integer.parseInt(arrDate[1]);
	    day = Integer.parseInt(arrDate[2]);
	}
	catch (NumberFormatException e) {
	    return FieldName + " is invalid. Format of date should be YYYY-MM-DD";
	}

	if (year < 2000 || year > 2100) {
	    return "Invalid date " + FieldName + ".";
	}

	if (month < 1 || month > 12) {
	    return "Invalid date " + FieldName + ".";
	}

	if (day < 1 || day > 31) {
	    return "Invalid date " + FieldName + ".";
	}

	if (month == 4 || month == 6 || month == 9 || month == 11) {
	    if (day > 30) {
		return "Invalid date " + FieldName + ".";
	    }
	}

	if (month == 2) {
	    if (year % 4 == 0 && day > 29) {
		return "Invalid date " + FieldName + ".";
	    }
	    else if (year % 4 != 0 && day > 28) {
		return "Invalid date " + FieldName + ".";
	    }
	}

	try {
	    Calendar c = Calendar.getInstance();
	    c.set(year, month - 1, day, 0, 0);
	    dt = c.getTime();
	}
	catch (Exception e) {
	    return "Invalid date " + FieldName + ".";
	}

	if (HasMinDate) {
	    if (minDate != null) {
		if (minDate.getTime() > dt.getTime()) {
		    return "Invalid date " + FieldName + ".";
		}
	    }
	}

	if (HasMaxDate) {
	    if (maxDate != null) {
		if (maxDate.getTime() < dt.getTime()) {
		    return "Invalid date " + FieldName + ".";
		}
	    }
	}

	return "";
    }

    public String IsValueDate()
    {
	String strErrorMessage = "";

	// Checks whether String input is required
	strErrorMessage = checkInputRequired();
	if (strErrorMessage != "")
	    return strErrorMessage;

	// Checks input value is in the format 'YYYY-MM-DD'
	if (IsInputFormt_YYYY_MM_DD) {
	    strErrorMessage = isDateFormat_YYYY_MM_DD();
	    if (strErrorMessage != "")
		return strErrorMessage;
	}

	return strErrorMessage;
    }

    public boolean IsValueDateToResponse()
    {
	String strMessage = IsValueDate();

	if (strMessage == "") {
	    return true;
	}
	else {
	    try {
		Utils.addErrorResponse(HttpServletResponse, strMessage);
	    }
	    catch (IOException e) {
		e.printStackTrace();
	    }

	    return false;
	}
    }
}
