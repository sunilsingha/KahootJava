package validation;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import utils.Utils;


public class ValidateFile
{
    public boolean	       UpdateToHttpServletResponse;
    public HttpServletResponse HttpServletResponse;
    public String	       FieldName;
    public FileItem	       InputFile;
    public boolean	       IsRequired;
    public boolean	       IsImage;
    public boolean	       IsVideo;
    public boolean	       IsDocument;


    public ValidateFile(HttpServletResponse httpServletResponse, Boolean updateToHttpServletResponse)
    {
	HttpServletResponse = httpServletResponse;
	UpdateToHttpServletResponse = updateToHttpServletResponse;

	Reset();
    }


    public void Reset()
    {
	InputFile = null;
	FieldName = "";
	IsRequired = false;
	IsImage = false;
	IsVideo = false;
	IsDocument = false;
    }


    private String checkInputRequired()
    {
	// Checks field is Required
	if (IsRequired == true)
	{
	    if (InputFile == null)
	    {
		return "Provide file for " + FieldName + ".";
	    }
	}

	return "";
    }


    private String checkTypeOfFile()
    {
	if (InputFile == null)
	{
	    return "";
	}

	String strContentType = "";
	strContentType = InputFile.getContentType().toLowerCase();

	if (IsImage)
	{
	    if (strContentType.equals("image/jpeg") == false // .JPG or .JPEG
	            && strContentType.equals("image/png") == false // .PNG
	            && strContentType.equals("image/bmp") == false)
	    { // .BMP
		return "Invalid file sent for " + FieldName + ".";
	    }

	}
	else if (IsVideo)
	{
	    if (strContentType.equals("video/x-msvideo") == false // .AVI
	            && strContentType.equals("application/x-dvi") == false // .DVI
	            && strContentType.equals("video/x-flv") == false // .FLV
	            && strContentType.equals("video/x-m4v") == false // .M4V
	            && strContentType.equals("video/x-ms-wmv") == false // .WMV
	            && strContentType.equals("video/mp4") == false // .MP4
	            && strContentType.equals("video/avi") == false // .AVI
	            && strContentType.equals("video/quicktime") == false)
	    { // .QT
		return "Invalid file sent for " + FieldName + ".";
	    }
	}
	else if (IsDocument)
	{
	    if (strContentType.equals("application/pdf") == false // .PDF
	            && strContentType.equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document") == false // .DOCX
	            && strContentType.equals("application/msword") == false // .DOC
	            && strContentType.equals("application/vnd.ms-word.document.macroenabled.12") == false // .DOCM
	            && strContentType.equals("application/vnd.openxmlformats-officedocument.presentationml.presentation") == false // .PPTX
	            && strContentType.equals("application/vnd.ms-powerpoint") == false // .PPT
	            && strContentType.equals("application/vnd.ms-powerpoint.presentation.macroenabled.12") == false)
	    { // .PPTM
		return "Invalid file sent for " + FieldName + ".";
	    }
	}

	return "";
    }


    // 200 MB = 209,715,200 Bytes
    // if(contentRequest.InRoleVideoFile.getSize() > 209715200 ) {
    // Utils.addErrorResponse(response, "In-role video file size should not exceed
    // more than 200 MB");
    // return null;

    public String IsValidFile()
    {
	String strErrorMessage = "";

	// Checks whether String input is required
	strErrorMessage = checkInputRequired();
	if (strErrorMessage != "")
	    return strErrorMessage;

	// Checks Type of the file
	strErrorMessage = checkTypeOfFile();
	if (strErrorMessage != "")
	    return strErrorMessage;

	return strErrorMessage;
    }


    public boolean IsValidFileToResponse()
    {
	String strMessage = IsValidFile();

	if (strMessage == "")
	{
	    return true;
	}
	else
	{
	    try
	    {
		Utils.addErrorResponse(HttpServletResponse, strMessage);
	    }
	    catch (IOException e)
	    {
		e.printStackTrace();
	    }

	    return false;
	}
    }
}
