package validation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;

import utils.Utils;

public class ValidateFileArray
{
    public boolean	       UpdateToHttpServletResponse;
    public HttpServletResponse HttpServletResponse;
    public String	       FieldName;
    public List<FileItem>      InputFiles;
    public boolean	       IsRequired;
    public boolean	       IsImage;
    public boolean	       IsVideo;
    public boolean	       IsDocument;

    public boolean HasMinimumItemsCount;
    public int	   MinimumItemsCount;
    public boolean HasMaximumItemsCount;
    public int	   MaximumItemsCount;

    public ValidateFileArray(HttpServletResponse httpServletResponse, Boolean updateToHttpServletResponse)
    {
	HttpServletResponse = httpServletResponse;
	UpdateToHttpServletResponse = updateToHttpServletResponse;

	Reset();
    }

    public void Reset()
    {
	InputFiles = null;
	FieldName = "";
	IsRequired = false;
	IsImage = false;
	IsVideo = false;
	IsDocument = false;

	HasMinimumItemsCount = false;
	MinimumItemsCount = -1;
	HasMaximumItemsCount = false;
	MaximumItemsCount = -1;
    }

    private String checkInputRequired()
    {
	if (IsRequired == true) {
	    if (InputFiles == null) {
		return "Provide File array for " + FieldName + ".";
	    }

	    if (InputFiles.size() == 0) {
		return "Provide File array for " + FieldName + ".";
	    }
	}

	return "";
    }

    private String checkFilesCountBetweenMinMaxItemsCount()
    {
	if (InputFiles == null) {
	    return "";
	}

	// Checks if both items count are equal
	if (HasMinimumItemsCount && HasMaximumItemsCount) {
	    if (MinimumItemsCount > 0 && MinimumItemsCount == MaximumItemsCount) {
		if (InputFiles.size() != MinimumItemsCount) {
		    if (MinimumItemsCount == 1) {
			return FieldName + " should have 1 file.";
		    }
		    else {
			return FieldName + " should have " + MinimumItemsCount + " files.";
		    }
		}
	    }
	}

	// Checks array Count
	if (HasMinimumItemsCount == true) {
	    if (MinimumItemsCount > 0) {
		if (InputFiles.size() < MinimumItemsCount) {
		    if (MinimumItemsCount == 1) {
			return FieldName + " should have atleast 1 file.";
		    }
		    else {
			return FieldName + " should have atleast " + MinimumItemsCount + " files.";
		    }
		}
	    }
	}

	// Checks array count for maximum
	if (HasMaximumItemsCount == true) {
	    if (MaximumItemsCount > 0) {
		if (InputFiles.size() > MaximumItemsCount) {
		    if (MaximumItemsCount == 1) {
			return FieldName + " should not be more than 1 file.";
		    }
		    else {
			return FieldName + " should not exceed more than " + MaximumItemsCount + " files.";
		    }
		}
	    }
	}

	return "";
    }

    public String IsValidFileArray()
    {
	String strErrorMessage = "";

	// Checks whether String input is required
	strErrorMessage = checkInputRequired();
	if (strErrorMessage != "")
	    return strErrorMessage;

	// validates number of items
	strErrorMessage = checkFilesCountBetweenMinMaxItemsCount();
	if (strErrorMessage != "")
	    return strErrorMessage;

	return "";
    }

    public List<String> ValidateEachFileItemInArray()
    {
	// Check Files inside the array .

	ValidateFile validateFile = new ValidateFile(null, false);

	// Checks whether Input has value
	if (InputFiles == null) {
	    return new ArrayList<String>();
	}

	// loops through the array
	int i = 0;
	List<String> messageList = new ArrayList<String>();
	String errorMessage = "";

	// checks if there is any error in string value
	for (; i < InputFiles.size(); i++) {
	    validateFile.Reset();

	    validateFile.InputFile = InputFiles.get(i);
	    validateFile.FieldName = "Item " + (i + 1);

	    validateFile.IsRequired = IsRequired;
	    validateFile.IsImage = IsImage;
	    validateFile.IsVideo = IsVideo;
	    validateFile.IsDocument = IsDocument;

	    errorMessage = validateFile.IsValidFile();

	    if (errorMessage != "") {
		messageList.add(errorMessage);
	    }
	}

	return messageList;
    }

    public boolean IsValidFileArrayToResponse()
            throws IOException
    {
	// checks input is array and Items in the array
	String strMessage = IsValidFileArray();

	if (strMessage != "") {
	    Utils.addErrorResponse(HttpServletResponse, strMessage);
	    return false;
	}

	// checks string values inside the array
	List<String> messageList = ValidateEachFileItemInArray();

	if (messageList.size() > 0) {
	    Utils.addErrorListResponse(HttpServletResponse, "Error in the field " + FieldName + ".", messageList);
	    return false;
	}

	return true;
    }
}
