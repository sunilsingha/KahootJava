package validation;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;

import validation.classes.FormField;


public class ValidateFormFields
{
    private List<FormField>    FormFields;
    public HttpServletResponse HttpServletResponse;


    public ValidateFormFields(HttpServletResponse httpServletResponse)
    {
	this.FormFields = new ArrayList<FormField>();
	this.HttpServletResponse = httpServletResponse;
    }


    public void addFormField(FormField formField)
    {
	this.FormFields.add(formField);
    }


    public void updateRequestFieldCount(FileItem fileItem)
    {
	int i = 0;
	boolean isTextInput = fileItem.isFormField();
	String fieldName = fileItem.getFieldName().toLowerCase();
	String strFieldName = "";

	for (; i < this.FormFields.size(); i++)
	{
	    strFieldName = this.FormFields.get(i).FieldName.toLowerCase();

	    if (strFieldName.equals(fieldName))
	    {
		this.FormFields.get(i).FieldCount += 1L;

		if (isTextInput)
		{
		    this.FormFields.get(i).TextInputCount += 1L;
		}
		else
		{
		    this.FormFields.get(i).FileInputCount += 1L;
		}
	    }
	}
    }


    public boolean IsValidToResponse()
    {

	return true;
    }
}
