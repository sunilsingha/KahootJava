package validation;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import utils.Utils;

public class ValidateNumber
{
    public boolean	       UpdateToHttpServletResponse;
    public HttpServletResponse HttpServletResponse;
    public String	       FieldName;
    public boolean	       IsRequired;
    public boolean	       IsAllCharactersNumber;
    public boolean	       IsLatitudeOrLongitude;

    public boolean IsStringInput;
    public String  StrInput;

    public boolean HasMinValue;
    public boolean HasMaxValue;

    public boolean IsInteger;
    public int	   IntInput;
    public int	   MinimumIntValue;
    public int	   MaximumIntValue;

    public boolean IsLong;
    public long	   LongInput;
    public long	   MinimumLongValue;
    public long	   MaximumLongValue;

    public ValidateNumber(HttpServletResponse httpServletResponse, Boolean updateToHttpServletResponse)
    {
	UpdateToHttpServletResponse = updateToHttpServletResponse;
	HttpServletResponse = httpServletResponse;

	Reset();
    }

    public void Reset()
    {
	FieldName = "";
	IsRequired = false;
	IsAllCharactersNumber = false;
	IsLatitudeOrLongitude = false;

	IsStringInput = false;
	StrInput = "";

	HasMinValue = false;
	HasMaxValue = false;

	IsInteger = false;
	IntInput = 0;
	MinimumIntValue = 0;
	MaximumIntValue = 0;

	IsLong = false;
	LongInput = 0;
	MinimumLongValue = 0;
	MaximumLongValue = 0;
    }

    private String validateForStringInput()
    {
	// Checks if Numeric value of String input is valid
	if (IsStringInput == false) {
	    return "";
	}

	// Checks value is required
	if (IsRequired == true) {
	    if (StrInput == null || StrInput == "") {
		return "Provide numeric value for " + FieldName + ".";
	    }
	}
	else if (StrInput == null || StrInput == "") {
	    return "";
	}

	if (IsInteger) {
	    // Parses to int value
	    try {
		IntInput = Integer.parseInt(StrInput);
	    }
	    catch (NumberFormatException e) {
		return FieldName + " is not integer.";
	    }
	}

	if (IsLong) {
	    // Parses to Long value
	    try {
		LongInput = Long.parseLong(StrInput);
	    }
	    catch (NumberFormatException e) {
		return FieldName + " is not long.";
	    }
	}

	return "";
    }

    private String checkValueBetweenMinMax()
    {
	// Checks whether input is integer
	if (IsInteger) {

	    // checks for min Int
	    if (HasMinValue == true) {
		if (IntInput < MinimumIntValue) {
		    return FieldName + " value is invalid.";
		}
	    }

	    // checks for max Int
	    if (HasMaxValue == true) {
		if (IntInput > MaximumIntValue) {
		    return FieldName + " value is invalid.";
		}
	    }

	}

	// Checks whether input is Long
	if (IsLong) {

	    // checks for min Long
	    if (HasMinValue == true) {
		if (LongInput < MinimumLongValue) {
		    return FieldName + " value is invalid.";
		}
	    }

	    // checks for max Long
	    if (HasMaxValue == true) {
		if (LongInput > MaximumLongValue) {
		    return FieldName + " value is invalid.";
		}
	    }
	}

	return "";
    }

    private String isAllCharactersareNumbers()
    {
	// Checks Whether String input characters are all numbers
	if (IsAllCharactersNumber == false) {
	    return "";
	}

	if (Utils.isAllCharactersareNumbers(StrInput) == false) {
	    return FieldName + " is not integer.";
	}

	return "";
    }

    private String isValueLatitudeOrLongitude()
    {
	// Checks whether input value is Latitude or Latitude
	if (IsLatitudeOrLongitude == false) {
	    return "";
	}

	if (Utils.isValueLatitudeOrLongitude(StrInput) == false) {
	    return FieldName + " value is invalid.";
	}

	return "";
    }

    public String isValueNumeric()
    {
	String strErrorMessage = "";

	// validates if input is String
	strErrorMessage = validateForStringInput();
	if (strErrorMessage != "")
	    return strErrorMessage;

	// validates if input is between Min and Max
	strErrorMessage = checkValueBetweenMinMax();
	if (strErrorMessage != "")
	    return strErrorMessage;

	// validates if input all charactrs are numeric
	strErrorMessage = isAllCharactersareNumbers();
	if (strErrorMessage != "")
	    return strErrorMessage;

	// validates if Input is Latitude or Longitude
	strErrorMessage = isValueLatitudeOrLongitude();
	if (strErrorMessage != "")
	    return strErrorMessage;

	return "";
    }

    public Boolean isValueNumericToResponse()
            throws IOException
    {
	String strMessage = isValueNumeric();

	if (strMessage == "") {
	    return true;
	}
	else {
	    Utils.addErrorResponse(HttpServletResponse, strMessage);
	    return false;
	}
    }
}
