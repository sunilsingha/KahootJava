package validation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import utils.Utils;


public class ValidateNumberArray
{
    public boolean	       UpdateToHttpServletResponse;
    public HttpServletResponse HttpServletResponse;
    public String	       FieldName;
    public boolean	       IsRequired;
    public boolean	       CheckDuplicates;
    public boolean	       IsAllCharactersNumber;
    public boolean	       IsLatitudeOrLongitude;

    public boolean HasMinimumItemsCount;
    public int	   MinimumItemsCount;
    public boolean HasMaximumItemsCount;
    public int	   MaximumItemsCount;

    public boolean	IsStringInput;
    public List<String>	StringArrayInput;

    public boolean HasMinValue;
    public boolean HasMaxValue;

    public boolean	 IsInteger;
    public List<Integer> IntArrayInput;
    public int		 MinimumIntValue;
    public int		 MaximumIntValue;

    public boolean    IsLong;
    public List<Long> LongArrayInput;
    public long	      MinimumLongValue;
    public long	      MaximumLongValue;


    public ValidateNumberArray(HttpServletResponse httpServletResponse, Boolean updateToHttpServletResponse)
    {
	HttpServletResponse = httpServletResponse;
	UpdateToHttpServletResponse = updateToHttpServletResponse;

	Reset();
    }


    public void Reset()
    {
	FieldName = "";
	IsRequired = false;
	IsAllCharactersNumber = false;
	IsLatitudeOrLongitude = false;

	HasMinimumItemsCount = false;
	MinimumItemsCount = -1;
	HasMaximumItemsCount = false;
	MaximumItemsCount = -1;

	IsStringInput = false;
	StringArrayInput = null;

	HasMinValue = false;
	HasMaxValue = false;

	IsInteger = false;
	IntArrayInput = null;
	MinimumIntValue = 0;
	MaximumIntValue = 0;

	IsLong = false;
	LongArrayInput = null;
	MinimumLongValue = 0L;
	MaximumLongValue = 0L;
    }


    private boolean checkInputHasValue()
    {
	if (IsStringInput)
	{
	    if (StringArrayInput == null)
	    {
		return false;
	    }

	    if (StringArrayInput.size() == 0)
	    {
		return false;
	    }
	}

	if (IsLong == true && IsStringInput == false)
	{
	    if (LongArrayInput == null)
	    {
		return false;
	    }

	    if (LongArrayInput.size() == 0)
	    {
		return false;
	    }
	}

	if (IsInteger == true && IsStringInput == false)
	{
	    if (IntArrayInput == null)
	    {
		return false;
	    }

	    if (IntArrayInput.size() == 0)
	    {
		return false;
	    }
	}

	return true;
    }


    private String checkInputRequired()
    {
	// Checks whether input is required
	if (IsRequired == true)
	{
	    // Checks String array
	    if (IsStringInput)
	    {
		if (StringArrayInput == null)
		{
		    return "Provide string array value for " + FieldName + ".";
		}

		if (StringArrayInput.size() == 0)
		{
		    return "Provide string array value for " + FieldName + ".";
		}
	    }

	    // Checks for long array
	    if (IsLong == true && IsStringInput == false)
	    {
		if (LongArrayInput == null)
		{
		    return "Provide long array value for " + FieldName + ".";
		}

		if (LongArrayInput.size() == 0)
		{
		    return "Provide long array value for " + FieldName + ".";
		}
	    }

	    // checks for integer array
	    if (IsInteger == true && IsStringInput == false)
	    {
		if (IntArrayInput == null)
		{
		    return "Provide integer array value for " + FieldName + ".";
		}

		if (IntArrayInput.size() == 0)
		{
		    return "Provide integer array value for " + FieldName + ".";
		}
	    }
	}

	return "";
    }


    private String findDuplicateItemsInStringArray()
    {
	if (StringArrayInput == null)
	{
	    return "";
	}

	if (StringArrayInput.size() == 0)
	{
	    return "";
	}

	int i = 0;
	int j = 0;
	int k = 0;
	List<String> uniqueArray = new ArrayList<String>();
	Boolean blUnique = true;
	List<String> duplicateArray = new ArrayList<String>();
	Boolean blDuplicateAdded = false;
	String strDuplicateValues = "";
	String strMessage = "";

	i = 0;
	for (; i < StringArrayInput.size(); i++)
	{

	    j = 0;
	    blUnique = true;
	    for (; j < uniqueArray.size(); j++)
	    {

		if (StringArrayInput.get(i).toUpperCase().trim() == uniqueArray.get(j).toUpperCase().trim())
		{

		    blDuplicateAdded = false;
		    k = 0;
		    for (; k < duplicateArray.size(); k++)
		    {
			if (StringArrayInput.get(i).toUpperCase().trim() == duplicateArray.get(k).toUpperCase().trim())
			{
			    blDuplicateAdded = true;
			    break;
			}
		    }

		    if (blDuplicateAdded == false)
		    {
			duplicateArray.add(StringArrayInput.get(i).trim());
		    }

		    blUnique = false;
		    break;
		}
	    }

	    if (blUnique == true)
	    {
		uniqueArray.add(StringArrayInput.get(i).trim());
	    }
	}

	if (duplicateArray.size() == 0)
	{
	    return "";
	}

	i = 0;
	for (; i < duplicateArray.size(); i++)
	{
	    if (strDuplicateValues != "")
	    {
		strDuplicateValues += ", ";
	    }

	    strDuplicateValues += "'" + duplicateArray.get(i) + "'";
	}

	if (duplicateArray.size() == 1)
	{
	    strMessage = "Duplicate value ";
	}
	else
	{
	    strMessage = "Duplicate values ";
	}

	strMessage += strDuplicateValues + " found in the field " + FieldName + ".";

	return strMessage;
    }


    private String findDuplicateItemsInLongArray()
    {
	// Finding duplicate items in the array

	// checks whether Input has value
	if (LongArrayInput == null)
	{
	    return "";
	}

	if (LongArrayInput.size() == 0)
	{
	    return "";
	}

	int i = 0;
	int j = 0;
	int k = 0;
	List<Long> uniqueArray = new ArrayList<Long>();
	Boolean blUnique = true;
	List<Long> duplicateArray = new ArrayList<Long>();
	Boolean blDuplicateAdded = false;
	String strDuplicateValues = "";
	String strMessage = "";

	i = 0;
	for (; i < LongArrayInput.size(); i++)
	{
	    j = 0;
	    blUnique = true;
	    for (; j < uniqueArray.size(); j++)
	    {

		if (LongArrayInput.get(i) == uniqueArray.get(j))
		{

		    blDuplicateAdded = false;
		    k = 0;
		    for (; k < duplicateArray.size(); k++)
		    {
			if (LongArrayInput.get(i) == duplicateArray.get(k))
			{
			    blDuplicateAdded = true;
			    break;
			}
		    }

		    if (blDuplicateAdded == false)
		    {
			duplicateArray.add(LongArrayInput.get(i));
		    }

		    blUnique = false;
		    break;
		}
	    }

	    if (blUnique == true)
	    {
		uniqueArray.add(LongArrayInput.get(i));
	    }
	}

	if (duplicateArray.size() == 0)
	{
	    return "";
	}

	i = 0;
	for (; i < duplicateArray.size(); i++)
	{
	    if (strDuplicateValues != "")
	    {
		strDuplicateValues += ", ";
	    }

	    strDuplicateValues += "'" + duplicateArray.get(i) + "'";
	}

	if (duplicateArray.size() == 1)
	{
	    strMessage = "Duplicate value ";
	}
	else
	{
	    strMessage = "Duplicate values ";
	}

	strMessage += strDuplicateValues + " found in the field " + FieldName + ".";

	return strMessage;
    }


    private String findDuplicateItemsInIntegerArray()
    {
	// Finding duplicate items in the array

	// checks whether Input has value
	if (IntArrayInput == null)
	{
	    return "";
	}

	if (IntArrayInput.size() == 0)
	{
	    return "";
	}

	int i = 0;
	int j = 0;
	int k = 0;
	List<Integer> uniqueArray = new ArrayList<Integer>();
	Boolean blUnique = true;
	List<Integer> duplicateArray = new ArrayList<Integer>();
	Boolean blDuplicateAdded = false;
	String strDuplicateValues = "";
	String strMessage = "";

	i = 0;
	for (; i < IntArrayInput.size(); i++)
	{

	    j = 0;
	    blUnique = true;
	    for (; j < uniqueArray.size(); j++)
	    {

		if (IntArrayInput.get(i) == uniqueArray.get(j))
		{

		    blDuplicateAdded = false;
		    k = 0;
		    for (; k < duplicateArray.size(); k++)
		    {
			if (IntArrayInput.get(i) == duplicateArray.get(k))
			{
			    blDuplicateAdded = true;
			    break;
			}
		    }

		    if (blDuplicateAdded == false)
		    {
			duplicateArray.add(IntArrayInput.get(i));
		    }

		    blUnique = false;
		    break;
		}
	    }

	    if (blUnique == true)
	    {
		uniqueArray.add(IntArrayInput.get(i));
	    }
	}

	if (duplicateArray.size() == 0)
	{
	    return "";
	}

	i = 0;
	for (; i < duplicateArray.size(); i++)
	{
	    if (strDuplicateValues != "")
	    {
		strDuplicateValues += ", ";
	    }

	    strDuplicateValues += "'" + duplicateArray.get(i) + "'";
	}

	if (duplicateArray.size() == 1)
	{
	    strMessage = "Duplicate value ";
	}
	else
	{
	    strMessage = "Duplicate values ";
	}

	strMessage += strDuplicateValues + " found in the field " + FieldName + ".";

	return strMessage;
    }


    private String findDuplicateItemsInArray()
    {
	// Finding duplicate items in the array
	if (CheckDuplicates == false)
	{
	    return "";
	}

	// checks whether Input has value
	if (IsStringInput)
	{
	    return findDuplicateItemsInStringArray();
	}

	// checks whether Input is Long
	if (IsLong == true && IsStringInput == false)
	{
	    return findDuplicateItemsInLongArray();
	}

	// check whether Input is Integer
	if (IsInteger == true && IsStringInput == false)
	{
	    return findDuplicateItemsInIntegerArray();
	}

	return "";
    }


    private String checkValueBetweenMinMaxItemsCount()
    {
	// Checks if both items count are equal
	if (HasMinimumItemsCount && HasMaximumItemsCount)
	{
	    if (MinimumItemsCount > 0 && MinimumItemsCount == MaximumItemsCount)
	    {
		// checks for String
		if (IsStringInput)
		{
		    if (StringArrayInput == null)
		    {
			return "";
		    }

		    if (StringArrayInput.size() != MinimumItemsCount)
		    {
			if (MinimumItemsCount == 1)
			{
			    return FieldName + " should have 1 item.";
			}
			else
			{
			    return FieldName + " should have " + MinimumItemsCount + " items.";
			}
		    }
		}

		// checks for Long
		if (IsLong == true && IsStringInput == false)
		{
		    if (LongArrayInput == null)
		    {
			return "";
		    }

		    if (LongArrayInput.size() != MinimumItemsCount)
		    {
			if (MinimumItemsCount == 1)
			{
			    return FieldName + " should have 1 item.";
			}
			else
			{
			    return FieldName + " should have " + MinimumItemsCount + " items.";
			}
		    }
		}

		// checks for Integer
		if (IsInteger == true && IsStringInput == false)
		{
		    if (IntArrayInput == null)
		    {
			return "";
		    }

		    if (IntArrayInput.size() != MinimumItemsCount)
		    {
			if (MinimumItemsCount == 1)
			{
			    return FieldName + " should have 1 item.";
			}
			else
			{
			    return FieldName + " should have " + MinimumItemsCount + " items.";
			}
		    }
		}
	    }
	}

	// Checks array Count
	if (HasMinimumItemsCount == true)
	{
	    if (MinimumItemsCount > 0)
	    {

		// checks for String
		if (IsStringInput)
		{
		    if (StringArrayInput == null)
		    {
			return "";
		    }

		    if (StringArrayInput.size() < MinimumItemsCount)
		    {
			if (MinimumItemsCount == 1)
			{
			    return FieldName + " should have atleast 1 item.";
			}
			else
			{
			    return FieldName + " should have atleast " + MinimumItemsCount + " item.";
			}
		    }
		}

		// checks for Long
		if (IsLong == true && IsStringInput == false)
		{
		    if (LongArrayInput == null)
		    {
			return "";
		    }

		    if (LongArrayInput.size() < MinimumItemsCount)
		    {
			if (MinimumItemsCount == 1)
			{
			    return FieldName + " should have atleast 1 item.";
			}
			else
			{
			    return FieldName + " should have atleast " + MinimumItemsCount + " item.";
			}
		    }
		}

		// checks for Integer
		if (IsInteger == true && IsStringInput == false)
		{
		    if (IntArrayInput == null)
		    {
			return "";
		    }

		    if (IntArrayInput.size() < MinimumItemsCount)
		    {
			if (MinimumItemsCount == 1)
			{
			    return FieldName + " should have atleast 1 item.";
			}
			else
			{
			    return FieldName + " should have atleast " + MinimumItemsCount + " item.";
			}
		    }
		}
	    }
	}

	// Checks array count for maximum
	if (HasMaximumItemsCount == true)
	{
	    if (MaximumItemsCount > 0)
	    {
		// checks for String
		if (IsStringInput)
		{
		    if (StringArrayInput == null)
		    {
			return "";
		    }
		    if (StringArrayInput.size() > MaximumItemsCount)
		    {
			if (MaximumItemsCount == 1)
			{
			    return FieldName + " should not be more than 1 item.";
			}
			else
			{
			    return FieldName + " should not exceed more than " + MaximumItemsCount + " items.";
			}
		    }
		}

		// checks for Long
		if (IsLong == true && IsStringInput == false)
		{
		    if (LongArrayInput == null)
		    {
			return "";
		    }

		    if (LongArrayInput.size() > MaximumItemsCount)
		    {
			if (MaximumItemsCount == 1)
			{
			    return FieldName + " should not be more than 1 item.";
			}
			else
			{
			    return FieldName + " should not exceed more than " + MaximumItemsCount + " items.";
			}
		    }
		}

		// checks for Integer
		if (IsInteger == true && IsStringInput == false)
		{
		    if (IntArrayInput == null)
		    {
			return "";
		    }

		    if (IntArrayInput.size() > MaximumItemsCount)
		    {
			if (MaximumItemsCount == 1)
			{
			    return FieldName + " should not be more than 1 item.";
			}
			else
			{
			    return FieldName + " should not exceed more than " + MaximumItemsCount + " items.";
			}
		    }
		}
	    }
	}

	return "";
    }


    public String IsNumberArray()
    {
	String strErrorMessage = "";

	// Checks whether String input is required
	strErrorMessage = checkInputRequired();
	if (strErrorMessage != "")
	    return strErrorMessage;

	// validates number of items
	strErrorMessage = checkValueBetweenMinMaxItemsCount();
	if (strErrorMessage != "")
	    return strErrorMessage;

	// Finds duplicate Items in the array
	strErrorMessage = findDuplicateItemsInArray();
	if (strErrorMessage != "")
	    return strErrorMessage;

	return strErrorMessage;
    }


    public List<String> ValidateEachItemInArray()
    {
	// Check String values inside the array and using the checklist.
	// to check the values it will sent to StringUtils

	ValidateNumber validateNumber = new ValidateNumber(null, false);

	// Checks whether Input has value
	if (checkInputHasValue() == false)
	{
	    return new ArrayList<String>();
	}

	// loops through the array
	int i = 0;
	List<String> messageList = new ArrayList<String>();
	String errorMessage = "";

	// checks if there is any error in string value
	if (IsStringInput)
	{
	    for (i = 0; i < StringArrayInput.size(); i++)
	    {
		validateNumber.Reset();

		validateNumber.IsStringInput = IsStringInput;
		validateNumber.StrInput = StringArrayInput.get(i);
		validateNumber.FieldName = "Item " + (i + 1);
		validateNumber.IsAllCharactersNumber = IsAllCharactersNumber;
		validateNumber.IsLatitudeOrLongitude = IsLatitudeOrLongitude;
		validateNumber.IsRequired = true;

		validateNumber.HasMaxValue = HasMaxValue;
		validateNumber.HasMinValue = HasMinValue;

		validateNumber.IsInteger = IsInteger;
		validateNumber.MinimumIntValue = MinimumIntValue;
		validateNumber.MaximumIntValue = MaximumIntValue;

		validateNumber.IsLong = IsLong;
		validateNumber.MinimumLongValue = MinimumLongValue;
		validateNumber.MaximumLongValue = MaximumLongValue;

		errorMessage = validateNumber.isValueNumeric();

		if (errorMessage != "")
		{
		    messageList.add(errorMessage);
		}
	    }
	}
	else if (IsInteger == true && IsStringInput == false)
	{
	    for (i = 0; i < IntArrayInput.size(); i++)
	    {
		validateNumber.Reset();

		validateNumber.IsStringInput = IsStringInput;
		validateNumber.IntInput = IntArrayInput.get(i);
		validateNumber.FieldName = "Item " + (i + 1);
		validateNumber.IsAllCharactersNumber = IsAllCharactersNumber;
		validateNumber.IsLatitudeOrLongitude = IsLatitudeOrLongitude;
		validateNumber.IsRequired = true;

		validateNumber.HasMaxValue = HasMaxValue;
		validateNumber.HasMinValue = HasMinValue;

		validateNumber.IsInteger = IsInteger;
		validateNumber.MinimumIntValue = MinimumIntValue;
		validateNumber.MaximumIntValue = MaximumIntValue;

		validateNumber.IsLong = IsLong;
		validateNumber.MinimumLongValue = MinimumLongValue;
		validateNumber.MaximumLongValue = MaximumLongValue;

		errorMessage = validateNumber.isValueNumeric();

		if (errorMessage != "")
		{
		    messageList.add(errorMessage);
		}
	    }
	}
	else if (IsLong == true && IsStringInput == false)
	{
	    for (i = 0; i < LongArrayInput.size(); i++)
	    {
		validateNumber.Reset();

		validateNumber.IsStringInput = IsStringInput;
		validateNumber.LongInput = LongArrayInput.get(i);
		validateNumber.FieldName = "Item " + (i + 1);
		validateNumber.IsAllCharactersNumber = IsAllCharactersNumber;
		validateNumber.IsLatitudeOrLongitude = IsLatitudeOrLongitude;
		validateNumber.IsRequired = true;

		validateNumber.HasMaxValue = HasMaxValue;
		validateNumber.HasMinValue = HasMinValue;

		validateNumber.IsInteger = IsInteger;
		validateNumber.MinimumIntValue = MinimumIntValue;
		validateNumber.MaximumIntValue = MaximumIntValue;

		validateNumber.IsLong = IsLong;
		validateNumber.MinimumLongValue = MinimumLongValue;
		validateNumber.MaximumLongValue = MaximumLongValue;

		errorMessage = validateNumber.isValueNumeric();

		if (errorMessage != "")
		{
		    messageList.add(errorMessage);
		}
	    }
	}

	return messageList;
    }


    public boolean IsNumberArrayToResponse()
            throws IOException
    {
	// checks input is array and Items in the array
	String strMessage = IsNumberArray();

	if (strMessage != "")
	{
	    Utils.addErrorResponse(HttpServletResponse, strMessage);
	    return false;
	}

	// checks string values inside the array
	List<String> messageList = ValidateEachItemInArray();

	if (messageList.size() > 0)
	{
	    Utils.addErrorListResponse(HttpServletResponse, "Error in the field " + FieldName + ".", messageList);
	    return false;
	}

	return true;
    }
}
