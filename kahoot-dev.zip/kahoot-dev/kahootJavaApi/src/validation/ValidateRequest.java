package validation;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import utils.Utils;


public class ValidateRequest
{
    public static boolean IsJSONRequest(HttpServletRequest request, HttpServletResponse response)
            throws IOException
    {
	// Reads content type
	String strContentType = request.getContentType();

	// Checks content Type is null
	if (strContentType == null)
	{
	    Utils.addErrorResponse(response, "Invalid request.");
	    return false;
	}

	// Checks content type is application/json
	strContentType = strContentType.toLowerCase();
	if (strContentType.contains("application/json") == false)
	{
	    Utils.addErrorResponse(response, "Invalid request.");
	    return false;
	}

	return true;
    }
}
