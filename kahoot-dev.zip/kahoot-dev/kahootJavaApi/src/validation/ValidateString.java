package validation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import utils.StringUtils;
import utils.Utils;

public class ValidateString
{
    public boolean	       UpdateToHttpServletResponse;
    public HttpServletResponse HttpServletResponse;
    public String	       Input;
    public String	       FieldName;
    public boolean	       IsRequired;
    public boolean	       IsValueWillBeTrimmed;
    public boolean	       IsValueInCheckList;
    public boolean	       IsEmail;
    public boolean	       IsAllCharactersNumber;
    public boolean	       IsLatitudeOrLongitude;

    public boolean HasMinimumLength;
    public boolean HasMaximumLength;
    public int	   MinimumLength;
    public int	   MaximumLength;

    public List<String> CheckList;

    public ValidateString(HttpServletResponse httpServletResponse, Boolean updateToHttpServletResponse)
    {
	HttpServletResponse = httpServletResponse;
	UpdateToHttpServletResponse = updateToHttpServletResponse;

	Reset();
    }

    public void Reset()
    {
	Input = "";
	FieldName = "";
	IsRequired = false;
	HasMinimumLength = false; 
	MinimumLength = -1;
	HasMaximumLength = false;
	MaximumLength = -1;
	CheckList = new ArrayList<String>();
	IsEmail = false;
	IsAllCharactersNumber = false;
	IsLatitudeOrLongitude = false;
    }

    private boolean checkInputHasValue()
    {
	if (Input == null || Input == "") {
	    return false;
	}

	if (IsValueWillBeTrimmed == true && Input.trim().length() == 0) {
	    return false;
	}

	return true;
    }

    private String checkInputRequired()
    {
	// Checks field is Required
	if (IsRequired == true) {
	    if (Input == null) {
		return "Provide string value for " + FieldName + ".";
	    }

	    else if (IsValueWillBeTrimmed == true && Input.trim().length() == 0) {
		return "Provide string value for " + FieldName + ".";
	    }
	    else if (Input.length() == 0) {
		return "Provide string value for " + FieldName + ".";
	    }
	}
	else if (Input == null) {
	    return "";
	}

	return "";
    }

    private String checkValueBetweenMinMaxLength()
    {
	if (checkInputHasValue() == false) {
	    return "";
	}

	// Checks value is more than or equal to minimum length
	if (HasMinimumLength == true) {
	    if (Input.length() < MinimumLength) {
		return FieldName + " should be at least " + MinimumLength + " characters.";
	    }
	}

	// Checks values is between Maximum length
	if (HasMaximumLength == true) {
	    if (Input.length() > MaximumLength) {
		return FieldName + " should not exceed more than " + MaximumLength + " characters.";
	    }
	}

	return "";
    }

    private String checkValueInCheckList()
    {
	if (checkInputHasValue() == false) {
	    return "";
	}

	if (IsValueInCheckList == false) {
	    return "";
	}

	// checks value in check List
	if (CheckList.size() > 0) {
	    int i = 0;
	    boolean blFound = false;

	    blFound = StringUtils.isValue_in_List(Input, CheckList);

	    if (blFound == false) {
		if (CheckList.size() <= 5) {
		    String strValues = "";

		    for (i = 0; i < CheckList.size(); i++) {
			if (strValues != "") {
			    strValues += ", ";
			}
			strValues += CheckList.get(i);
		    }

		    return FieldName + " value should be either " + strValues;
		}
		else {
		    return FieldName + " value is invalid.";
		}
	    }
	}

	return "";
    }

    private String validateEmail()
    {
	if (Input == null) {
	    return "";
	}

	// Checks whether input value is email
	if (IsEmail == true) {
	    if (Utils.validateEmail(Input) == false) {
		return FieldName + " is not email.";
	    }
	}

	return "";
    }

    private String isAllCharactersAreNumeric()
    {
	if (Input == null) {
	    return "";
	}

	// Checks Whether String input characters are all numbers
	if (IsAllCharactersNumber == false) {
	    return "";
	}

	if (Utils.isAllCharactersareNumbers(Input) == false) {
	    return FieldName + " is not integer.";
	}

	return "";
    }

    private String isValueLatitudeOrLongitude()
    {
	if (Input == null) {
	    return "";
	}

	// Checks whether input value is Latitude or Latitude
	if (IsLatitudeOrLongitude == false) {
	    return "";
	}

	if (Utils.isValueLatitudeOrLongitude(Input) == false) {
	    return FieldName + " value is invalid.";
	}

	return "";
    }

    public String IsValueString()
    {
	String strErrorMessage = "";

	// Checks whether String input is required
	strErrorMessage = checkInputRequired();
	if (strErrorMessage != "")
	    return strErrorMessage;

	// Checks input string value is between Minimum length and maximum length
	strErrorMessage = checkValueBetweenMinMaxLength();
	if (strErrorMessage != "")
	    return strErrorMessage;

	// Checks whether input value in In Check List
	strErrorMessage = checkValueInCheckList();
	if (strErrorMessage != "")
	    return strErrorMessage;

	// Checks whether input value is email
	strErrorMessage = validateEmail();
	if (strErrorMessage != "")
	    return strErrorMessage;

	// Checks whether all the characters in input are numbers
	strErrorMessage = isAllCharactersAreNumeric();
	if (strErrorMessage != "")
	    return strErrorMessage;

	// Checks whether input is latitude or longitude
	strErrorMessage = isValueLatitudeOrLongitude();
	if (strErrorMessage != "")
	    return strErrorMessage;

	return strErrorMessage;
    }

    public Boolean isValueStringToResponse()
    {
	String strMessage = IsValueString();

	if (strMessage == "") {
	    return true;
	}
	else {
	    try {
		Utils.addErrorResponse(HttpServletResponse, strMessage);
	    }
	    catch (IOException e) {
		e.printStackTrace();
	    }

	    return false;
	}
    }

}
