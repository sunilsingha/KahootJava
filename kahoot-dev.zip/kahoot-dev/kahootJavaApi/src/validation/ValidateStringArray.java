package validation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import utils.Utils;


public class ValidateStringArray
{
    public boolean	       UpdateToHttpServletResponse;
    public HttpServletResponse HttpServletResponse;
    public List<String>	       Input;
    public String	       FieldName;
    public boolean	       IsRequired;
    public boolean	       IsValueWillBeTrimmed;
    public boolean	       IsValueInCheckList;
    public boolean	       IsEmail;
    public boolean	       CheckDuplicates;
    public boolean	       IsAllCharactersNumber;
    public boolean	       IsLatitudeOrLongitude;

    public boolean HasMinimumStringLength;
    public int	   MinimumStringLength;
    public boolean HasMaximumStringLength;
    public int	   MaximumStringLength;

    public boolean HasMinimumItemsCount;
    public int	   MinimumItemsCount;
    public boolean HasMaximumItemsCount;
    public int	   MaximumItemsCount;

    public List<String> CheckList;


    public ValidateStringArray(HttpServletResponse httpServletResponse, Boolean updateToHttpServletResponse)
    {
	HttpServletResponse = httpServletResponse;
	UpdateToHttpServletResponse = updateToHttpServletResponse;

	Reset();
    }


    public void Reset()
    {
	Input = null;
	FieldName = "";
	IsRequired = false;
	IsValueWillBeTrimmed = false;
	IsValueInCheckList = false;
	IsEmail = false;
	CheckDuplicates = false;

	HasMinimumStringLength = false;
	MinimumStringLength = -1;
	HasMaximumStringLength = false;
	MaximumStringLength = -1;

	HasMinimumItemsCount = false;
	MinimumItemsCount = -1;
	HasMaximumItemsCount = false;
	MaximumItemsCount = -1;
    }


    private String checkInputRequired()
    {
	if (IsRequired == true)
	{
	    if (Input == null)
	    {
		return "Provide string array value for " + FieldName + ".";
	    }

	    if (Input.size() == 0)
	    {
		return "Provide string array value for " + FieldName + ".";
	    }
	}
	else if (Input == null)
	{
	    return "";
	}

	return "";
    }


    private String checkValueBetweenMinMaxItemsCount()
    {
	if (Input == null)
	{
	    return "";
	}

	// Checks if both items count are equal
	if (HasMinimumItemsCount && HasMaximumItemsCount)
	{
	    if (MinimumItemsCount > 0 && MinimumItemsCount == MaximumItemsCount)
	    {
		if (Input.size() != MinimumItemsCount)
		{
		    if (MinimumItemsCount == 1)
		    {
			return FieldName + " should have 1 item.";
		    }
		    else
		    {
			return FieldName + " should have " + MinimumItemsCount + " items.";
		    }
		}
	    }
	}

	// Checks array Count
	if (HasMinimumItemsCount == true)
	{
	    if (MinimumItemsCount > 0)
	    {
		if (Input.size() < MinimumItemsCount)
		{
		    if (MinimumItemsCount == 1)
		    {
			return FieldName + " should have atleast 1 item.";
		    }
		    else
		    {
			return FieldName + " should have atleast " + MinimumItemsCount + " item.";
		    }
		}
	    }
	}

	// Checks array count for maximum
	if (HasMaximumItemsCount == true)
	{
	    if (MaximumItemsCount > 0)
	    {
		if (Input.size() > MaximumItemsCount)
		{
		    if (MaximumItemsCount == 1)
		    {
			return FieldName + " should not be more than 1 item.";
		    }
		    else
		    {
			return FieldName + " should not exceed more than " + MaximumItemsCount + " items.";
		    }
		}
	    }
	}

	return "";
    }


    private String findDuplicateItemsInArray()
    {
	// Finding duplicate items in the array

	// checks whether Input has value
	if (Input == null)
	{
	    return "";
	}

	if (CheckDuplicates == false)
	{
	    return "";
	}

	int i = 0;
	int j = 0;
	int k = 0;
	List<String> uniqueArray = new ArrayList<String>();
	Boolean blUnique = true;
	List<String> duplicateArray = new ArrayList<String>();
	Boolean blDuplicateAdded = false;
	String strDuplicateValues = "";
	String strMessage = "";

	i = 0;
	for (; i < Input.size(); i++)
	{

	    j = 0;
	    blUnique = true;
	    for (; j < uniqueArray.size(); j++)
	    {

		if (Input.get(i).toUpperCase().trim() == uniqueArray.get(j).toUpperCase().trim())
		{

		    blDuplicateAdded = false;
		    k = 0;
		    for (; k < duplicateArray.size(); k++)
		    {
			if (Input.get(i).toUpperCase().trim() == duplicateArray.get(k).toUpperCase().trim())
			{
			    blDuplicateAdded = true;
			    break;
			}
		    }

		    if (blDuplicateAdded == false)
		    {
			duplicateArray.add(Input.get(i).trim());
		    }

		    blUnique = false;
		    break;
		}
	    }

	    if (blUnique == true)
	    {
		uniqueArray.add(Input.get(i).trim());
	    }
	}

	if (duplicateArray.size() == 0)
	{
	    return "";
	}

	i = 0;
	for (; i < duplicateArray.size(); i++)
	{
	    if (strDuplicateValues != "")
	    {
		strDuplicateValues += ", ";
	    }

	    strDuplicateValues += "'" + duplicateArray.get(i) + "'";
	}

	if (duplicateArray.size() == 1)
	{
	    strMessage = "Duplicate value ";
	}
	else
	{
	    strMessage = "Duplicate values ";
	}

	strMessage += strDuplicateValues + " found in the field " + FieldName + ".";

	return strMessage;
    }


    public String IsStringArray()
    {
	String strErrorMessage = "";

	// Checks whether String input is required
	strErrorMessage = checkInputRequired();
	if (strErrorMessage != "")
	    return strErrorMessage;

	// validates number of items
	strErrorMessage = checkValueBetweenMinMaxItemsCount();
	if (strErrorMessage != "")
	    return strErrorMessage;

	// Finds duplicate Items in the array
	strErrorMessage = findDuplicateItemsInArray();
	if (strErrorMessage != "")
	    return strErrorMessage;

	return strErrorMessage;
    }


    public List<String> ValidateEachStringItemInArray()
    {
	// Check String values inside the array and using the checklist.
	// to check the values it will sent to StringUtils

	ValidateString validateString = new ValidateString(null, false);

	// Checks whether Input has value
	if (Input == null)
	{
	    return new ArrayList<String>();
	}

	// loops through the array
	int i = 0;
	List<String> messageList = new ArrayList<String>();
	String errorMessage = "";

	// checks if there is any error in string value
	for (; i < Input.size(); i++)
	{
	    validateString.Reset();

	    validateString.Input = Input.get(i);
	    validateString.FieldName = "Item " + (i + 1);

	    validateString.HasMinimumLength = HasMinimumStringLength;
	    validateString.HasMaximumLength = HasMaximumStringLength;
	    validateString.MinimumLength = MinimumStringLength;
	    validateString.MaximumLength = MaximumStringLength;

	    validateString.IsValueInCheckList = IsValueInCheckList;
	    validateString.CheckList = CheckList;

	    validateString.IsEmail = IsEmail;
	    validateString.IsAllCharactersNumber = IsAllCharactersNumber;
	    validateString.IsLatitudeOrLongitude = IsLatitudeOrLongitude;

	    errorMessage = validateString.IsValueString();

	    if (errorMessage != "")
	    {
		messageList.add(errorMessage);
	    }
	}

	return messageList;
    }


    public boolean IsStringArrayToResponse()
            throws IOException
    {
	// checks input is array and Items in the array
	String strMessage = IsStringArray();

	if (strMessage != "")
	{
	    Utils.addErrorResponse(HttpServletResponse, strMessage);
	    return false;
	}

	// checks string values inside the array
	List<String> messageList = ValidateEachStringItemInArray();

	if (messageList.size() > 0)
	{
	    Utils.addErrorListResponse(HttpServletResponse, "Error in the field " + FieldName + ".", messageList);
	    return false;
	}

	return true;
    }

}
