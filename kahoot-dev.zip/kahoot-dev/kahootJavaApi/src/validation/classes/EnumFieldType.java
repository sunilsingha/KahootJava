package validation.classes;

public enum EnumFieldType {
    File, Text
}
