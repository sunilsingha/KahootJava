package validation.classes;

public class FormField
{
    public FormField()
    {

    }


    public FormField(String fieldName, EnumFieldType fieldType, boolean isMultiple)
    {
	this.FieldName = fieldName;
	this.FieldType = fieldType;
	this.IsMultiple = isMultiple;
    }

    public String	 FieldName;
    public EnumFieldType FieldType;
    public boolean	 IsMultiple;

    public long	FieldCount;
    public long	TextInputCount;
    public long	FileInputCount;
}
