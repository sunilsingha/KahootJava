package admin;

import java.io.BufferedReader;

import java.io.IOException;
import java.sql.Connection;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.fasterxml.jackson.databind.ObjectMapper;

import adminrequest.AdminProfileRequest;
import adminresponse.AdminRegistrationResponse;
import adminservices.AdminService;
import db_operations.DBUtils;
import utils.Utils;

@WebServlet("/api/admin/AdminRegistration")
public class AdminRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		StringBuffer stringBuffer = new StringBuffer();
		AdminProfileRequest adminprofilerequest = null;
		AdminRegistrationResponse adminRegistrationResponse = null;
		AdminService adminService = null;
		String line = null;
		try
		{
		    BufferedReader reader = request.getReader();
		    while ((line = reader.readLine()) != null)
		    {
		    	stringBuffer.append(line);
		    }
		    ObjectMapper mapper = new ObjectMapper();
			String requestJson = stringBuffer.toString();
			adminprofilerequest = mapper.readValue(requestJson, AdminProfileRequest.class);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		adminService = new AdminService();

		Connection conn = null;
		conn = DBUtils.ConnectToDatabase(response);
		if (conn == null)
		{
		    return;
		}
		
		if(adminService.isAdminProfileExist(conn, adminprofilerequest.userName, adminprofilerequest.userPassword))
		{
			adminRegistrationResponse = new AdminRegistrationResponse();
			long adminIdByUserName = adminService.getAdminIdService(conn, adminprofilerequest.userName);
			adminRegistrationResponse = adminService.getAdminProfile(conn, adminIdByUserName);
			
			Utils.addSuccessResponseFromObject(response, adminRegistrationResponse);
			DBUtils.CloseConnection(conn);
			
		}
		else
		{
			adminRegistrationResponse = new AdminRegistrationResponse();
			adminRegistrationResponse.message = "user id or password is wrong";
			adminRegistrationResponse.responseType ="E";
			Utils.addSuccessResponseFromObject(response, adminRegistrationResponse);
			DBUtils.CloseConnection(conn);
		}
	}

}
