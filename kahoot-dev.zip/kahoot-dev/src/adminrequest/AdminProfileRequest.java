package adminrequest;

public class AdminProfileRequest 
{
	public String userName;
	public String userPassword;

}
