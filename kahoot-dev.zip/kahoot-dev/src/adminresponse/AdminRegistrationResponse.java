package adminresponse;

public class AdminRegistrationResponse 
{
	public String message;
	public String responseType;
	public String adminUserName;
	public long adminId;
	public String email;
	public String desiganation;

}
