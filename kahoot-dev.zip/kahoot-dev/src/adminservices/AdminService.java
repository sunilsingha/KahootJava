package adminservices;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;

import adminresponse.AdminRegistrationResponse;
import db_operations.AdminDBUtils;

public class AdminService 
{
	private String userName = null;
	private String userPassword = null;
	HashMap<String, String> existingAdminProfileMap = null;
	boolean isAdminProfileExist = false;
	public AdminRegistrationResponse adminRegResp = null;
	public boolean isAdminProfileExist(Connection conn, String userName,String userPassword)
	{
		this.userName = userName;
		this.userPassword = userPassword;
		try 
		{
			existingAdminProfileMap = AdminDBUtils.existingAdminProfileDetails(conn, userName, userPassword);
			if(existingAdminProfileMap != null)
			{
				String existingUserName = existingAdminProfileMap.get(userName);
				String existingUserPassword = existingAdminProfileMap.get(userPassword);
				if(userName.equalsIgnoreCase(existingUserName) && userPassword.equalsIgnoreCase(existingUserPassword))
				{
					isAdminProfileExist = true;
				}
				else
				{
					isAdminProfileExist = false;
				}
			}
			else
			{
				isAdminProfileExist = false;
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
		return isAdminProfileExist;
	}
	public AdminRegistrationResponse getAdminProfile(Connection conn, long adminId)
	{
		adminRegResp = AdminDBUtils.getAdminProfile(conn, adminId);
		return adminRegResp;
		
	}
	public long getAdminIdService(Connection conn, String adminUserName) 
	{
		return AdminDBUtils.getAdminIdDao(conn, adminUserName);
	}
	

}
