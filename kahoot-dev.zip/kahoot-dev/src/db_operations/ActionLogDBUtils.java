package db_operations;

import java.util.List;
import java.util.ArrayList;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;


public class ActionLogDBUtils
{

    private static final String	tblActionLogs	= "";//"\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblActionLogs + "\"";
    private static final String	sqnceActionLogs	= "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.sqnceActionLogs + "\"";


    public static Long getNextActionLogId(Connection conn)
            throws SQLException
    {
	return DBUtils.getNextSequenceId(conn, sqnceActionLogs);
    }


    private static SQLFieldsAndQueries getCommonSQLFields()
    {
	List<String> sqlFields = new ArrayList<String>();
	List<String> sqlValues = new ArrayList<String>();

	sqlFields.add("Id");
	sqlValues.add("?"); // 1

	sqlFields.add("CreatedOn");
	sqlValues.add("Now()");

	sqlFields.add("ContentId");
	sqlValues.add("?"); // 2

	sqlFields.add("ActionType");
	sqlValues.add("?"); // 3

	sqlFields.add("ActionByUserId");
	sqlValues.add("?"); // 4

	SQLFieldsAndQueries sqlFieldsAndQueries = new SQLFieldsAndQueries();

	sqlFieldsAndQueries.SQLFields = sqlFields;
	sqlFieldsAndQueries.SQLValues = sqlValues;

	return sqlFieldsAndQueries;
    }


    public static PreparedStatement updateValuesToCommonSQLFields(PreparedStatement pstmt, long actionLogId, Long contentId,
                                                                  String actionType, String userId)
            throws SQLException
    {
	pstmt.setLong(1, actionLogId);
	pstmt.setLong(2, contentId);
	pstmt.setNString(3, actionType);
	pstmt.setNString(4, userId);

	return pstmt;
    }


    private static void addActionLogforStatus(Connection conn, long actionLogId, long contentId, String action, String userId)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	SQLFieldsAndQueries objSQLFieldsValues = null;
	List<String> sqlFields = new ArrayList<String>();
	List<String> sqlValues = new ArrayList<String>();

	objSQLFieldsValues = getCommonSQLFields();
	sqlFields = objSQLFieldsValues.SQLFields;
	sqlValues = objSQLFieldsValues.SQLValues;

	sql = DBUtils.combineSQLInsertQuery(sqlFields, sqlValues, tblActionLogs);

	pstmt = conn.prepareStatement(sql);
	pstmt = updateValuesToCommonSQLFields(pstmt, actionLogId, contentId, action, userId);

	pstmt.execute();
	pstmt.close();
    }


    public static void addActionLogforInReview(Connection conn, Long actionLogId, Long contentId, String userId)
            throws SQLException
    {
	addActionLogforStatus(conn, actionLogId, contentId, "In Review", userId);
    }


    public static void addActionLogforPublished(Connection conn, long actionLogId, long contentId, String userId)
            throws SQLException
    {
	addActionLogforStatus(conn, actionLogId, contentId, "Published", userId);
    }
}
