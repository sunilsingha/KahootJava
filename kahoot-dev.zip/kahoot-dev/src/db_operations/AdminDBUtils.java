package db_operations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import adminresponse.AdminRegistrationResponse;
import quizresponse.QuizResponse;

public class AdminDBUtils 
{
	 private static final String	tblAdminProfile	    = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblAdminProfile + "\"";
	 
	 public static HashMap<String, String> existingAdminProfileDetails(Connection conn, String userName, String userPassword)
	            throws SQLException
	    {
		String sql = "";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		HashMap<String, String> adminProfileMap = new HashMap<>();
		sql = "SELECT * from " + tblAdminProfile + " ";
		sql += "where \"UserName\" = ? " ; // 1 userName
		sql += "AND \"Password\" = ?;"; // 2 Password

		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, userName);
		pstmt.setString(2, userPassword);

		rs = pstmt.executeQuery();
		while (rs.next())
		{
			adminProfileMap.put(userName, rs.getString("UserName"));
			adminProfileMap.put(userPassword, rs.getString("Password"));
		}
		return adminProfileMap;
	    }

	public static AdminRegistrationResponse getAdminProfile(Connection conn, long adminId) 
	{
		AdminRegistrationResponse adminRegRespData = null; 
		String sql = "";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		sql = "SELECT ";
		sql += "\"AdminId\", ";
		sql += "\"UserName\", ";
		sql += "\"EmailId\", ";
		sql += "\"Designation\" ";
		sql += "FROM " + tblAdminProfile + " ";
		sql += "where \"AdminId\" = ? ";
		//sql += "order by \"CreatedOn\" desc;";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setLong(1, adminId);
			rs = pstmt.executeQuery();
			while (rs.next())
			{
				adminRegRespData = new AdminRegistrationResponse();
				adminRegRespData.message = "Welcome ! "+rs.getNString(2);
				adminRegRespData.responseType = "S";
				adminRegRespData.adminId = rs.getLong(1);
				adminRegRespData.adminUserName = rs.getNString(2);
				adminRegRespData.email = rs.getNString(3);
				adminRegRespData.desiganation = rs.getNString(4);
			}
			rs.close();
			pstmt.close();
		} catch (SQLException e) {
			DBUtils.CloseConnection(conn);
			e.printStackTrace();
		}
		return adminRegRespData;
	}

	public static long getAdminIdDao(Connection conn, String adminUserName) 
	{
		long adminId = 0 ; 
		String sql = "";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		sql = "SELECT ";
		sql += "\"AdminId\", ";
		sql += "\"UserName\", ";
		sql += "\"EmailId\" ";
		sql += "FROM " + tblAdminProfile + " ";
		sql += "where \"UserName\" = ? ";
		//sql += "order by \"CreatedOn\" desc;";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, adminUserName);
			rs = pstmt.executeQuery();
			while (rs.next())
			{
				adminId  = rs.getLong(1);
			}
			rs.close();
			pstmt.close();
		} catch (SQLException e) {
			DBUtils.CloseConnection(conn);
			e.printStackTrace();
		}
		return adminId;
	}

}
