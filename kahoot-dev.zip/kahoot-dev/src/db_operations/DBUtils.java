package db_operations;

import java.io.IOException;
import java.util.List;

import javax.naming.InitialContext;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import utils.Utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class DBUtils
{
     public static final String SchemaName = "KAHOOT_DEV";
     private static final String XSJSProjectName = "kahoot_dev";

    public static final String tblAdminProfile		 = XSJSProjectName + ".Data.Tables::admin_profile";
    public static final String tblQuizDetails		 = XSJSProjectName + ".Data.Tables::quiz_details";
    public static final String tblQuizSummary		 = XSJSProjectName + ".Data.Tables::quiz_summary";
    public static final String tblGameDetails		 = XSJSProjectName + ".Data.Tables::game_details";
    public static final String tblPlayerScores		 = XSJSProjectName + ".Data.Tables::players_scores";

    public static final String sqnceQuizDetails		 = XSJSProjectName + ".Data.Sequences::quiz_details";
    public static final String sqnceQuizIdDetails	 = XSJSProjectName + ".Data.Sequences::Questions";
    public static final String sqnceGameIdDetails	 = XSJSProjectName + ".Data.Sequences::game_details";
    public static final String sqncePlayersScore	 = XSJSProjectName + ".Data.Sequences::players_score";
    
    
    public static final String tblCenters		     = XSJSProjectName + ".Data.Tables::Centers";
    public static final String tblCentersContacts	     = XSJSProjectName + ".Data.Tables::Centers_Contacts";
    public static final String tblCentersFloormaps	     = XSJSProjectName + ".Data.Tables::Centers_Floormaps";
    public static final String tblCentersOtherDocuments	     = XSJSProjectName + ".Data.Tables::Centers_OtherDocuments";
    public static final String tblCentersPictures	     = XSJSProjectName + ".Data.Tables::Centers_Pictures";
    public static final String tblCMISDocuments		     = XSJSProjectName + ".Data.Tables::CMIS_Documents";
    public static final String tblContents		     = XSJSProjectName + ".Data.Tables::Contents";
    public static final String tblContentsAssetTypes	     = XSJSProjectName + ".Data.Tables::Contents_AssetTypes";
    public static final String tblContentsCenters	     = XSJSProjectName + ".Data.Tables::Contents_Centers";
    public static final String tblContentsComments	     = XSJSProjectName + ".Data.Tables::Contents_Comments";
    public static final String tblContentsContacts	     = XSJSProjectName + ".Data.Tables::Contents_Contacts";
    public static final String tblContentsMainContacts	     = XSJSProjectName + ".Data.Tables::Contents_MainContacts";
    public static final String tblContentsIndustries	     = XSJSProjectName + ".Data.Tables::Contents_Industries";
    public static final String tblContentsSolutions	     = XSJSProjectName + ".Data.Tables::Contents_Solutions";
    public static final String tblContentsInRoleVideoRatings = XSJSProjectName + ".Data.Tables::Contents_InRoleVideoRatings";
    public static final String tblContentsInRoleVideos	     = XSJSProjectName + ".Data.Tables::Contents_InRoleVideos";
    public static final String tblContentsRatings	     = XSJSProjectName + ".Data.Tables::Contents_Ratings";
    public static final String tblContentsSizes		     = XSJSProjectName + ".Data.Tables::Contents_Sizes";
    public static final String tblStories		     = XSJSProjectName + ".Data.Tables::Stories";
    public static final String tblStoriesContents	     = XSJSProjectName + ".Data.Tables::Stories_Contents";
    public static final String tblStoriesDocuments	     = XSJSProjectName + ".Data.Tables::Stories_Documents";

    public static final String sqnceActionLogs		       = XSJSProjectName + ".Data.Sequences::ActionLogs";
    public static final String sqnceCMISDocuments	       = XSJSProjectName + ".Data.Sequences::CMIS_Documents";
    public static final String sqnceCenters		       = XSJSProjectName + ".Data.Sequences::Centers";
    public static final String sqnceCentersFloormaps	       = XSJSProjectName + ".Data.Sequences::Centers_Floormaps";
    public static final String sqnceCentersOtherDocuments      = XSJSProjectName + ".Data.Sequences::Centers_OtherDocuments";
    public static final String sqnceCentersPictures	       = XSJSProjectName + ".Data.Sequences::Centers_Pictures";
    public static final String sqnceContents		       = XSJSProjectName + ".Data.Sequences::Contents";
    public static final String sqnceContentsInRoleVideos       = XSJSProjectName + ".Data.Sequences::Contents_InRoleVideos";
    public static final String sqnceContentsInRoleVideoRatings = XSJSProjectName + ".Data.Sequences::Contents_InRoleVideoRatings";
    public static final String sqnceStories		       = XSJSProjectName + ".Data.Sequences::Stories";
    public static final String sqnceStoriesDocuments	       = XSJSProjectName + ".Data.Sequences::Stories_Documents";

    public static final String sqlVwUsers		  = XSJSProjectName + ".Data.SQLViews::Users";
    public static final String sqlVwUserRoles		  = XSJSProjectName + ".Data.SQLViews::UserRoles";
    public static final String sqlVwAssetTypes		  = XSJSProjectName + ".Data.SQLViews::AssetTypes";
    public static final String sqlVwIndustries		  = XSJSProjectName + ".Data.SQLViews::Industries";
    public static final String sqlVwSolutions		  = XSJSProjectName + ".Data.SQLViews::Solutions";
    public static final String sqlVwRejectionCategoryList = XSJSProjectName + ".Data.SQLViews::RejectionCategoryList";


    public static Long getNextSequenceId(Connection conn, String sequence)
            throws SQLException
    {
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Long Id = 0L;

	// Gets new Id from sequence
	sql = "select " + sequence + ".nextval as \"Id\" from Dummy;";
	pstmt = conn.prepareStatement(sql);
	rs = pstmt.executeQuery();
	rs.next();

	Id = rs.getLong(1);

	return Id;
    }


    public static String combineSQLInsertQuery(List<String> sqlFields, List<String> sqlValues, String tableName)
    {
	String sql = "";

	sql = "INSERT INTO " + tableName + " ";
	sql += "(\"" + String.join("\", \"", sqlFields) + "\") Values(" + String.join(", ", sqlValues) + ");";

	return sql;
    }


    public static String combineSQLUpdateQuery(List<String> sqlFields, List<String> sqlValues, String tableName, String whereCondition)
    {
	String sql = "";
	int i = 0;
	Boolean blFieldAdded = false;

	sql = "Update " + tableName + " set ";

	i = 0;
	for (; i < sqlFields.size(); i++)
	{
	    if (blFieldAdded)
	    {
		sql += ", ";
	    }

	    sql += "\"" + sqlFields.get(i) + "\"" + " = ";
	    sql += sqlValues.get(i);

	    blFieldAdded = true;
	}

	if (whereCondition != "")
	{
	    sql += " " + whereCondition;
	}

	return sql;
    }


    public static Connection ConnectToDatabase(HttpServletResponse response)
            throws IOException
    {
	Connection conn = null;
	try
	{
	    InitialContext ctx = new InitialContext();
	    DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/DefaultDB");
	    conn = ds.getConnection();

	}
	catch (SQLException e)
	{
	    CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while connecting to database - " + e.getMessage());
	    e.printStackTrace();
	    return null;
	}
	catch (Exception e)
	{
	    CloseConnection(conn);
	    Utils.addErrorResponse(response, "Error occurred while connecting to database - " + e.getMessage());
	    e.printStackTrace();
	    return null;
	}

	return conn;
    }

    public static Connection ConnectToDatabase()
            throws IOException
    {
	Connection conn = null;
	try
	{
	    InitialContext ctx = new InitialContext();
	    DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/DefaultDB");
	    conn = ds.getConnection();

	}
	catch (SQLException e)
	{
	    CloseConnection(conn);
	    e.printStackTrace();
	    return null;
	}
	catch (Exception e)
	{
	    CloseConnection(conn);
	    e.printStackTrace();
	    return null;
	}

	return conn;
    }

    public static void CloseConnection(Connection conn)
    {
	try
	{
	    conn.close();
	}
	catch (Exception ex)
	{
	    ex.printStackTrace();
	    return;
	}
    }
}
