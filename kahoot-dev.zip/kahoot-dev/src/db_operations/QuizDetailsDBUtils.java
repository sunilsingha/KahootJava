package db_operations;

import java.sql.Connection;
import java.sql.SQLException;

public class QuizDetailsDBUtils 
{
    private static final String	sqnceQuizDetails	= "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.sqnceQuizDetails + "\"";
    private static final String	sqnceQuizDetailsId	= "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.sqnceQuizIdDetails + "\"";
    private static final String	sqnceGamePinId		= "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.sqnceGameIdDetails + "\"";
    private static final String	sqncePlayersScore	= "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.sqncePlayersScore + "\"";

	public static long getNextQuizId(Connection conn) throws SQLException
    {
	return DBUtils.getNextSequenceId(conn, sqnceQuizDetails);
    }
	
	public static long getNextId(Connection conn) throws SQLException
    {
	return DBUtils.getNextSequenceId(conn, sqnceQuizDetailsId);
    }
	
	public static long getNexPintId(Connection conn) throws SQLException
    {
	return DBUtils.getNextSequenceId(conn, sqnceGamePinId);
    }
	public static long getNextPlayerId(Connection conn) throws SQLException
	{
		return DBUtils.getNextSequenceId(conn, sqncePlayersScore);
	}
}
