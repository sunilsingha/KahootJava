package game;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import gameresponse.GameResponseData;
import gameservices.GameService;
import questionservice.QuizService;
import quizresponse.QuestionResponse;
import utils.Utils;

/**
 * Servlet implementation class InitializeGame
 */
@WebServlet("/api/game/InitializeGame")
public class InitializeGame extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	GameService gameService = null;
	GameResponseData gameResponseData = null;
	String startStatus = "start";
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String quizId = request.getParameter("quizId");
	    String adminId = request.getParameter("adminId");
	    String requestType = request.getParameter("reqType");
	    
	    long quizIdlong = Long.parseLong(quizId);
		long adminIdlong = Long.parseLong(adminId);
		
		gameService = new GameService();
		List<GameResponseData> gameResponseDataList = null;
		if(requestType.equalsIgnoreCase("init"))
		{
			if(quizIdlong != 0 && adminIdlong != 0)
			{
				gameResponseDataList = gameService.startGameService(quizIdlong, adminIdlong, requestType);
			}
			Utils.addSuccessResponseFromObject(response, gameResponseDataList);
		}
		
		if(requestType.equalsIgnoreCase("start"))
		{
			QuizService quizService = new QuizService();
			java.util.List<QuestionResponse> questionResponseList = null;
			if(adminId != null && quizId != null)
			{
				questionResponseList = quizService.getQuestionsService(adminIdlong, quizIdlong, startStatus);
			}
			Utils.addSuccessResponseFromObject(response, questionResponseList);
		}
		if(requestType.equalsIgnoreCase("end"))
		{
			if(quizIdlong != 0 && adminIdlong != 0)
			{
				gameResponseDataList = gameService.startGameService(quizIdlong, adminIdlong, requestType);
			}
			Utils.addSuccessResponseFromObject(response, gameResponseDataList);
		}
		
	    
		
	}

}
