package game;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

import gameresponse.GameResponseData;
import gameservices.GameService;
import utils.Utils;

/**
 * Servlet implementation class JoinGameServlet
 */
@WebServlet("/api/game/JoinGameServlet")
public class JoinGameServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	GameService gameService = null;
	List<GameResponseData> gameResponseData = null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		String strQuizId = request.getParameter("quizId");
	    String strPin = request.getParameter("pinId");
		
	    long longQuizId = Long.parseLong(strQuizId);
	    long longPinId = Long.parseLong(strPin);
		
		gameService = new GameService();
		gameResponseData = gameService.joinGameService(longQuizId, longPinId);
		Utils.addSuccessResponseFromObject(response, gameResponseData);
	}

	}

