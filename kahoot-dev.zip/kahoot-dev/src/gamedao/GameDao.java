package gamedao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import db_operations.DBUtils;
import db_operations.QuizDetailsDBUtils;
import gamedto.AddPlayers;
import quizresponse.QuizResponse;


public class GameDao 
{
	private static final String	tblGameDetails	    = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblGameDetails + "\"";
	private static final String	tblPlayersScore	    = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblPlayerScores + "\"";
	
	String insertGameDetails = "";
	PreparedStatement gameStatement = null;
	ResultSet gameResultSet = null;
	List<String> gameFields = null;
	List<String> gameValues = null;
	List<String> playerField = null;
	List<String> playerValues = null;
	Connection conn = null;
	public Connection getConnection()
	{
		try {
			conn = DBUtils.ConnectToDatabase();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return conn;
	}
	public long insertGameDetails(long quizIdlong, long adminIdlong, String initialStatus) 
	{
		gameFields = new ArrayList<String>();
		gameValues = new ArrayList<String>();
		long pinId = 0;
		conn = getConnection();
		try {
			pinId = QuizDetailsDBUtils.getNextQuizId(conn);
			
			gameFields.add("AdminId");
			gameValues.add("?");
			
			gameFields.add("QuizId");
			gameValues.add("?");
			
			gameFields.add("Pin");
			gameValues.add("?");
			
			gameFields.add("Status");
			gameValues.add("?");
			
			insertGameDetails = DBUtils.combineSQLInsertQuery(gameFields, gameValues, tblGameDetails);
			gameStatement = conn.prepareStatement(insertGameDetails);
			
			gameStatement.setLong(1, adminIdlong);
			gameStatement.setLong(2, quizIdlong);
			gameStatement.setLong(3, pinId);
			gameStatement.setNString(4, initialStatus);
			
			gameStatement.executeUpdate();
			DBUtils.CloseConnection(conn);
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
				e.getLocalizedMessage();
				e.getMessage();
				DBUtils.CloseConnection(conn);
			}
		return pinId;
	}
	public boolean isQuizIdExist(long longQuizId, long longPinId) 
	{
		String sql = "";
		conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Boolean isQuizIdExist = false;
		sql = "SELECT Count(*) FROM " + tblGameDetails + " ";
		sql += "where \"QuizId\" = ? ";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setLong(1, longQuizId);
			rs = pstmt.executeQuery();
			rs.next();
			if (rs.getLong(1) > 0)
			{
			    isQuizIdExist = true;
			}
			rs.close();
			pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtils.CloseConnection(conn);
		return isQuizIdExist;
	}
	public boolean isPinIdExist(long longQuizId, long longPinId) 
	{
		String sql = "";
		conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Boolean isPinIdExist = false;
		sql = "SELECT Count(*) FROM " + tblGameDetails + " ";
		sql += "where \"Pin\" = ? ";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setLong(1, longPinId);
			rs = pstmt.executeQuery();
			rs.next();
			if (rs.getLong(1) > 0)
			{
				isPinIdExist = true;
			}
			rs.close();
			pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtils.CloseConnection(conn);
		return isPinIdExist;
	}
	public boolean isStatusInitialized(String status) 
	{
		String sql = "";
		conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Boolean isStatusinitialized = false;
		sql = "SELECT Count(*) FROM " + tblGameDetails + " ";
		sql += "where \"Status\" = ? ";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setNString(1, status);
			rs = pstmt.executeQuery();
			rs.next();
			if (rs.getLong(1) > 0)
			{
				isStatusinitialized = true;
			}
			rs.close();
			pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtils.CloseConnection(conn);
		return isStatusinitialized;
	}
	public void updateGameStatusDao(long quizIdlong, long adminIdlong, String startStatus) 
	{
		PreparedStatement pstmt = null;
		String sql = "";
		conn = getConnection();
		List<String> sqlFields = new ArrayList<String>();
		List<String> sqlValues = new ArrayList<String>();

		sqlFields.add("Status");
		sqlValues.add("?");

		sql = DBUtils.combineSQLUpdateQuery(sqlFields, sqlValues, tblGameDetails, " where \"QuizId\" = ?;");

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setNString(1, startStatus);
			pstmt.setLong(2, quizIdlong);
			pstmt.execute();
			pstmt.close();
			DBUtils.CloseConnection(conn);
		} catch (SQLException e) {
			e.printStackTrace();
			DBUtils.CloseConnection(conn);
		}
	}
	public void endGameDao(long quizIdlong, long adminIdlong, String endStatus) 
	{
		deleteGameDetails(quizIdlong);
		deletePlayerScore(quizIdlong);
	}
	public void deleteGameDetails(long quizIdlong)
	{
		String sql = "";
		PreparedStatement pstmt = null;
		conn = getConnection();
		
		sql = "Delete from " + tblGameDetails + " ";
		sql += "where \"QuizId\" = ?;";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setLong(1, quizIdlong);
			pstmt.executeUpdate();
			pstmt.close();
			DBUtils.CloseConnection(conn);
		} catch (SQLException e) {
			DBUtils.CloseConnection(conn);
			e.printStackTrace();
		}
	}
	public void deletePlayerScore(long quizIdlong)
	{
		String sql = "";
		PreparedStatement pstmt = null;
		conn = getConnection();
		
		sql = "Delete from " + tblPlayersScore + " ";
		sql += "where \"QuizId\" = ?;";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setLong(1, quizIdlong);
			pstmt.executeUpdate();
			pstmt.close();
			DBUtils.CloseConnection(conn);
		} catch (SQLException e) {
			DBUtils.CloseConnection(conn);
			e.printStackTrace();
		}
	}
	public void insertPlayerDetails(AddPlayers addPlayers, long quizId) 
	{
		playerField = new ArrayList<String>();
		playerValues = new ArrayList<String>();
		conn = getConnection();
		try {
			playerField.add("QuizId");
			playerValues.add("?");
			
			playerField.add("Pin");
			playerValues.add("?");
			
			playerField.add("PlayerId");
			playerValues.add("?");
			
			playerField.add("PlayerName");
			playerValues.add("?");
			
			playerField.add("Score");
			playerValues.add("?");
			
			long autoGenPlayerId = QuizDetailsDBUtils.getNextPlayerId(conn);
			addPlayers.setPlayerId(autoGenPlayerId);
			String playerName = addPlayers.getPlayerName();
			long currentPinId = addPlayers.getPin();
			
			insertGameDetails = DBUtils.combineSQLInsertQuery(playerField, playerValues, tblPlayersScore);
			gameStatement = conn.prepareStatement(insertGameDetails);
			
			gameStatement.setLong(1, quizId);
			gameStatement.setLong(2, currentPinId);
			gameStatement.setLong(3, autoGenPlayerId);
			gameStatement.setNString(4, playerName);
			gameStatement.setLong(5, 0);
			
			gameStatement.executeUpdate();
			DBUtils.CloseConnection(conn);
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
				e.getLocalizedMessage();
				e.getMessage();
				DBUtils.CloseConnection(conn);
			}
	}
	public String getGameStatusByPinId(long pinId)
	{
		String sql = "";
		conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String existingStatus = "";
		sql = "SELECT \"Status\" FROM " + tblGameDetails + " ";
		sql += "where \"Pin\" = ? ";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setLong(1, pinId);
			rs = pstmt.executeQuery();
			while (rs.next())
			{
			   existingStatus = rs.getNString(1);
			}
			rs.close();
			pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtils.CloseConnection(conn);
		return existingStatus;
	}
	public boolean isPinIdExists(long pinId)
	{
		String sql = "";
		conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Boolean isPinIdExist = false;
		sql = "SELECT Count(*) FROM " + tblGameDetails + " ";
		sql += "where \"Pin\" = ? ";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setLong(1, pinId);
			rs = pstmt.executeQuery();
			rs.next();
			if (rs.getLong(1) > 0)
			{
				isPinIdExist = true;
			}
			rs.close();
			pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtils.CloseConnection(conn);
		return isPinIdExist;
	}
	public long getQuizIdByPinId(long pinId)
	{
		String sql = "";
		conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		long existingQuizId = 0;
		sql = "SELECT \"QuizId\" FROM " + tblGameDetails + " ";
		sql += "where \"Pin\" = ? ";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setLong(1, pinId);
			rs = pstmt.executeQuery();
			while (rs.next())
			{
				existingQuizId = rs.getLong(1);
			}
			rs.close();
			pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtils.CloseConnection(conn);
		return existingQuizId;
	}
	public String getStatusByQuizId(long longQuizId, String status)
	{
		String sql = "";
		conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String existingStatus = "";
		sql = "SELECT \"Status\" FROM " + tblGameDetails + " ";
		sql += "where \"QuizId\" = ? AND \"Status\" = ? ";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setLong(1, longQuizId);
			pstmt.setNString(2, status);
			rs = pstmt.executeQuery();
			while (rs.next())
			{
				existingStatus = rs.getString(1);
			}
			rs.close();
			pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtils.CloseConnection(conn);
		return existingStatus;
	}
	public long getPlayerIdDao(String playerName) 
	{
		String sql = "";
		conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		long existingPlayerId = 0;
		sql = "SELECT \"PlayerId\" FROM " + tblPlayersScore + " ";
		sql += "where \"PlayerName\" = ? ";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setNString(1, playerName);
			rs = pstmt.executeQuery();
			while (rs.next())
			{
				existingPlayerId = rs.getLong(1);
			}
			rs.close();
			pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DBUtils.CloseConnection(conn);
		return existingPlayerId;
	}
}
