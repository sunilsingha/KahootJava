package gameresponse;

public class GameResponseData 
{
	public long adminId;
	public long quizId;
	public long pin;
	public String responseType;
	public String status;
	public String messages;

}
