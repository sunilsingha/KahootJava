package gameresponse;

public class PlayersResponse 
{
	public String responseType;
	public String name;
	public long playerId;
	public long quizId;
	public long pinId;
	public String currentStatus;
	public String message;

}
