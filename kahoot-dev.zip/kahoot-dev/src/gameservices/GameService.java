package gameservices;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import gamedao.GameDao;
import gamedto.AddPlayers;
import gameresponse.GameResponseData;
import gameresponse.PlayersResponse;

public class GameService 
{
	
	GameDao gamedao = null;
	long pinId = 0;
	
	GameResponseData gameResponseData = null;
	ArrayList<GameResponseData> gameResponseDataList = null;
	PlayersResponse playersResponse = null;
	List<PlayersResponse> playersResponseDataList = null;
	String initialStatus = "initialized ";
	String startStatus = "started";
	String endStatus = "ended";
	public List<GameResponseData> startGameService(long quizIdlong, long adminIdlong, String requestType) 
	{
		gamedao = new GameDao();
		gameResponseData = new GameResponseData();
		gameResponseDataList = new ArrayList<GameResponseData>();
		
		if(requestType.equalsIgnoreCase("init"))
		{
			pinId = gamedao.insertGameDetails(quizIdlong, adminIdlong, initialStatus);
			gameResponseData.adminId = adminIdlong;
			gameResponseData.quizId = quizIdlong;
			gameResponseData.pin = pinId;
			gameResponseData.status = initialStatus;
			gameResponseData.responseType = "S";
			gameResponseDataList.add(gameResponseData);
		}
		if(requestType.equalsIgnoreCase("end"))
		{
			String existingStatus = gamedao.getStatusByQuizId(quizIdlong, startStatus);
			if(existingStatus.equalsIgnoreCase(startStatus))
			{
				gamedao.endGameDao(quizIdlong, adminIdlong, endStatus);
				gameResponseData.adminId = adminIdlong;
				gameResponseData.quizId = quizIdlong;
				gameResponseData.status = endStatus;
				gameResponseData.responseType = "S";
				gameResponseData.messages = "Status changed from 'stared' to 'ended'";
				gameResponseDataList.add(gameResponseData);
			}
			else
			{
				gameResponseData.adminId = adminIdlong;
				gameResponseData.quizId = quizIdlong;
				gameResponseData.status = endStatus;
				gameResponseData.responseType = "S";
				gameResponseData.messages = "Quiz is not started yet ";
				gameResponseDataList.add(gameResponseData);
			}
			
		}
		return gameResponseDataList;
	}
	public List<GameResponseData> joinGameService(long longQuizId, long longPinId) 
	{
		gamedao = new GameDao();
		boolean isQuizIdExist = false;
		boolean isPinIdExist = false;
		boolean isStatusInitialized = false;
		
		gameResponseData = new GameResponseData();
		gameResponseDataList = new ArrayList<GameResponseData>();
		isQuizIdExist = gamedao.isQuizIdExist(longQuizId, longPinId);
		isPinIdExist = gamedao.isPinIdExist(longQuizId, longPinId);
		isStatusInitialized = gamedao.isStatusInitialized(initialStatus);
		if(isQuizIdExist == true && isPinIdExist == true && isStatusInitialized == true)
		{
			gameResponseData.quizId = longQuizId;
			gameResponseData.pin = longPinId;
			gameResponseData.status = initialStatus;
			gameResponseData.responseType = "S";
			gameResponseDataList.add(gameResponseData);
		}
		else
		{
			gameResponseData.responseType = "E";
			gameResponseDataList.add(gameResponseData);
		}
		gameResponseDataList.removeAll(Collections.singletonList(null));
		return gameResponseDataList;
	}
	public List<PlayersResponse> addPlayersService(AddPlayers addPlayers) 
	{
		gamedao = new GameDao();
		long pinId = addPlayers.getPin();
		String existingStatusByPinId = gamedao.getGameStatusByPinId(pinId);
		long existingQuizId = gamedao.getQuizIdByPinId(pinId);
		addPlayers.setQuizId(existingQuizId);
		boolean isPinIdexist = gamedao.isPinIdExists(pinId);
		
		playersResponse = new PlayersResponse();
		playersResponseDataList = new ArrayList<PlayersResponse>();
		
		if(addPlayers != null)
		{
			if(existingStatusByPinId.equalsIgnoreCase(initialStatus) && isPinIdexist)
			{
				gamedao.insertPlayerDetails(addPlayers, existingQuizId);
				playersResponse.name = addPlayers.getPlayerName();
				playersResponse.playerId = addPlayers.getPlayerId();
				playersResponse.quizId = gamedao.getQuizIdByPinId(pinId);
				playersResponse.pinId = addPlayers.getPin();
				playersResponse.responseType = "S";
				playersResponse.message = "Player logged in successfully";
				playersResponseDataList.add(playersResponse);
			}
			else
			{
				playersResponse.name = addPlayers.getPlayerName();
				playersResponse.pinId = addPlayers.getPin();
				playersResponse.message = "Pin you have entered "+addPlayers.getPin()+" is not correct";
				playersResponse.responseType = "E";
				playersResponseDataList.add(playersResponse);
			}
		}
		return playersResponseDataList;
	}
	public long getPlayerId(String playerName)
	{
		gamedao = new GameDao();
		long playerId = gamedao.getPlayerIdDao(playerName);
		
		return playerId;
	}
}
