package questionDao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import db_operations.DBUtils;
import db_operations.QuizDetailsDBUtils;
import questionTo.CreateQuizTO;
import questionrequest.QuestionRequestData;
import questionrequest.QuizDetailsData;
import quizresponse.QuestionResponse;
import quizresponse.QuizResponse;

public class QuizDao {

	private static final String	tblQuizDetails	    = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblQuizDetails + "\"";
	private static final String	tblQuizSummary	    = "\"" + DBUtils.SchemaName + "\".\"" + DBUtils.tblQuizSummary + "\"";
	
	String insertInQuizDetailsTable = "";
	String insertIntoQuizSummaryTable = "";
	
	String updateIntoQuizDetailsTable = "";
	String updateIntoQuizSummaryTable = "";
	
	PreparedStatement quizDetailsStatement = null;
	PreparedStatement quizSummaryStatement = null;
	ResultSet quizDetailsResultSet = null;
	ResultSet quizSummaryResultSet = null;
	//Quiz details field 
	List<String> QuizDetailsTblFields = null;
	List<String> QuizDetailsTblValues = null;
	QuizResponse quizResponse = null;
	Connection conn = null;
	public Connection getConnection()
	{
		try {
			conn = DBUtils.ConnectToDatabase();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return conn;
	}
	public  void insertQuizDetails(Connection conn, CreateQuizTO createQuizTO)
	{
		insertToQuizDetails(conn, createQuizTO);
		insertToQuizSummary(conn, createQuizTO);
		DBUtils.CloseConnection(conn);
	}
	public void insertToQuizDetails(Connection conn, CreateQuizTO createQuizTO)
	{
		 QuizDetailsTblFields = new ArrayList<String>();
		 QuizDetailsTblValues = new ArrayList<String>();

		QuizDetailsTblFields.add("QuizId");
		QuizDetailsTblValues.add("?");
		
		QuizDetailsTblFields.add("QuestionNumber");
		QuizDetailsTblValues.add("?");
		
		QuizDetailsTblFields.add("Type");
		QuizDetailsTblValues.add("?");

		QuizDetailsTblFields.add("Question");
		QuizDetailsTblValues.add("?");

		QuizDetailsTblFields.add("A");
		QuizDetailsTblValues.add("?"); 

		QuizDetailsTblFields.add("B");
		QuizDetailsTblValues.add("?");
		
		QuizDetailsTblFields.add("C");
		QuizDetailsTblValues.add("?");

		QuizDetailsTblFields.add("D");
		QuizDetailsTblValues.add("?");

		QuizDetailsTblFields.add("CorrectOption");
		QuizDetailsTblValues.add("?"); 
		
		QuizDetailsTblFields.add("Id");
		QuizDetailsTblValues.add("?"); 
		
		insertInQuizDetailsTable = DBUtils.combineSQLInsertQuery(QuizDetailsTblFields, QuizDetailsTblValues, tblQuizDetails);
		try {
			quizDetailsStatement = conn.prepareStatement(insertInQuizDetailsTable);
			if(createQuizTO.getQuizDetails().getQuizId() != 0)
			{
			quizDetailsStatement.setLong(1, createQuizTO.getQuizDetails().getQuizId());
			}
			for(int i = 0 ; i< createQuizTO.getQuestions().size() ; i++)
			{
				quizDetailsStatement.setLong(2, createQuizTO.getQuestions().get(i).getQuestionNumber());
				quizDetailsStatement.setString(3, createQuizTO.getQuestions().get(i).getType());
				quizDetailsStatement.setString(4, createQuizTO.getQuestions().get(i).getQuestion());
				quizDetailsStatement.setString(5, createQuizTO.getQuestions().get(i).getOptionA());
				quizDetailsStatement.setString(6, createQuizTO.getQuestions().get(i).getOptionB());
				quizDetailsStatement.setString(7, createQuizTO.getQuestions().get(i).getOptionC());
				quizDetailsStatement.setString(8, createQuizTO.getQuestions().get(i).getOptionD());
				quizDetailsStatement.setLong(9, createQuizTO.getQuestions().get(i).getCorrectOptionIndex());
				quizDetailsStatement.setLong(10, QuizDetailsDBUtils.getNextId(conn));
				quizDetailsStatement.addBatch();
				quizDetailsStatement.executeBatch();
			}
		} catch (SQLException e) {
			e.printStackTrace();
			e.getLocalizedMessage();
			e.getMessage();
		}
	}
	public void insertToQuizSummary(Connection conn, CreateQuizTO createQuizTO)
	{
		List<String> QuizSummaryTblFields = new ArrayList<String>();
		List<String> QuizSummaryTblValues = new ArrayList<String>();

		//Fields & Values for Quiz Summary Table
		QuizSummaryTblFields.add("AdminId");
		QuizSummaryTblValues.add("?");
		
		QuizSummaryTblFields.add("QuizName");
		QuizSummaryTblValues.add("?"); 
		
		QuizSummaryTblFields.add("QuizId");
		QuizSummaryTblValues.add("?");
		
		QuizSummaryTblFields.add("QuizDescription");
		QuizSummaryTblValues.add("?");
		
		QuizSummaryTblFields.add("TotalQuestions");
		QuizSummaryTblValues.add("?");
		
		QuizSummaryTblFields.add("Date");
		QuizSummaryTblValues.add("?");

		insertIntoQuizSummaryTable = DBUtils.combineSQLInsertQuery(QuizSummaryTblFields, QuizSummaryTblValues, tblQuizSummary);
		try {
			quizSummaryStatement = conn.prepareStatement(insertIntoQuizSummaryTable);
			
			quizSummaryStatement.setInt(1, createQuizTO.getQuizDetails().getAdminId());
			quizSummaryStatement.setString(2, createQuizTO.getQuizDetails().getQuizName());
			if(createQuizTO.getQuizDetails().getQuizId() != 0)
			{
			quizSummaryStatement.setLong(3, createQuizTO.getQuizDetails().getQuizId());
			}
			quizSummaryStatement.setString(4, createQuizTO.getQuizDetails().getQuizDescription());
			quizSummaryStatement.setInt(5, createQuizTO.getQuestions().size());
			quizSummaryStatement.setString(6, createQuizTO.getQuizDetails().getDate());
			quizSummaryStatement.addBatch();
			quizSummaryStatement.executeBatch();
		} catch (SQLException e) 
		{
			DBUtils.CloseConnection(conn);
			e.printStackTrace();
		}
	}
	public List<QuizResponse> getQuizSummaryDao(Connection conn, long adminId) 
	{
		List<QuizResponse> quizResponselist = new ArrayList<QuizResponse>();
		QuizResponse quizResponseData = null; 
		String sql = "";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		sql = "SELECT ";
		sql += "\"AdminId\", ";
		sql += "\"QuizName\", ";
		sql += "\"QuizDescription\", ";
		sql += "\"TotalQuestions\", ";
		sql += "\"QuizId\", ";
		sql += "\"Date\" "; 
		sql += "FROM " + tblQuizSummary + " ";
		sql += "where \"AdminId\" = ? ";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setLong(1, adminId);
			rs = pstmt.executeQuery();
			while (rs.next())
			{
				quizResponseData = new QuizResponse();
				quizResponseData.adminId = rs.getLong(1);
				quizResponseData.quizName = rs.getNString(2);
				quizResponseData.quizDescription = rs.getNString(3);
				quizResponseData.totalQuestions = rs.getLong(4);
				quizResponseData.quizId = rs.getLong(5);
				quizResponseData.date = rs.getString(6);

				quizResponselist.add(quizResponseData);
			}
			rs.close();
			pstmt.close();
			DBUtils.CloseConnection(conn);
		} catch (SQLException e) {
			DBUtils.CloseConnection(conn);
			e.printStackTrace();
		}
		return quizResponselist;
	    }
	public void deleteQuizDao(Connection conn, CreateQuizTO createQuizTO) 
	{
		deleteQuizDetailsData(conn, createQuizTO);
		deleteQuizSummaryData(conn, createQuizTO);
		DBUtils.CloseConnection(conn);
	}
	public void deleteQuizSummaryData(Connection conn, CreateQuizTO createQuizTO)
	{
		String sql = "";
		PreparedStatement pstmt = null;
		
		sql = "Delete from " + tblQuizSummary + " ";
		sql += "where \"QuizId\" = ?;";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setLong(1, createQuizTO.getQuizDetails().getQuizId());
			pstmt.executeUpdate();
			pstmt.close();
		} catch (SQLException e) {
			DBUtils.CloseConnection(conn);
			e.printStackTrace();
		}
	}
	
	public void deleteQuizDetailsData(Connection conn, CreateQuizTO createQuizTO)
	{
		String sql = "";
		PreparedStatement pstmt = null;
		
		sql = "Delete from " + tblQuizDetails + " ";
		sql += "where \"QuizId\" = ?;";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setLong(1, createQuizTO.getQuizDetails().getQuizId());
			pstmt.executeUpdate();
			pstmt.close();
		} catch (SQLException e) {
			DBUtils.CloseConnection(conn);
			e.printStackTrace();
		}
	}
	public void updateQuestions(Connection conn, CreateQuizTO createQuizTO) 
	{
		deleteQuizDetailsData(conn, createQuizTO);
		deleteQuizSummaryData(conn, createQuizTO);
		insertToQuizDetails(conn, createQuizTO);
		insertToQuizSummary(conn, createQuizTO);
		DBUtils.CloseConnection(conn);
	}
	public List<QuestionResponse> getQuestionsDao(long requestAdminId, long requestQuizId) 
	{
		QuestionResponse questionRequestData = null;
		List<QuestionResponse> questionsResponselist = new ArrayList<QuestionResponse>();
		QuizDetailsData quizDetailsData = null;
		QuestionRequestData questionsRequestData = null;
		List<QuestionRequestData> questionsRequestDataList =  new ArrayList<QuestionRequestData>();
		String quizSummarySql = "";
		String quizDetailsSql = "";
		PreparedStatement quizSummaryPstmt = null;
		PreparedStatement quizSuDetailsPstmt = null;
		ResultSet quizSummaryResultSet = null;
		ResultSet quizDetailsResultSet = null;
		Connection getConn = getConnection(); 
		quizSummarySql = "SELECT ";
		quizSummarySql += "\"AdminId\", ";
		quizSummarySql += "\"QuizName\", ";
		quizSummarySql += "\"QuizDescription\", ";
		quizSummarySql += "\"QuizId\", ";
		quizSummarySql += "\"Date\" "; 
		quizSummarySql += "FROM " + tblQuizSummary + " ";
		quizSummarySql += "where \"AdminId\" = ? AND \"QuizId\" = ?";
		
		quizDetailsSql = "SELECT ";
		quizDetailsSql += "\"QuestionNumber\", ";
		quizDetailsSql += "\"Type\", ";
		quizDetailsSql += "\"Question\", ";
		quizDetailsSql += "\"A\", ";
		quizDetailsSql += "\"B\", ";
		quizDetailsSql += "\"C\", "; 
		quizDetailsSql += "\"D\", ";
		quizDetailsSql += "\"CorrectOption\" "; 
		quizDetailsSql += "FROM " + tblQuizDetails + " ";
		quizDetailsSql += "where \"QuizId\" = ?";
		
		try {
			quizSummaryPstmt = getConn.prepareStatement(quizSummarySql);
			quizSummaryPstmt.setLong(1, requestAdminId);
			quizSummaryPstmt.setLong(2, requestQuizId);
			quizSummaryResultSet = quizSummaryPstmt.executeQuery();
			quizSuDetailsPstmt = getConn.prepareStatement(quizDetailsSql);
			quizSuDetailsPstmt.setLong(1, requestQuizId);
			quizDetailsResultSet = quizSuDetailsPstmt.executeQuery();
			while (quizSummaryResultSet.next())
			{
				quizDetailsData = new QuizDetailsData();
				quizDetailsData.adminId = quizSummaryResultSet.getLong(1);
				quizDetailsData.quizName = quizSummaryResultSet.getNString(2);
				quizDetailsData.quizDescription = quizSummaryResultSet.getNString(3);
				quizDetailsData.quizId = quizSummaryResultSet.getLong(4);
				quizDetailsData.date = quizSummaryResultSet.getString(5);
				
			}
			while (quizDetailsResultSet.next())
			{
				questionsRequestData = new QuestionRequestData();
				questionsRequestData.questionNumber = quizDetailsResultSet.getLong(1);
				questionsRequestData.type = quizDetailsResultSet.getNString(2);
				questionsRequestData.question = quizDetailsResultSet.getNString(3);
				questionsRequestData.optionA = quizDetailsResultSet.getString(4);
				questionsRequestData.optionB = quizDetailsResultSet.getString(5);
				questionsRequestData.optionC = quizDetailsResultSet.getString(6);
				questionsRequestData.optionD = quizDetailsResultSet.getString(7);
				questionsRequestData.correctOptionIndex = quizDetailsResultSet.getLong(8);
				questionsRequestDataList.add(questionsRequestData);
			}
			questionRequestData = new QuestionResponse(quizDetailsData, questionsRequestDataList);
			questionsResponselist.add(questionRequestData);
			
			quizDetailsResultSet.close();
			quizSummaryResultSet.close();
			quizSummaryPstmt.close();
			quizSuDetailsPstmt.close();
			DBUtils.CloseConnection(getConn);
		} catch (SQLException e) {
			DBUtils.CloseConnection(getConn);
			e.printStackTrace();
		}
		return questionsResponselist;
	}
	}
