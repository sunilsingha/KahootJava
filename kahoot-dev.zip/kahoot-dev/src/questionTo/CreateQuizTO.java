package questionTo;

import java.util.List;

public class CreateQuizTO 
{
	 QuizDetailsTo quizDetails;
	 List<QuestionsTo> questions;
	
	public QuizDetailsTo getQuizDetails() {
		return quizDetails;
	}
	public void setQuizDetails(QuizDetailsTo quizDetails) {
		this.quizDetails = quizDetails;
	}
	public List<QuestionsTo> getQuestions() {
		return questions;
	}
	public void setQuestions(List<QuestionsTo> questions) {
		this.questions = questions;
	}
	
	
}
