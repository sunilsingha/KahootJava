package questionrequest;

public class QuestionRequestData 
{
	public long questionNumber;
	public String type;
	public String question;
	public String optionA;
	public String optionB;
	public String optionC;
	public String optionD;
	public long correctOptionIndex;

}
