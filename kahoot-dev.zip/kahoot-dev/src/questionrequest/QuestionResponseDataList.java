package questionrequest;

import java.util.List;

public class QuestionResponseDataList 
{
	public List<QuestionRequestData> questionReqDataList;
}
