package questionrequest;

public class QuizDetailsData 
{
	public long adminId;
	public long quizId;
	public String quizName;
	public String quizDescription;
	public String requestType;
	public String date;

}
