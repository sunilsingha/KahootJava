package questionrequest;

public class QuizRequestData 
{
	public long adminId; 

}
