package questions;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import db_operations.DBUtils;
import questionTo.CreateQuizTO;
import questionrequest.QuizRequestData;
import questionservice.QuizService;
import quizresponse.QuizResponse;
import utils.RequestType;
import utils.Utils;

@WebServlet("/api/admin/CreateQuiz")
public class CreateQuiz extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private QuizService quizService = null;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		StringBuffer stringBuffer = new StringBuffer();
		CreateQuizTO createQuizTO = null;
		String line = null;
		try
		{
		    BufferedReader reader = request.getReader();
		    while ((line = reader.readLine()) != null)
		    {
		    	stringBuffer.append(line);
		    }
		    ObjectMapper objectMapper = new ObjectMapper();
		    objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
			String requestJson = stringBuffer.toString();
			createQuizTO = objectMapper.readValue(requestJson, CreateQuizTO.class);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		Connection conn = null;
		conn = DBUtils.ConnectToDatabase(response);
		if (conn == null)
		{
		    return;
		}
		quizService = new QuizService();
		QuizResponse quizResponseObj = new QuizResponse();
		try
		{
			quizService.processQuizData(conn, createQuizTO);
			if(quizService != null)
			{
				quizResponseObj.responseType = "S";
				quizResponseObj.quizId = createQuizTO.getQuizDetails().getQuizId();
			}
			else
			{
				quizResponseObj.responseType = "E";
			}
		} 
		catch (SQLException e) 
		{
			DBUtils.CloseConnection(conn);
			e.printStackTrace();
		}
		Utils.addSuccessResponseFromObject(response, quizResponseObj);
	}

}
