package questions;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import adminresponse.AdminRegistrationResponse;
import db_operations.DBUtils;
import questionTo.CreateQuizTO;
import questionservice.QuizService;
import quizresponse.DeleteResponse;
import utils.Utils;

@WebServlet("/api/admin/DeleteQuiz")
public class DeleteQuiz extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private QuizService quizService = null;
	private DeleteResponse deleteResponse;
    public DeleteQuiz() 
    {
        super();
    }
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
	}
	protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		StringBuffer stringBuffer = new StringBuffer();
		CreateQuizTO createQuizTO = null;
		String line = null;
		try
		{
		    BufferedReader reader = request.getReader();
		    while ((line = reader.readLine()) != null)
		    {
		    	stringBuffer.append(line);
		    }
		    ObjectMapper objectMapper = new ObjectMapper();
		    objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
			String requestJson = stringBuffer.toString();
			createQuizTO = objectMapper.readValue(requestJson, CreateQuizTO.class);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		Connection conn = null;
		conn = DBUtils.ConnectToDatabase(response);
		if (conn == null)
		{
		    return;
		}
		quizService = new QuizService();
		deleteResponse = new DeleteResponse();
			try {
				quizService.deleteQuizService(conn, createQuizTO);
				deleteResponse.message="Data deleted Successfully";
				deleteResponse.responseType = "S";
				Utils.addSuccessResponseFromObject(response, deleteResponse);
				DBUtils.CloseConnection(conn);
			} catch (SQLException e) {
				DBUtils.CloseConnection(conn);
				e.printStackTrace();
			}
	}
}
