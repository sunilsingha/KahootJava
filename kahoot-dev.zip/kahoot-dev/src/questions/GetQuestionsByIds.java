package questions;

import java.awt.List;
import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import questionservice.QuizService;
import quizresponse.QuestionResponse;
import quizresponse.QuizResponse;
import utils.Utils;

/**
 * Servlet implementation class GetQuestionsByIds
 */
@WebServlet("/api/admin/getQuestionsByIds")
public class GetQuestionsByIds extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private QuizService quizService = null;  
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetQuestionsByIds() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String requestAdminId = request.getParameter("adminId");
		String requestQuizId = request.getParameter("quizId");
		
		long requestAdminIdLong = Long.parseLong(requestAdminId);
		long requestQuizIdLong = Long.parseLong(requestQuizId);
		
		quizService = new QuizService();
		java.util.List<QuestionResponse> questionResponseList = null;
		if(requestAdminId != null && requestQuizId != null)
		{
			questionResponseList = quizService.getQuestionsService(requestAdminIdLong, requestQuizIdLong, null);
		}
		Utils.addSuccessResponseFromObject(response, questionResponseList);
		
		
	}

}
