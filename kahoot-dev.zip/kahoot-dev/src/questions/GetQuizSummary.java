package questions;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

import adminrequest.AdminProfileRequest;
import db_operations.DBUtils;
import questionrequest.QuizRequestData;
import questionservice.QuizService;
import quizresponse.QuizResponse;
import utils.Utils;

@WebServlet("/api/admin/GetQuizSummary")
public class GetQuizSummary extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		StringBuffer stringBuffer = new StringBuffer();
		QuizRequestData quizRequestData = null;
		
		String line = null;
		try
		{
		    BufferedReader reader = request.getReader();
		    while ((line = reader.readLine()) != null)
		    {
		    	stringBuffer.append(line);
		    }
		    ObjectMapper mapper = new ObjectMapper();
			String requestJson = stringBuffer.toString();
			quizRequestData = mapper.readValue(requestJson, QuizRequestData.class);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		Connection conn = null;
		conn = DBUtils.ConnectToDatabase(response);
		if (conn == null)
		{
		    return;
		}
		QuizService quizService = new QuizService();
		
		List<QuizResponse> quizResponseObj = null;
		try {
			quizResponseObj = quizService.getQuizSummaryService(conn, quizRequestData.adminId);
		} catch (SQLException e) {
			DBUtils.CloseConnection(conn);
			e.printStackTrace();
		}
		Utils.addSuccessResponseFromObject(response, quizResponseObj);
	}

}
