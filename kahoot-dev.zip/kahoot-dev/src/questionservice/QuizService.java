package questionservice;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db_operations.QuizDetailsDBUtils;
import gamedao.GameDao;
import questionDao.QuizDao;
import questionTo.CreateQuizTO;
import questionTo.QuizDetailsTo;
import quizresponse.QuestionResponse;
import quizresponse.QuizResponse;
import utils.RequestType;

public class QuizService 
{
	private QuizDao quizDao = null;
	private GameDao gameDao = null;
	String startStatus = "started";
	public void processQuizData(Connection conn, CreateQuizTO createQuizTO) throws IOException, SQLException 
	{
		quizDao = new QuizDao();
		if (createQuizTO.getQuizDetails().getRequestType().equalsIgnoreCase("Add")) 
		{
			createQuizTO.getQuizDetails().setQuizId(QuizDetailsDBUtils.getNextQuizId(conn));
			quizDao.insertQuizDetails(conn, createQuizTO);
		} 
		if(createQuizTO.getQuizDetails().getRequestType().equalsIgnoreCase("Update"))
		{
			quizDao.updateQuestions(conn, createQuizTO);
		}
	}
	public List<QuizResponse> getQuizSummaryService(Connection conn, long adminId) throws IOException, SQLException 
	{
		quizDao = new QuizDao();
		List<QuizResponse> quizResServList =  quizDao.getQuizSummaryDao(conn, adminId);
		return quizResServList;
	}
	public void deleteQuizService(Connection conn, CreateQuizTO createQuizTO) throws IOException, SQLException
	{
		quizDao = new QuizDao();
		quizDao.deleteQuizDao(conn, createQuizTO);
		
	}
	public List<QuestionResponse> getQuestionsService(long requestAdminId, long requestQuizId, String reqType) 
	{
		List<QuestionResponse> questionResponseServList = null;
		quizDao = new QuizDao();
		gameDao = new GameDao();
		try {
			if(reqType != null)
			{
				if(reqType.equalsIgnoreCase("start"))
				{
					gameDao.updateGameStatusDao(requestQuizId, requestAdminId, startStatus);
					questionResponseServList = quizDao.getQuestionsDao(requestAdminId, requestQuizId);
				}
			}
			else
			{
				questionResponseServList = quizDao.getQuestionsDao(requestAdminId, requestQuizId);
			}
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
		return questionResponseServList;

	}
	
}
