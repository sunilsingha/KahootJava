package quizresponse;

public class DeleteResponse {
	public String message ;
	public String responseType;

}
