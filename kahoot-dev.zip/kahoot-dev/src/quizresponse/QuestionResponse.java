package quizresponse;

import java.util.List;
import questionrequest.QuestionRequestData;
import questionrequest.QuizDetailsData;

public class QuestionResponse 
{
	public long adminId;
	public long quizId;
	public String quizName;
	public String quizDescription;
	public String requestType;
	public String date;
	
	public List<QuestionRequestData> questions;
	
	public QuestionResponse(QuizDetailsData quizData, List<QuestionRequestData> questionsRequestData)
	{
		this.adminId = quizData.adminId;
		this.quizId = quizData.quizId;
		this.quizName = quizData.quizName;
		this.quizDescription = quizData.quizDescription;
		this.date = quizData.date;
		this.questions = questionsRequestData;
		
	}
}
