package quizresponse;

public class QuizDetailsResponse 
{
	public int adminId;
	public long quizId;
	public String quizName;
	public String quizDescription;
	public String requestType;
	public String date;

}
