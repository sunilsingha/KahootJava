package quizresponse;

public class QuizResponse 
{

	public String responseType;
	public long adminId;
	public String quizName;
	public String quizDescription;
	public long totalQuestions;
	public long quizId;
	public String date;
}
